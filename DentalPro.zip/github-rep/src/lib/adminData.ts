import { db, dentistsOf, patientsOf, servicesOf } from "./store";
import type { Appointment, AppointmentStatus } from "./types";

export interface AppointmentView {
  id: string;
  date: string;
  startTime: string;
  endTime: string;
  status: AppointmentStatus;
  patientId: string;
  patientName: string;
  patientPhone: string;
  serviceId: string;
  serviceName: string;
  dentistId: string;
  dentistName: string;
  issue: string;
  source: string;
  createdAt: string;
}

export function enrichAppointments(
  clinicId: string,
  filter?: (a: Appointment) => boolean
): AppointmentView[] {
  const patients = new Map(patientsOf(clinicId).map((p) => [p.id, p]));
  const services = new Map(servicesOf(clinicId).map((s) => [s.id, s]));
  const dentists = new Map(dentistsOf(clinicId).map((d) => [d.id, d]));

  return db()
    .appointments.filter((a) => a.clinicId === clinicId && (!filter || filter(a)))
    .map((a) => {
      const patient = patients.get(a.patientId);
      return {
        id: a.id,
        date: a.date,
        startTime: a.startTime,
        endTime: a.endTime,
        status: a.status,
        patientId: a.patientId,
        patientName: patient ? `${patient.firstName} ${patient.lastName}` : "Unknown",
        patientPhone: patient?.phone ?? "",
        serviceId: a.serviceId,
        serviceName: services.get(a.serviceId)?.name ?? "—",
        dentistId: a.dentistId,
        dentistName: dentists.get(a.dentistId)?.name ?? "—",
        issue: a.issue,
        source: a.source,
        createdAt: a.createdAt,
      };
    })
    .sort((a, b) =>
      a.date === b.date
        ? a.startTime.localeCompare(b.startTime)
        : a.date.localeCompare(b.date)
    );
}
