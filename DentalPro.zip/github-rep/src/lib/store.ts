import fs from "node:fs";
import path from "node:path";
import { randomUUID } from "node:crypto";
import type {
  Appointment,
  Clinic,
  Database,
  Dentist,
  Patient,
  Review,
  Service,
  User,
  WeekHours,
} from "./types";
import { hashPassword } from "./password";
import { addDays, toDateString, toMinutes, toTimeString } from "./utils";

const DATA_DIR = process.env.DATA_DIR || path.join(process.cwd(), "data");
const DB_PATH = path.join(DATA_DIR, "db.json");

declare global {
  // eslint-disable-next-line no-var
  var __dentalproDb: Database | undefined;
}

export function uid(): string {
  return randomUUID();
}

export function token(): string {
  return randomUUID().replace(/-/g, "") + randomUUID().replace(/-/g, "");
}

export function db(): Database {
  if (!globalThis.__dentalproDb) {
    globalThis.__dentalproDb = load();
  }
  return globalThis.__dentalproDb;
}

/** Persist the current in-memory database to disk. Call after any mutation. */
export function save(): void {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  fs.writeFileSync(DB_PATH, JSON.stringify(db(), null, 2));
}

function load(): Database {
  if (fs.existsSync(DB_PATH)) {
    return JSON.parse(fs.readFileSync(DB_PATH, "utf8")) as Database;
  }
  const seeded = seed();
  fs.mkdirSync(DATA_DIR, { recursive: true });
  fs.writeFileSync(DB_PATH, JSON.stringify(seeded, null, 2));
  return seeded;
}

/* ---------- lookups ---------- */

export function clinicBySlug(slug: string): Clinic | undefined {
  return db().clinics.find((c) => c.slug === slug);
}

export function clinicById(id: string): Clinic | undefined {
  return db().clinics.find((c) => c.id === id);
}

export function servicesOf(clinicId: string, activeOnly = false): Service[] {
  return db()
    .services.filter((s) => s.clinicId === clinicId && (!activeOnly || s.active))
    .sort((a, b) => a.sortOrder - b.sortOrder);
}

export function dentistsOf(clinicId: string, activeOnly = false): Dentist[] {
  return db().dentists.filter(
    (d) => d.clinicId === clinicId && (!activeOnly || d.active)
  );
}

export function appointmentsOf(clinicId: string): Appointment[] {
  return db().appointments.filter((a) => a.clinicId === clinicId);
}

export function patientsOf(clinicId: string): Patient[] {
  return db().patients.filter((p) => p.clinicId === clinicId);
}

export function reviewsOf(clinicId: string): Review[] {
  return db().reviews.filter((r) => r.clinicId === clinicId);
}

export function findPatientByPhone(
  clinicId: string,
  phone: string
): Patient | undefined {
  return db().patients.find((p) => p.clinicId === clinicId && p.phone === phone);
}

export function userByEmail(email: string): User | undefined {
  return db().users.find(
    (u) => u.email.toLowerCase() === email.toLowerCase().trim()
  );
}

/* ---------- default templates & fixtures ---------- */

export const DEFAULT_SMS_TEMPLATES = {
  confirmation:
    "{clinic}: Your appointment for {service} is confirmed for {date} at {time}. Manage your booking: {link}",
  reminder:
    "{clinic}: Reminder — your {service} appointment is tomorrow at {time}. We look forward to seeing you!",
};

export const DEFAULT_WEEK_HOURS: WeekHours = [
  { closed: true, open: "09:00", close: "14:00" }, // Sun
  { closed: false, open: "09:00", close: "17:00" }, // Mon
  { closed: false, open: "09:00", close: "17:00" },
  { closed: false, open: "09:00", close: "17:00" },
  { closed: false, open: "09:00", close: "17:00" },
  { closed: false, open: "09:00", close: "17:00" }, // Fri
  { closed: false, open: "09:00", close: "14:00" }, // Sat
];

export const DEFAULT_SERVICES: Array<
  Pick<Service, "name" | "description" | "durationMinutes" | "price" | "icon">
> = [
  {
    name: "General Checkup",
    description:
      "A complete oral examination with professional cleaning and personalized advice for a healthy smile.",
    durationMinutes: 20,
    price: 20,
    icon: "checkup",
  },
  {
    name: "Teeth Whitening",
    description:
      "Brighten your smile by several shades in a single visit with gentle, enamel-safe whitening.",
    durationMinutes: 40,
    price: 120,
    icon: "whitening",
  },
  {
    name: "Dental Filling",
    description:
      "Tooth-colored composite fillings that restore your tooth invisibly and comfortably.",
    durationMinutes: 45,
    price: 35,
    icon: "filling",
  },
  {
    name: "Root Canal",
    description:
      "Pain-free root canal treatment using modern rotary technology and precise imaging.",
    durationMinutes: 75,
    price: 90,
    icon: "root-canal",
  },
  {
    name: "Dental Implants",
    description:
      "Permanent, natural-looking tooth replacement with premium titanium implants.",
    durationMinutes: 90,
    price: 450,
    icon: "implant",
  },
  {
    name: "Orthodontics",
    description:
      "Braces and clear aligners to straighten your teeth — consultation and treatment planning.",
    durationMinutes: 30,
    price: 30,
    icon: "braces",
  },
  {
    name: "Cosmetic Dentistry",
    description:
      "Veneers, bonding and smile design tailored to the smile you have always wanted.",
    durationMinutes: 45,
    price: null,
    icon: "cosmetic",
  },
  {
    name: "Emergency Care",
    description:
      "Sudden pain, swelling or a broken tooth? We keep same-day slots for urgent cases.",
    durationMinutes: 30,
    price: null,
    icon: "emergency",
  },
  {
    name: "Other",
    description:
      "Not sure what you need? Book a visit and describe your issue — we will take care of the rest.",
    durationMinutes: 30,
    price: null,
    icon: "other",
  },
];

/* ---------- seed ---------- */

/** Deterministic PRNG so the demo data is stable across reseeds. */
function mulberry32(a: number) {
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function seed(): Database {
  const now = new Date().toISOString();
  const rand = mulberry32(383383);
  const pick = <T,>(arr: T[]): T => arr[Math.floor(rand() * arr.length)];

  const clinicId = uid();

  const clinic: Clinic = {
    id: clinicId,
    slug: "smile",
    name: "Smile Dental Clinic",
    tagline: "Modern dentistry in the heart of Prishtina",
    logoUrl: null,
    primaryColor: "#2563eb",
    heroHeadline: "Healthy Smiles Start Here.",
    heroSubheadline:
      "Book your appointment in less than a minute. No account required.",
    aboutText:
      "Smile Dental Clinic combines modern technology with a warm, personal approach. Our team of certified dentists takes time to listen, explain and make every visit comfortable — from a routine checkup to a complete smile makeover.",
    patientInstructions:
      "Please arrive 5 minutes before your appointment. If you have previous X-rays or reports, bring them along.",
    address: "Rr. Garibaldi 23",
    city: "Prishtina",
    phone: "+383 44 123 456",
    emergencyPhone: "+383 44 987 654",
    email: "hello@smiledental.com",
    mapsEmbedUrl: "https://www.google.com/maps?q=Prishtina%2C+Kosovo&output=embed",
    socials: {
      facebook: "https://facebook.com/smiledental",
      instagram: "https://instagram.com/smiledental",
      tiktok: "",
    },
    stats: { yearsExperience: 15, happyPatients: 12000, certifiedDentists: 6 },
    workingHours: DEFAULT_WEEK_HOURS,
    holidays: [
      { date: "2026-08-15", name: "Staff Training Day" },
      { date: "2026-11-28", name: "Independence Day" },
    ],
    slotStepMinutes: 30,
    minLeadMinutes: 60,
    maxAdvanceDays: 60,
    smsTemplates: { ...DEFAULT_SMS_TEMPLATES },
    timezone: "Europe/Belgrade",
    published: true,
    createdAt: now,
  };

  const services: Service[] = DEFAULT_SERVICES.map((s, i) => ({
    id: uid(),
    clinicId,
    ...s,
    active: true,
    sortOrder: i,
  }));

  const dentists: Dentist[] = [
    {
      id: uid(),
      clinicId,
      name: "Dr. Arta Krasniqi",
      title: "Implantology & Oral Surgery",
      bio: "12 years of experience in implantology. Gentle, precise and passionate about restoring confident smiles.",
      workingHours: null,
      daysOff: [],
      active: true,
    },
    {
      id: uid(),
      clinicId,
      name: "Dr. Blerim Gashi",
      title: "Orthodontics",
      bio: "Specialist in braces and clear aligners for children and adults.",
      workingHours: null,
      daysOff: [],
      active: true,
    },
    {
      id: uid(),
      clinicId,
      name: "Dr. Elira Hoxha",
      title: "General & Cosmetic Dentistry",
      bio: "Focused on preventive care, aesthetic restorations and anxiety-free visits.",
      workingHours: null,
      daysOff: [],
      active: true,
    },
  ];

  const users: User[] = [
    {
      id: uid(),
      clinicId: null,
      role: "super_admin",
      name: "Platform Admin",
      email: "admin@dentalpro.app",
      passwordHash: hashPassword("admin1234"),
      dentistId: null,
      createdAt: now,
    },
    {
      id: uid(),
      clinicId,
      role: "owner",
      name: "Jon Kalludra",
      email: "owner@smile.dental",
      passwordHash: hashPassword("demo1234"),
      dentistId: null,
      createdAt: now,
    },
    {
      id: uid(),
      clinicId,
      role: "receptionist",
      name: "Vlora Berisha",
      email: "reception@smile.dental",
      passwordHash: hashPassword("demo1234"),
      dentistId: null,
      createdAt: now,
    },
    {
      id: uid(),
      clinicId,
      role: "dentist",
      name: "Dr. Arta Krasniqi",
      email: "arta@smile.dental",
      passwordHash: hashPassword("demo1234"),
      dentistId: dentists[0].id,
      createdAt: now,
    },
  ];

  const firstNames = [
    "Liridon", "Vjosa", "Ardit", "Elsa", "Driton", "Fjolla", "Leart", "Rina",
    "Gentrit", "Dafina", "Arben", "Erza", "Bekim", "Lumnije", "Endrit", "Adelina",
    "Valon", "Blerta", "Fisnik", "Jehona", "Kushtrim", "Mimoza", "Petrit", "Teuta",
  ];
  const lastNames = [
    "Berisha", "Ramadani", "Shala", "Morina", "Krasniqi", "Bytyqi", "Zeka",
    "Ahmeti", "Salihu", "Kelmendi", "Rexhepi", "Muja", "Gashi", "Hoxha",
    "Peci", "Dushi", "Sopi", "Tahiri", "Osmani", "Halili", "Bunjaku", "Statovci",
  ];

  const patients: Patient[] = firstNames.map((first, i) => ({
    id: uid(),
    clinicId,
    firstName: first,
    lastName: lastNames[i % lastNames.length],
    phone: `+38344${String(100000 + Math.floor(rand() * 899999))}`,
    email: null,
    createdAt: new Date(Date.now() - Math.floor(rand() * 180) * 86400_000).toISOString(),
  }));

  // Generate realistic appointments from 30 days back to 14 days ahead,
  // respecting working hours and never overlapping per dentist.
  const appointments: Appointment[] = [];
  const issues = [
    "Regular checkup and cleaning",
    "Tooth sensitivity when drinking cold water",
    "Chipped front tooth",
    "Pain in lower left molar",
    "Interested in whitening before a wedding",
    "Follow-up after filling",
    "Bleeding gums when brushing",
    "Consultation for braces",
    "Old filling fell out",
    "",
  ];
  const today = toDateString(new Date());
  const nowMinutes = new Date().getHours() * 60 + new Date().getMinutes();

  for (let offset = -30; offset <= 14; offset++) {
    const date = addDays(today, offset);
    const weekday = new Date(date + "T12:00:00").getDay();
    const hours = clinic.workingHours[weekday];
    if (hours.closed) continue;
    if (clinic.holidays.some((h) => h.date === date)) continue;

    for (const dentist of dentists) {
      let cursor = toMinutes(hours.open);
      const close = toMinutes(hours.close);
      while (cursor < close) {
        // random gap between appointments
        if (rand() < 0.45) {
          cursor += 30;
          continue;
        }
        const service = pick(services);
        const duration = Math.ceil(service.durationMinutes / 30) * 30;
        if (cursor + duration > close) break;
        const patient = pick(patients);
        const isPast =
          offset < 0 || (offset === 0 && cursor + duration < nowMinutes);
        const status = isPast
          ? rand() < 0.08
            ? "cancelled"
            : "completed"
          : rand() < 0.05
            ? "cancelled"
            : "confirmed";
        appointments.push({
          id: uid(),
          clinicId,
          patientId: patient.id,
          dentistId: dentist.id,
          serviceId: service.id,
          date,
          startTime: toTimeString(cursor),
          endTime: toTimeString(cursor + duration),
          status,
          issue: pick(issues),
          manageToken: token(),
          source: rand() < 0.7 ? "online" : "admin",
          reminderSentAt: null,
          createdAt: new Date(
            Date.now() + (offset - 2) * 86400_000
          ).toISOString(),
        });
        cursor += duration;
        cursor += rand() < 0.5 ? 30 : 0;
      }
    }
  }

  const reviews: Review[] = [
    {
      id: uid(),
      clinicId,
      name: "Vjosa R.",
      rating: 5,
      text: "Booked online in under a minute, was seen the next day. The clinic is spotless and Dr. Krasniqi explained everything patiently. Best dental experience I've had.",
      treatment: "Dental Implants",
    },
    {
      id: uid(),
      clinicId,
      name: "Leart Z.",
      rating: 5,
      text: "I used to dread the dentist. Here everything felt calm and modern — no waiting, no paperwork, just a text message and done.",
      treatment: "General Checkup",
    },
    {
      id: uid(),
      clinicId,
      name: "Dafina K.",
      rating: 5,
      text: "My teeth whitening results are incredible. The team is professional and the booking reminder by SMS meant I never forgot my appointment.",
      treatment: "Teeth Whitening",
    },
    {
      id: uid(),
      clinicId,
      name: "Ardit S.",
      rating: 5,
      text: "Emergency toothache on a Saturday — they fit me in within two hours. Painless treatment and honest pricing. Highly recommended.",
      treatment: "Emergency Care",
    },
    {
      id: uid(),
      clinicId,
      name: "Elsa M.",
      rating: 5,
      text: "Got braces for my daughter here. Dr. Gashi is wonderful with kids and the whole process was transparent from day one.",
      treatment: "Orthodontics",
    },
    {
      id: uid(),
      clinicId,
      name: "Gentrit S.",
      rating: 5,
      text: "The most organized clinic in Prishtina. You pick your time, confirm by SMS, and they are ready for you when you walk in.",
      treatment: "Dental Filling",
    },
  ];

  return {
    clinics: [clinic],
    services,
    dentists,
    patients,
    appointments,
    users,
    blockedSlots: [],
    reviews,
    bookingSessions: [],
    sentMessages: [],
  };
}
