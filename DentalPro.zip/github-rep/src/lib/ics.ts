import type { Appointment, Clinic, Service } from "./types";

function icsDate(date: string, time: string): string {
  return `${date.replace(/-/g, "")}T${time.replace(":", "")}00`;
}

export function buildIcs(
  appointment: Appointment,
  clinic: Clinic,
  service: Service
): string {
  const uid = `${appointment.id}@dentalpro`;
  const stamp = new Date()
    .toISOString()
    .replace(/[-:]/g, "")
    .replace(/\.\d{3}/, "");
  const location = `${clinic.name}, ${clinic.address}, ${clinic.city}`;
  return [
    "BEGIN:VCALENDAR",
    "VERSION:2.0",
    "PRODID:-//DentalPro//Appointment//EN",
    "CALSCALE:GREGORIAN",
    "METHOD:PUBLISH",
    "BEGIN:VEVENT",
    `UID:${uid}`,
    `DTSTAMP:${stamp}`,
    `DTSTART:${icsDate(appointment.date, appointment.startTime)}`,
    `DTEND:${icsDate(appointment.date, appointment.endTime)}`,
    `SUMMARY:${service.name} — ${clinic.name}`,
    `DESCRIPTION:Appointment at ${clinic.name}. Phone: ${clinic.phone}`,
    `LOCATION:${location}`,
    "STATUS:CONFIRMED",
    "BEGIN:VALARM",
    "TRIGGER:-PT2H",
    "ACTION:DISPLAY",
    `DESCRIPTION:Dental appointment at ${clinic.name}`,
    "END:VALARM",
    "END:VEVENT",
    "END:VCALENDAR",
  ].join("\r\n");
}

export function googleCalendarUrl(
  appointment: Appointment,
  clinic: Clinic,
  service: Service
): string {
  const params = new URLSearchParams({
    action: "TEMPLATE",
    text: `${service.name} — ${clinic.name}`,
    dates: `${icsDate(appointment.date, appointment.startTime)}/${icsDate(appointment.date, appointment.endTime)}`,
    details: `Appointment at ${clinic.name}. Phone: ${clinic.phone}`,
    location: `${clinic.name}, ${clinic.address}, ${clinic.city}`,
  });
  return `https://calendar.google.com/calendar/render?${params.toString()}`;
}
