import { cookies } from "next/headers";
import type { Role } from "./types";

export const SESSION_COOKIE = "dp_session";
const SESSION_TTL_HOURS = 24 * 7;

export interface Session {
  userId: string;
  role: Role;
  clinicId: string | null;
  dentistId: string | null;
  name: string;
  exp: number;
}

function secret(): string {
  return process.env.SESSION_SECRET || "dp-dev-secret-change-in-production";
}

function b64url(buf: ArrayBuffer | Uint8Array): string {
  const bytes = buf instanceof Uint8Array ? buf : new Uint8Array(buf);
  let bin = "";
  for (const b of bytes) bin += String.fromCharCode(b);
  return btoa(bin).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

function b64urlDecode(s: string): string {
  const pad = s.length % 4 === 0 ? "" : "=".repeat(4 - (s.length % 4));
  return atob(s.replace(/-/g, "+").replace(/_/g, "/") + pad);
}

async function sign(payload: string): Promise<string> {
  const key = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(secret()),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"]
  );
  const sig = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(payload));
  return b64url(sig);
}

/** Edge-safe: usable from middleware and node routes alike. */
export async function createSessionToken(
  session: Omit<Session, "exp">
): Promise<string> {
  const full: Session = {
    ...session,
    exp: Date.now() + SESSION_TTL_HOURS * 3600_000,
  };
  const payload = b64url(new TextEncoder().encode(JSON.stringify(full)));
  const sig = await sign(payload);
  return `${payload}.${sig}`;
}

export async function verifySessionToken(token: string): Promise<Session | null> {
  const [payload, sig] = token.split(".");
  if (!payload || !sig) return null;
  const expected = await sign(payload);
  if (sig !== expected) return null;
  try {
    const session = JSON.parse(b64urlDecode(payload)) as Session;
    if (session.exp < Date.now()) return null;
    return session;
  } catch {
    return null;
  }
}

export async function getSession(): Promise<Session | null> {
  const store = await cookies();
  const token = store.get(SESSION_COOKIE)?.value;
  if (!token) return null;
  return verifySessionToken(token);
}

/* ---------- role permissions ---------- */

export type Permission =
  | "appointments" // view + manage appointments, calendar, blocked slots
  | "patients"
  | "services"
  | "staff"
  | "settings"
  | "clinics"; // platform-level clinic management

const ROLE_PERMISSIONS: Record<Role, Permission[]> = {
  super_admin: ["appointments", "patients", "services", "staff", "settings", "clinics"],
  owner: ["appointments", "patients", "services", "staff", "settings"],
  receptionist: ["appointments", "patients"],
  dentist: ["appointments"],
};

export function can(session: Session, permission: Permission): boolean {
  return ROLE_PERMISSIONS[session.role].includes(permission);
}

/** Dentists only see their own schedule; returns dentistId to filter by, or null for all. */
export function dentistFilter(session: Session): string | null {
  return session.role === "dentist" ? session.dentistId : null;
}
