export type Role = "super_admin" | "owner" | "receptionist" | "dentist";

export type AppointmentStatus = "pending" | "confirmed" | "completed" | "cancelled";

/** "HH:mm" 24h format */
export type TimeString = string;
/** "YYYY-MM-DD" */
export type DateString = string;

export interface DayHours {
  closed: boolean;
  open: TimeString;
  close: TimeString;
}

/** Index 0 = Sunday … 6 = Saturday */
export type WeekHours = DayHours[];

export interface Holiday {
  date: DateString;
  name: string;
}

export interface ClinicStats {
  yearsExperience: number;
  happyPatients: number;
  certifiedDentists: number;
}

export interface SmsTemplates {
  confirmation: string;
  reminder: string;
}

export interface Clinic {
  id: string;
  slug: string;
  name: string;
  tagline: string;
  logoUrl: string | null;
  primaryColor: string;
  heroHeadline: string;
  heroSubheadline: string;
  aboutText: string;
  patientInstructions: string;
  address: string;
  city: string;
  phone: string;
  emergencyPhone: string;
  email: string;
  mapsEmbedUrl: string;
  socials: { facebook: string; instagram: string; tiktok: string };
  stats: ClinicStats;
  workingHours: WeekHours;
  holidays: Holiday[];
  slotStepMinutes: number;
  minLeadMinutes: number;
  maxAdvanceDays: number;
  smsTemplates: SmsTemplates;
  timezone: string;
  published: boolean;
  createdAt: string;
}

export interface Service {
  id: string;
  clinicId: string;
  name: string;
  description: string;
  durationMinutes: number;
  price: number | null;
  icon: string;
  active: boolean;
  sortOrder: number;
}

export interface Dentist {
  id: string;
  clinicId: string;
  name: string;
  title: string;
  bio: string;
  /** null = inherit clinic hours */
  workingHours: WeekHours | null;
  daysOff: DateString[];
  active: boolean;
}

export interface Patient {
  id: string;
  clinicId: string;
  firstName: string;
  lastName: string;
  phone: string;
  email: string | null;
  createdAt: string;
}

export interface Appointment {
  id: string;
  clinicId: string;
  patientId: string;
  dentistId: string;
  serviceId: string;
  date: DateString;
  startTime: TimeString;
  endTime: TimeString;
  status: AppointmentStatus;
  issue: string;
  manageToken: string;
  source: "online" | "admin";
  reminderSentAt: string | null;
  createdAt: string;
}

export interface User {
  id: string;
  /** null for super_admin */
  clinicId: string | null;
  role: Role;
  name: string;
  email: string;
  passwordHash: string;
  /** set when role === "dentist" */
  dentistId: string | null;
  createdAt: string;
}

export interface BlockedSlot {
  id: string;
  clinicId: string;
  /** null = blocks the whole clinic */
  dentistId: string | null;
  date: DateString;
  startTime: TimeString;
  endTime: TimeString;
  reason: string;
}

export interface Review {
  id: string;
  clinicId: string;
  name: string;
  rating: number;
  text: string;
  treatment: string;
}

export interface BookingPayload {
  serviceId: string;
  dentistId: string | "any";
  date: DateString;
  time: TimeString;
  firstName: string;
  lastName: string;
  phone: string;
  issue: string;
}

export interface BookingSession {
  id: string;
  clinicId: string;
  phone: string;
  payload: BookingPayload;
  /** only set when using the mock SMS provider */
  mockCode: string | null;
  attempts: number;
  expiresAt: number;
  createdAt: number;
}

export interface SentMessage {
  id: string;
  clinicId: string;
  phone: string;
  body: string;
  kind: "otp" | "confirmation" | "reminder" | "update";
  sentAt: string;
}

export interface Database {
  clinics: Clinic[];
  services: Service[];
  dentists: Dentist[];
  patients: Patient[];
  appointments: Appointment[];
  users: User[];
  blockedSlots: BlockedSlot[];
  reviews: Review[];
  bookingSessions: BookingSession[];
  sentMessages: SentMessage[];
}
