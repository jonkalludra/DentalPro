import { NextRequest, NextResponse } from "next/server";
import { can, getSession, verifySessionToken, SESSION_COOKIE, type Permission, type Session } from "./session";
import { clinicById } from "./store";
import type { Clinic } from "./types";

/** Resolve session from an API request cookie. */
export async function apiSession(req: NextRequest): Promise<Session | null> {
  const token = req.cookies.get(SESSION_COOKIE)?.value;
  if (!token) return null;
  return verifySessionToken(token);
}

export interface AdminContext {
  session: Session;
  clinic: Clinic;
}

/**
 * Guard for admin API routes: verifies the session, the permission and
 * resolves the clinic every mutation must be scoped to.
 */
export async function requireAdmin(
  req: NextRequest,
  permission: Permission
): Promise<AdminContext | NextResponse> {
  const session = await apiSession(req);
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  if (!can(session, permission)) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }
  const clinic = session.clinicId ? clinicById(session.clinicId) : undefined;
  if (!clinic) {
    return NextResponse.json({ error: "No clinic selected" }, { status: 400 });
  }
  return { session, clinic };
}

/** Same as requireAdmin but without needing a clinic (platform-level ops). */
export async function requirePlatformAdmin(
  req: NextRequest
): Promise<Session | NextResponse> {
  const session = await apiSession(req);
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  if (session.role !== "super_admin") {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }
  return session;
}

/** For server components (pages). Middleware already redirects anonymous users. */
export async function pageSession(): Promise<Session | null> {
  return getSession();
}
