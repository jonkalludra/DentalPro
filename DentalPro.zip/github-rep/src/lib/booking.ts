import type { NextRequest } from "next/server";
import { formatDateLong, formatTime, renderTemplate } from "./utils";
import type { Appointment, Clinic, Dentist, Service } from "./types";

/** Absolute origin for links placed inside SMS messages. */
export function requestOrigin(req: NextRequest): string {
  const proto = req.headers.get("x-forwarded-proto") ?? "http";
  const host = req.headers.get("host") ?? "localhost:3000";
  return `${proto}://${host}`;
}

export function manageUrl(origin: string, slug: string, token: string): string {
  return `${origin}/clinic/${slug}/manage/${token}`;
}

export function confirmationSms(
  clinic: Clinic,
  service: Service,
  dentist: Dentist | undefined,
  appointment: Appointment,
  link: string
): string {
  return renderTemplate(clinic.smsTemplates.confirmation, {
    clinic: clinic.name,
    service: service.name,
    dentist: dentist?.name ?? "",
    date: formatDateLong(appointment.date),
    time: formatTime(appointment.startTime),
    link,
  });
}

export function reminderSms(
  clinic: Clinic,
  service: Service,
  appointment: Appointment
): string {
  return renderTemplate(clinic.smsTemplates.reminder, {
    clinic: clinic.name,
    service: service.name,
    date: formatDateLong(appointment.date),
    time: formatTime(appointment.startTime),
    link: "",
  });
}
