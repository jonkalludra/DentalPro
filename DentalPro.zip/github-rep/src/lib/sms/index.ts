import { db, save, uid } from "../store";
import type { SentMessage } from "../types";

/**
 * SMS provider abstraction.
 * The rest of the app only talks to this interface, so swapping
 * Twilio for another provider (Vonage, MessageBird, a local Kosovar
 * gateway, …) means adding one file and changing one env var.
 */
export interface SmsProvider {
  readonly name: string;
  /** Send a one-time verification code. */
  sendOtp(phone: string): Promise<{ ok: boolean; demoCode?: string; error?: string }>;
  /** Check a code the user entered. */
  checkOtp(phone: string, code: string): Promise<{ ok: boolean; error?: string }>;
  /** Send a plain SMS (confirmations, reminders, updates). */
  sendSms(phone: string, body: string): Promise<{ ok: boolean; error?: string }>;
}

/* ---------- Mock provider (development / demo) ---------- */

interface MockOtp {
  code: string;
  expiresAt: number;
  attempts: number;
}

declare global {
  // eslint-disable-next-line no-var
  var __dentalproOtps: Map<string, MockOtp> | undefined;
}

function otps(): Map<string, MockOtp> {
  if (!globalThis.__dentalproOtps) globalThis.__dentalproOtps = new Map();
  return globalThis.__dentalproOtps;
}

class MockSmsProvider implements SmsProvider {
  readonly name = "mock";

  async sendOtp(phone: string) {
    const code = String(Math.floor(100000 + Math.random() * 900000));
    otps().set(phone, { code, expiresAt: Date.now() + 10 * 60_000, attempts: 0 });
    console.log(`[sms:mock] OTP for ${phone}: ${code}`);
    return { ok: true, demoCode: code };
  }

  async checkOtp(phone: string, code: string) {
    const entry = otps().get(phone);
    if (!entry) return { ok: false, error: "Code expired. Please request a new one." };
    if (Date.now() > entry.expiresAt) {
      otps().delete(phone);
      return { ok: false, error: "Code expired. Please request a new one." };
    }
    entry.attempts += 1;
    if (entry.attempts > 5) {
      otps().delete(phone);
      return { ok: false, error: "Too many attempts. Please request a new code." };
    }
    if (entry.code !== code.trim()) {
      return { ok: false, error: "Incorrect code. Please try again." };
    }
    otps().delete(phone);
    return { ok: true };
  }

  async sendSms(phone: string, body: string) {
    console.log(`[sms:mock] → ${phone}: ${body}`);
    return { ok: true };
  }
}

/* ---------- Twilio provider (production) ---------- */

class TwilioSmsProvider implements SmsProvider {
  readonly name = "twilio";

  private get sid() { return process.env.TWILIO_ACCOUNT_SID!; }
  private get auth() {
    return Buffer.from(
      `${process.env.TWILIO_ACCOUNT_SID}:${process.env.TWILIO_AUTH_TOKEN}`
    ).toString("base64");
  }
  private get verifyService() { return process.env.TWILIO_VERIFY_SERVICE_SID!; }

  async sendOtp(phone: string) {
    const res = await fetch(
      `https://verify.twilio.com/v2/Services/${this.verifyService}/Verifications`,
      {
        method: "POST",
        headers: {
          Authorization: `Basic ${this.auth}`,
          "Content-Type": "application/x-www-form-urlencoded",
        },
        body: new URLSearchParams({ To: phone, Channel: "sms" }),
      }
    );
    if (!res.ok) {
      const body = await res.text();
      console.error("[sms:twilio] sendOtp failed", res.status, body);
      return { ok: false, error: "Could not send the verification code. Please check the phone number." };
    }
    return { ok: true };
  }

  async checkOtp(phone: string, code: string) {
    const res = await fetch(
      `https://verify.twilio.com/v2/Services/${this.verifyService}/VerificationCheck`,
      {
        method: "POST",
        headers: {
          Authorization: `Basic ${this.auth}`,
          "Content-Type": "application/x-www-form-urlencoded",
        },
        body: new URLSearchParams({ To: phone, Code: code.trim() }),
      }
    );
    if (!res.ok) return { ok: false, error: "Incorrect code. Please try again." };
    const data = (await res.json()) as { status?: string };
    return data.status === "approved"
      ? { ok: true }
      : { ok: false, error: "Incorrect code. Please try again." };
  }

  async sendSms(phone: string, body: string) {
    const res = await fetch(
      `https://api.twilio.com/2010-04-01/Accounts/${this.sid}/Messages.json`,
      {
        method: "POST",
        headers: {
          Authorization: `Basic ${this.auth}`,
          "Content-Type": "application/x-www-form-urlencoded",
        },
        body: new URLSearchParams({
          To: phone,
          From: process.env.TWILIO_FROM_NUMBER ?? "",
          Body: body,
        }),
      }
    );
    if (!res.ok) {
      console.error("[sms:twilio] sendSms failed", res.status, await res.text());
      return { ok: false, error: "SMS could not be sent." };
    }
    return { ok: true };
  }
}

/* ---------- provider selection ---------- */

export function smsProvider(): SmsProvider {
  const hasTwilio =
    process.env.TWILIO_ACCOUNT_SID &&
    process.env.TWILIO_AUTH_TOKEN &&
    process.env.TWILIO_VERIFY_SERVICE_SID;
  return hasTwilio ? new TwilioSmsProvider() : new MockSmsProvider();
}

export function isDemoSms(): boolean {
  return smsProvider().name === "mock";
}

/** Send a plain SMS and log it to the clinic's message history. */
export async function sendClinicSms(
  clinicId: string,
  phone: string,
  body: string,
  kind: SentMessage["kind"]
): Promise<boolean> {
  const result = await smsProvider().sendSms(phone, body);
  db().sentMessages.push({
    id: uid(),
    clinicId,
    phone,
    body,
    kind,
    sentAt: new Date().toISOString(),
  });
  save();
  return result.ok;
}
