import { z } from "zod";

const dayHours = z.object({
  closed: z.boolean(),
  open: z.string().regex(/^\d{2}:\d{2}$/),
  close: z.string().regex(/^\d{2}:\d{2}$/),
});

export const serviceSchema = z.object({
  name: z.string().trim().min(2).max(80),
  description: z.string().trim().max(400).optional().default(""),
  durationMinutes: z.number().int().min(5).max(480),
  price: z.number().min(0).max(100000).nullable(),
  icon: z.string().trim().min(1).max(30),
  active: z.boolean(),
});

export const dentistSchema = z.object({
  name: z.string().trim().min(2).max(80),
  title: z.string().trim().max(120).optional().default(""),
  bio: z.string().trim().max(500).optional().default(""),
  workingHours: z.array(dayHours).length(7).nullable(),
  daysOff: z.array(z.string().regex(/^\d{4}-\d{2}-\d{2}$/)).max(200),
  active: z.boolean(),
});
