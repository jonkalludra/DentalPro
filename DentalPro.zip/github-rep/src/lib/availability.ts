import { db } from "./store";
import type {
  Appointment,
  Clinic,
  DateString,
  DayHours,
  Dentist,
  Service,
  TimeString,
} from "./types";
import { addDays, todayString, toMinutes, toTimeString, weekdayOf } from "./utils";

const BLOCKING_STATUSES = new Set(["pending", "confirmed"]);

export interface Slot {
  time: TimeString;
  /** dentists free at this time (used for "no preference" assignment) */
  dentistIds: string[];
}

function effectiveHours(clinic: Clinic, dentist: Dentist, weekday: number): DayHours {
  const hours = dentist.workingHours?.[weekday] ?? clinic.workingHours[weekday];
  const clinicHours = clinic.workingHours[weekday];
  if (clinicHours.closed) return clinicHours;
  return hours;
}

export function isHoliday(clinic: Clinic, date: DateString): boolean {
  return clinic.holidays.some((h) => h.date === date);
}

function overlaps(aStart: number, aEnd: number, bStart: number, bEnd: number): boolean {
  return aStart < bEnd && aEnd > bStart;
}

/** Whether `dentist` is free for [start, start+duration) on `date`. */
function dentistFreeAt(
  clinic: Clinic,
  dentist: Dentist,
  date: DateString,
  startMin: number,
  durationMin: number,
  appointments: Appointment[],
  ignoreAppointmentId?: string
): boolean {
  const weekday = weekdayOf(date);
  const hours = effectiveHours(clinic, dentist, weekday);
  if (hours.closed) return false;
  if (dentist.daysOff.includes(date)) return false;

  const open = toMinutes(hours.open);
  const close = toMinutes(hours.close);
  const endMin = startMin + durationMin;
  if (startMin < open || endMin > close) return false;

  const dayAppointments = appointments.filter(
    (a) =>
      a.dentistId === dentist.id &&
      a.date === date &&
      BLOCKING_STATUSES.has(a.status) &&
      a.id !== ignoreAppointmentId
  );
  for (const a of dayAppointments) {
    if (overlaps(startMin, endMin, toMinutes(a.startTime), toMinutes(a.endTime)))
      return false;
  }

  const blocks = db().blockedSlots.filter(
    (b) =>
      b.clinicId === clinic.id &&
      b.date === date &&
      (b.dentistId === null || b.dentistId === dentist.id)
  );
  for (const b of blocks) {
    if (overlaps(startMin, endMin, toMinutes(b.startTime), toMinutes(b.endTime)))
      return false;
  }

  return true;
}

/** Earliest bookable minute for a given date (lead time applies to today only). */
function minStartFor(clinic: Clinic, date: DateString, ignoreLeadTime?: boolean): number {
  if (date !== todayString()) return 0;
  const now = new Date();
  const current = now.getHours() * 60 + now.getMinutes();
  // Admins can register walk-ins for the current time; patients get a lead buffer.
  return ignoreLeadTime ? current : current + clinic.minLeadMinutes;
}

/**
 * All bookable slots for a service on a date.
 * Enforces: working hours, holidays, past dates, lead time, max advance,
 * per-dentist schedules/days off, existing appointments and blocked slots.
 */
export function slotsForDay(
  clinic: Clinic,
  service: Service,
  dentists: Dentist[],
  date: DateString,
  opts?: { ignoreAppointmentId?: string; ignoreLeadTime?: boolean }
): Slot[] {
  const today = todayString();
  if (date < today) return [];
  if (date > addDays(today, clinic.maxAdvanceDays)) return [];
  if (isHoliday(clinic, date)) return [];

  const weekday = weekdayOf(date);
  const clinicHours = clinic.workingHours[weekday];
  if (clinicHours.closed) return [];

  const appointments = db().appointments.filter(
    (a) => a.clinicId === clinic.id && a.date === date
  );
  const step = clinic.slotStepMinutes;
  const minStart = minStartFor(clinic, date, opts?.ignoreLeadTime);
  const slots: Slot[] = [];

  const earliestOpen = Math.min(
    ...dentists.map((d) => {
      const h = effectiveHours(clinic, d, weekday);
      return h.closed ? Infinity : toMinutes(h.open);
    })
  );
  const latestClose = Math.max(
    ...dentists.map((d) => {
      const h = effectiveHours(clinic, d, weekday);
      return h.closed ? -Infinity : toMinutes(h.close);
    })
  );
  if (!isFinite(earliestOpen) || !isFinite(latestClose)) return [];

  for (let t = earliestOpen; t + service.durationMinutes <= latestClose; t += step) {
    if (t < minStart) continue;
    const free = dentists.filter((d) =>
      dentistFreeAt(
        clinic, d, date, t, service.durationMinutes, appointments,
        opts?.ignoreAppointmentId
      )
    );
    if (free.length > 0) {
      slots.push({ time: toTimeString(t), dentistIds: free.map((d) => d.id) });
    }
  }
  return slots;
}

export interface DaySummary {
  date: DateString;
  slotCount: number;
}

/** Per-day slot counts over a range — used by the booking date picker. */
export function daySummaries(
  clinic: Clinic,
  service: Service,
  dentists: Dentist[],
  from: DateString,
  days: number
): DaySummary[] {
  const out: DaySummary[] = [];
  for (let i = 0; i < days; i++) {
    const date = addDays(from, i);
    out.push({ date, slotCount: slotsForDay(clinic, service, dentists, date).length });
  }
  return out;
}

/**
 * Validate a requested slot and pick the dentist.
 * Returns the assigned dentistId, or null when the slot is not available.
 */
export function resolveSlot(
  clinic: Clinic,
  service: Service,
  candidates: Dentist[],
  date: DateString,
  time: TimeString,
  opts?: { ignoreAppointmentId?: string; ignoreLeadTime?: boolean }
): string | null {
  const slots = slotsForDay(clinic, service, candidates, date, opts);
  const slot = slots.find((s) => s.time === time);
  if (!slot) return null;
  // Balance load: among free dentists pick the one with fewest appointments that day.
  const counts = new Map<string, number>();
  for (const a of db().appointments) {
    if (a.clinicId === clinic.id && a.date === date && BLOCKING_STATUSES.has(a.status)) {
      counts.set(a.dentistId, (counts.get(a.dentistId) ?? 0) + 1);
    }
  }
  return [...slot.dentistIds].sort(
    (a, b) => (counts.get(a) ?? 0) - (counts.get(b) ?? 0)
  )[0];
}
