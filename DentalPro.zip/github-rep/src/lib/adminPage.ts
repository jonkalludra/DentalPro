import { redirect } from "next/navigation";
import { getSession, type Session } from "./session";
import { clinicById } from "./store";
import type { Clinic } from "./types";

/** Server-component guard: resolves the session + selected clinic or redirects. */
export async function requireClinicPage(): Promise<{
  session: Session;
  clinic: Clinic;
}> {
  const session = await getSession();
  if (!session) redirect("/admin/login");
  const clinic = session.clinicId ? clinicById(session.clinicId) : undefined;
  if (!clinic) {
    redirect(session.role === "super_admin" ? "/admin/clinics" : "/admin/login");
  }
  return { session, clinic };
}
