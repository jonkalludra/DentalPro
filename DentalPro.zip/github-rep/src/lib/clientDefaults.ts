import type { WeekHours } from "./types";

/** Client-safe defaults (store.ts is server-only because it touches fs). */
export const DEFAULT_WEEK_HOURS: WeekHours = [
  { closed: true, open: "09:00", close: "14:00" }, // Sun
  { closed: false, open: "09:00", close: "17:00" },
  { closed: false, open: "09:00", close: "17:00" },
  { closed: false, open: "09:00", close: "17:00" },
  { closed: false, open: "09:00", close: "17:00" },
  { closed: false, open: "09:00", close: "17:00" },
  { closed: false, open: "09:00", close: "14:00" }, // Sat
];

export const SMS_PLACEHOLDERS = [
  { token: "{clinic}", label: "Clinic name" },
  { token: "{service}", label: "Service name" },
  { token: "{dentist}", label: "Dentist name" },
  { token: "{date}", label: "Appointment date" },
  { token: "{time}", label: "Appointment time" },
  { token: "{link}", label: "Manage-booking link" },
];
