import { DottedSurface } from "@/components/effects/DottedSurface";
import { LogoMark } from "@/components/icons";
import { MapPin, Phone } from "lucide-react";
import Link from "next/link";

function FacebookIcon({ size = 17 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor">
      <path d="M13.5 21v-7h2.4l.4-3h-2.8V9.1c0-.9.3-1.5 1.6-1.5h1.3V4.9c-.3 0-1.1-.1-2-.1-2 0-3.4 1.2-3.4 3.5V11H8.5v3H11v7h2.5z" />
    </svg>
  );
}

function InstagramIcon({ size = 17 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round">
      <rect x="3.5" y="3.5" width="17" height="17" rx="4.5" />
      <circle cx="12" cy="12" r="3.8" />
      <circle cx="17.2" cy="6.8" r="0.9" fill="currentColor" stroke="none" />
    </svg>
  );
}

function TikTokIcon({ size = 17 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor">
      <path d="M16.6 3c.4 2 1.7 3.4 3.9 3.6v2.7c-1.5 0-2.8-.4-3.9-1.2v5.6c0 3.4-2.4 5.8-5.6 5.8-3.1 0-5.5-2.3-5.5-5.4 0-3 2.3-5.3 5.4-5.3.3 0 .7 0 1 .1v2.8c-.3-.1-.7-.2-1-.2-1.6 0-2.7 1.2-2.7 2.7 0 1.6 1.2 2.7 2.8 2.7 1.7 0 2.9-1.2 2.9-3.1V3h2.7z" />
    </svg>
  );
}

export function Footer({
  base,
  name,
  tagline,
  address,
  city,
  phone,
  socials,
  services,
}: {
  base: string;
  name: string;
  tagline: string;
  address: string;
  city: string;
  phone: string;
  socials: { facebook: string; instagram: string; tiktok: string };
  services: { id: string; name: string }[];
}) {
  return (
    <footer className="relative overflow-hidden bg-[#0a1120] text-white">
      <DottedSurface variant="dark" className="opacity-80" />
      <div className="relative z-10 mx-auto max-w-6xl px-5 sm:px-6 py-16">
        <div className="grid gap-12 md:grid-cols-[1.4fr_1fr_1fr_1.2fr]">
          <div>
            <div className="flex items-center gap-2.5">
              <LogoMark size={38} />
              <span className="font-display text-lg font-extrabold tracking-tight">
                {name}
              </span>
            </div>
            <p className="mt-4 max-w-xs text-[15px] leading-relaxed text-white/55">
              {tagline}
            </p>
            <div className="mt-5 flex gap-2.5">
              {socials.facebook && (
                <a
                  href={socials.facebook}
                  target="_blank"
                  rel="noreferrer"
                  aria-label="Facebook"
                  className="flex h-10 w-10 items-center justify-center rounded-full bg-white/8 border border-white/10 text-white/70 transition hover:bg-brand hover:text-white hover:border-brand"
                >
                  <FacebookIcon />
                </a>
              )}
              {socials.instagram && (
                <a
                  href={socials.instagram}
                  target="_blank"
                  rel="noreferrer"
                  aria-label="Instagram"
                  className="flex h-10 w-10 items-center justify-center rounded-full bg-white/8 border border-white/10 text-white/70 transition hover:bg-brand hover:text-white hover:border-brand"
                >
                  <InstagramIcon />
                </a>
              )}
              {socials.tiktok && (
                <a
                  href={socials.tiktok}
                  target="_blank"
                  rel="noreferrer"
                  aria-label="TikTok"
                  className="flex h-10 w-10 items-center justify-center rounded-full bg-white/8 border border-white/10 text-white/70 transition hover:bg-brand hover:text-white hover:border-brand"
                >
                  <TikTokIcon />
                </a>
              )}
            </div>
          </div>

          <div>
            <p className="text-[13px] font-bold uppercase tracking-[0.15em] text-white/40">
              Quick Links
            </p>
            <ul className="mt-4 space-y-2.5 text-[15px]">
              {[
                { label: "Home", href: base || "/" },
                { label: "Services", href: `${base}#services` },
                { label: "About", href: `${base}#about` },
                { label: "Reviews", href: `${base}#reviews` },
                { label: "Book Appointment", href: `${base}/book` },
              ].map((l) => (
                <li key={l.label}>
                  <Link href={l.href} className="text-white/65 transition hover:text-white">
                    {l.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <p className="text-[13px] font-bold uppercase tracking-[0.15em] text-white/40">
              Services
            </p>
            <ul className="mt-4 space-y-2.5 text-[15px]">
              {services.slice(0, 5).map((s) => (
                <li key={s.id}>
                  <Link
                    href={`${base}/book?service=${s.id}`}
                    className="text-white/65 transition hover:text-white"
                  >
                    {s.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <p className="text-[13px] font-bold uppercase tracking-[0.15em] text-white/40">
              Contact
            </p>
            <ul className="mt-4 space-y-3.5 text-[15px]">
              <li className="flex items-start gap-3 text-white/65">
                <MapPin size={17} className="mt-0.5 shrink-0 text-brand" />
                {address}, {city}
              </li>
              <li>
                <a
                  href={`tel:${phone.replace(/\s/g, "")}`}
                  className="flex items-center gap-3 text-white/65 transition hover:text-white"
                >
                  <Phone size={17} className="shrink-0 text-brand" />
                  {phone}
                </a>
              </li>
            </ul>
            <Link
              href={`${base}/book`}
              className="btn-liquid mt-6 inline-flex h-11 items-center rounded-full px-6 text-sm font-semibold"
            >
              Book Appointment
            </Link>
          </div>
        </div>

        <div className="mt-14 flex flex-col sm:flex-row items-center justify-between gap-3 border-t border-white/10 pt-7 text-[13px] text-white/40">
          <p>
            © {new Date().getFullYear()} {name}. All rights reserved.
          </p>
          <p>
            Powered by <span className="font-semibold text-white/60">DentalPro</span>
          </p>
        </div>
      </div>
    </footer>
  );
}
