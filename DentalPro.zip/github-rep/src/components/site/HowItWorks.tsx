"use client";

import { Reveal } from "@/components/ui";
import { CalendarClock, MessageSquareText, Smile } from "lucide-react";

const STEPS = [
  {
    icon: CalendarClock,
    title: "Pick a time",
    text: "Choose your service and a slot that fits your day.",
  },
  {
    icon: MessageSquareText,
    title: "Confirm by SMS",
    text: "Enter the 6-digit code we text you. No account, no passwords.",
  },
  {
    icon: Smile,
    title: "Show up smiling",
    text: "That's it — we'll send a reminder the day before.",
  },
];

export function HowItWorks() {
  return (
    <section className="py-14 sm:py-20">
      <div className="mx-auto max-w-6xl px-5 sm:px-6">
        <div className="grid gap-4 sm:grid-cols-3">
          {STEPS.map((step, i) => (
            <Reveal key={step.title} delay={i * 0.08}>
              <div className="relative flex items-start gap-4 rounded-3xl border border-line/70 bg-white p-6 shadow-[0_8px_30px_rgba(11,21,38,0.04)] h-full">
                <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-brand-soft text-brand">
                  <step.icon size={22} />
                </span>
                <div>
                  <p className="font-display font-bold text-ink">
                    <span className="text-brand mr-1.5">{i + 1}.</span>
                    {step.title}
                  </p>
                  <p className="mt-1 text-[14px] leading-relaxed text-ink-soft">
                    {step.text}
                  </p>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
