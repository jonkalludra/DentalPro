"use client";

import { AnimatePresence, motion } from "framer-motion";
import { CalendarCheck2, Phone } from "lucide-react";
import Link from "next/link";
import { useEffect, useState } from "react";

export function MobileCta({ base, phone }: { base: string; phone: string }) {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const onScroll = () => setVisible(window.scrollY > 420);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          initial={{ y: 90, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 90, opacity: 0 }}
          transition={{ type: "spring", duration: 0.5, bounce: 0.2 }}
          className="fixed inset-x-4 bottom-4 z-40 sm:hidden"
        >
          <div className="glass-deep flex items-center gap-2 rounded-full p-2">
            <a
              href={`tel:${phone.replace(/\s/g, "")}`}
              className="btn-glass flex h-12 w-12 items-center justify-center rounded-full"
              aria-label="Call clinic"
            >
              <Phone size={19} className="text-brand" />
            </a>
            <Link
              href={`${base}/book`}
              className="btn-liquid flex h-12 flex-1 items-center justify-center gap-2 rounded-full text-[15px] font-semibold"
            >
              <CalendarCheck2 size={18} />
              Book Appointment
            </Link>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
