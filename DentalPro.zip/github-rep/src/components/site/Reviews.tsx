"use client";

import { Reveal } from "@/components/ui";
import { AnimatePresence, motion } from "framer-motion";
import { ChevronLeft, ChevronRight, Quote, Star } from "lucide-react";
import { useCallback, useEffect, useState } from "react";

export interface ReviewItem {
  id: string;
  name: string;
  rating: number;
  text: string;
  treatment: string;
}

export function Reviews({ reviews }: { reviews: ReviewItem[] }) {
  const [[index, direction], setIndex] = useState<[number, number]>([0, 0]);
  const [paused, setPaused] = useState(false);

  const go = useCallback(
    (dir: number) => {
      setIndex(([i]) => [(i + dir + reviews.length) % reviews.length, dir]);
    },
    [reviews.length]
  );

  useEffect(() => {
    if (paused || reviews.length <= 1) return;
    const t = setInterval(() => go(1), 5200);
    return () => clearInterval(t);
  }, [go, paused, reviews.length]);

  if (reviews.length === 0) return null;
  const review = reviews[index];

  return (
    <section id="reviews" className="scroll-mt-24 bg-mist py-20 sm:py-28 overflow-hidden">
      <div className="mx-auto max-w-4xl px-5 sm:px-6">
        <Reveal className="text-center">
          <p className="text-[13px] font-bold uppercase tracking-[0.18em] text-brand">
            Patient Reviews
          </p>
          <h2 className="font-display mt-3 text-3xl sm:text-5xl font-extrabold tracking-[-0.02em] text-ink text-balance">
            Loved by our patients
          </h2>
        </Reveal>

        <Reveal delay={0.1}>
          <div
            className="relative mt-12"
            onMouseEnter={() => setPaused(true)}
            onMouseLeave={() => setPaused(false)}
          >
            <div className="relative min-h-[300px] sm:min-h-[260px]">
              <AnimatePresence initial={false} custom={direction} mode="popLayout">
                <motion.figure
                  key={review.id}
                  custom={direction}
                  initial={{ opacity: 0, x: direction >= 0 ? 80 : -80, scale: 0.97 }}
                  animate={{ opacity: 1, x: 0, scale: 1 }}
                  exit={{ opacity: 0, x: direction >= 0 ? -80 : 80, scale: 0.97 }}
                  transition={{ type: "spring", duration: 0.6, bounce: 0.15 }}
                  className="glass-deep relative rounded-[2rem] p-8 sm:p-10"
                >
                  <Quote
                    size={44}
                    className="absolute right-8 top-8 text-brand opacity-15"
                    strokeWidth={1.5}
                  />
                  <div className="flex items-center gap-1">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        size={17}
                        className={
                          i < review.rating
                            ? "text-amber-400 fill-amber-400"
                            : "text-line fill-line"
                        }
                      />
                    ))}
                  </div>
                  <blockquote className="mt-4 text-lg sm:text-xl leading-relaxed text-ink">
                    “{review.text}”
                  </blockquote>
                  <figcaption className="mt-6 flex items-center gap-3">
                    <span
                      className="flex h-11 w-11 items-center justify-center rounded-full text-sm font-bold text-white"
                      style={{
                        background:
                          "linear-gradient(145deg, color-mix(in srgb, var(--brand) 75%, white), var(--brand-dark))",
                      }}
                    >
                      {review.name[0]}
                    </span>
                    <div>
                      <p className="font-semibold text-ink">{review.name}</p>
                      <p className="text-[13px] text-ink-faint">{review.treatment}</p>
                    </div>
                  </figcaption>
                </motion.figure>
              </AnimatePresence>
            </div>

            <div className="mt-7 flex items-center justify-center gap-4">
              <button
                onClick={() => go(-1)}
                className="btn-glass flex h-11 w-11 items-center justify-center rounded-full"
                aria-label="Previous review"
              >
                <ChevronLeft size={18} />
              </button>
              <div className="flex items-center gap-2">
                {reviews.map((r, i) => (
                  <button
                    key={r.id}
                    onClick={() => setIndex([i, i > index ? 1 : -1])}
                    aria-label={`Review ${i + 1}`}
                    className="rounded-full transition-all duration-300"
                    style={{
                      width: i === index ? 22 : 8,
                      height: 8,
                      background:
                        i === index ? "var(--brand)" : "rgba(11,21,38,.15)",
                    }}
                  />
                ))}
              </div>
              <button
                onClick={() => go(1)}
                className="btn-glass flex h-11 w-11 items-center justify-center rounded-full"
                aria-label="Next review"
              >
                <ChevronRight size={18} />
              </button>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
