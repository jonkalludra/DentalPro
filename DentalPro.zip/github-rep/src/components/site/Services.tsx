"use client";

import { ServiceIcon } from "@/components/icons";
import { Reveal } from "@/components/ui";
import { motion } from "framer-motion";
import { ArrowRight, Clock } from "lucide-react";
import Link from "next/link";

export interface ServiceCard {
  id: string;
  name: string;
  description: string;
  durationMinutes: number;
  price: number | null;
  icon: string;
}

export function Services({
  base,
  services,
}: {
  base: string;
  services: ServiceCard[];
}) {
  return (
    <section id="services" className="scroll-mt-24 bg-mist py-20 sm:py-28">
      <div className="mx-auto max-w-6xl px-5 sm:px-6">
        <Reveal className="text-center">
          <p className="text-[13px] font-bold uppercase tracking-[0.18em] text-brand">
            Our Services
          </p>
          <h2 className="font-display mt-3 text-3xl sm:text-5xl font-extrabold tracking-[-0.02em] text-ink text-balance">
            Everything your smile needs
          </h2>
          <p className="mx-auto mt-4 max-w-xl text-lg text-ink-soft">
            From routine checkups to complete smile makeovers — all under one roof,
            with transparent pricing.
          </p>
        </Reveal>

        <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {services.map((service, i) => (
            <Reveal key={service.id} delay={Math.min(i * 0.06, 0.3)}>
              <motion.div
                whileHover={{ y: -6 }}
                transition={{ type: "spring", stiffness: 300, damping: 22 }}
                className="group h-full rounded-3xl border border-line/70 bg-white p-7 shadow-[0_8px_30px_rgba(11,21,38,0.05)] transition-shadow hover:shadow-[0_18px_50px_rgba(11,21,38,0.1)]"
              >
                <div className="flex items-start justify-between">
                  <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-brand-soft text-brand transition-colors duration-300 group-hover:bg-brand group-hover:text-white">
                    <ServiceIcon icon={service.icon} size={28} />
                  </span>
                  {service.price !== null && (
                    <span className="rounded-full bg-mist px-3 py-1 text-[13px] font-bold text-ink">
                      from €{service.price}
                    </span>
                  )}
                </div>
                <h3 className="font-display mt-5 text-xl font-bold text-ink">
                  {service.name}
                </h3>
                <p className="mt-2 text-[15px] leading-relaxed text-ink-soft">
                  {service.description}
                </p>
                <div className="mt-5 flex items-center justify-between">
                  <span className="inline-flex items-center gap-1.5 text-[13px] font-medium text-ink-faint">
                    <Clock size={14} />
                    {service.durationMinutes} min
                  </span>
                  <Link
                    href={`${base}/book?service=${service.id}`}
                    className="inline-flex items-center gap-1 text-sm font-semibold text-brand opacity-0 -translate-x-1 transition-all duration-300 group-hover:opacity-100 group-hover:translate-x-0"
                  >
                    Book <ArrowRight size={15} />
                  </Link>
                </div>
              </motion.div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
