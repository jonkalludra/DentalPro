"use client";

import { Reveal } from "@/components/ui";
import { initials } from "@/lib/utils";
import { animate, motion, useInView } from "framer-motion";
import { Award, HeartHandshake, Sparkles } from "lucide-react";
import { useEffect, useRef, useState } from "react";

function CountUp({ target, suffix = "" }: { target: number; suffix?: string }) {
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true, margin: "-40px" });
  const [value, setValue] = useState(0);

  useEffect(() => {
    if (!inView) return;
    const controls = animate(0, target, {
      duration: 1.6,
      ease: [0.22, 0.8, 0.36, 1],
      onUpdate: (v) => setValue(Math.round(v)),
    });
    return () => controls.stop();
  }, [inView, target]);

  return (
    <span ref={ref}>
      {value.toLocaleString()}
      {suffix}
    </span>
  );
}

export interface AboutDentist {
  id: string;
  name: string;
  title: string;
}

export function About({
  name,
  aboutText,
  stats,
  dentists,
}: {
  name: string;
  aboutText: string;
  stats: { yearsExperience: number; happyPatients: number; certifiedDentists: number };
  dentists: AboutDentist[];
}) {
  return (
    <section id="about" className="scroll-mt-24 py-20 sm:py-28">
      <div className="mx-auto grid max-w-6xl items-center gap-14 px-5 sm:px-6 lg:grid-cols-2">
        <Reveal>
          <p className="text-[13px] font-bold uppercase tracking-[0.18em] text-brand">
            About Us
          </p>
          <h2 className="font-display mt-3 text-3xl sm:text-[44px] leading-[1.1] font-extrabold tracking-[-0.02em] text-ink text-balance">
            A calmer kind of dental care
          </h2>
          <p className="mt-5 text-lg leading-relaxed text-ink-soft">{aboutText}</p>

          <div className="mt-7 space-y-4">
            {[
              {
                icon: Sparkles,
                title: "Modern technology",
                text: "Digital X-rays, 3D imaging and pain-free treatment methods.",
              },
              {
                icon: HeartHandshake,
                title: "Personal approach",
                text: "We listen first. Every treatment plan is explained clearly, with honest pricing.",
              },
              {
                icon: Award,
                title: "Certified specialists",
                text: "Internationally trained dentists in implantology, orthodontics and aesthetics.",
              },
            ].map((item) => (
              <div key={item.title} className="flex gap-4">
                <span className="mt-0.5 flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-brand-soft text-brand">
                  <item.icon size={19} />
                </span>
                <div>
                  <p className="font-semibold text-ink">{item.title}</p>
                  <p className="text-[15px] text-ink-soft">{item.text}</p>
                </div>
              </div>
            ))}
          </div>

          {dentists.length > 0 && (
            <div className="mt-8 flex items-center gap-4">
              <div className="flex -space-x-3">
                {dentists.slice(0, 4).map((d) => (
                  <span
                    key={d.id}
                    title={d.name}
                    className="flex h-11 w-11 items-center justify-center rounded-full border-2 border-white text-[13px] font-bold text-white shadow-md"
                    style={{
                      background:
                        "linear-gradient(145deg, color-mix(in srgb, var(--brand) 75%, white), var(--brand-dark))",
                    }}
                  >
                    {initials(d.name)}
                  </span>
                ))}
              </div>
              <p className="text-sm text-ink-soft">
                <span className="font-semibold text-ink">Meet our team</span>
                <br />
                {dentists.map((d) => d.name.replace(/^Dr\.?\s*/, "Dr. ")).slice(0, 2).join(" · ")}
                {dentists.length > 2 ? " · …" : ""}
              </p>
            </div>
          )}
        </Reveal>

        <Reveal delay={0.12}>
          <div className="relative">
            <div
              aria-hidden
              className="absolute -inset-6 -z-10 rounded-[3rem] opacity-70 blur-2xl"
              style={{ background: "color-mix(in srgb, var(--brand) 8%, white)" }}
            />
            <div className="grid gap-5">
              <motion.div
                whileHover={{ y: -4 }}
                className="rounded-[2rem] border border-line/70 bg-white p-8 shadow-[0_8px_30px_rgba(11,21,38,0.06)]"
              >
                <p className="font-display text-5xl sm:text-6xl font-extrabold tracking-tight text-brand">
                  <CountUp target={stats.yearsExperience} suffix="+" />
                </p>
                <p className="mt-2 font-semibold text-ink">Years of experience</p>
                <p className="text-sm text-ink-faint">
                  Caring for {name.split(" ")[0]} families since day one
                </p>
              </motion.div>
              <div className="grid grid-cols-2 gap-5">
                <motion.div
                  whileHover={{ y: -4 }}
                  className="rounded-[2rem] border border-line/70 bg-white p-7 shadow-[0_8px_30px_rgba(11,21,38,0.06)]"
                >
                  <p className="font-display text-4xl font-extrabold tracking-tight text-ink">
                    <CountUp target={stats.happyPatients} suffix="+" />
                  </p>
                  <p className="mt-2 text-sm font-semibold text-ink-soft">
                    Happy patients
                  </p>
                </motion.div>
                <motion.div
                  whileHover={{ y: -4 }}
                  className="rounded-[2rem] p-7 text-white shadow-[0_18px_50px_color-mix(in_srgb,var(--brand)_35%,transparent)]"
                  style={{
                    background:
                      "linear-gradient(150deg, color-mix(in srgb, var(--brand) 85%, white), var(--brand-dark))",
                  }}
                >
                  <p className="font-display text-4xl font-extrabold tracking-tight">
                    <CountUp target={stats.certifiedDentists} />
                  </p>
                  <p className="mt-2 text-sm font-semibold text-white/85">
                    Certified dentists
                  </p>
                </motion.div>
              </div>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
