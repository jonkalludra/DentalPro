"use client";

import { Reveal } from "@/components/ui";
import type { DayHours } from "@/lib/types";
import { formatTime } from "@/lib/utils";
import { Clock, Mail, MapPin, Phone, Siren } from "lucide-react";

const DAY_LABELS = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
/** Display order Mon → Sun */
const ORDER = [1, 2, 3, 4, 5, 6, 0];

export function Contact({
  address,
  city,
  phone,
  emergencyPhone,
  email,
  mapsEmbedUrl,
  workingHours,
}: {
  address: string;
  city: string;
  phone: string;
  emergencyPhone: string;
  email: string;
  mapsEmbedUrl: string;
  workingHours: DayHours[];
}) {
  const todayWeekday = new Date().getDay();

  return (
    <section id="contact" className="scroll-mt-24 py-20 sm:py-28">
      <div className="mx-auto max-w-6xl px-5 sm:px-6">
        <Reveal className="text-center">
          <p className="text-[13px] font-bold uppercase tracking-[0.18em] text-brand">
            Contact & Location
          </p>
          <h2 className="font-display mt-3 text-3xl sm:text-5xl font-extrabold tracking-[-0.02em] text-ink text-balance">
            Come say hello
          </h2>
        </Reveal>

        <div className="mt-14 grid gap-6 lg:grid-cols-[0.9fr_1.1fr]">
          <Reveal>
            <div className="grid gap-5 h-full">
              <div className="rounded-3xl border border-line/70 bg-white p-7 shadow-[0_8px_30px_rgba(11,21,38,0.05)]">
                <div className="space-y-5">
                  <div className="flex gap-4">
                    <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-brand-soft text-brand">
                      <MapPin size={19} />
                    </span>
                    <div>
                      <p className="text-[13px] font-semibold uppercase tracking-wide text-ink-faint">
                        Address
                      </p>
                      <p className="font-semibold text-ink">
                        {address}, {city}
                      </p>
                    </div>
                  </div>
                  <div className="flex gap-4">
                    <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-brand-soft text-brand">
                      <Phone size={19} />
                    </span>
                    <div>
                      <p className="text-[13px] font-semibold uppercase tracking-wide text-ink-faint">
                        Phone
                      </p>
                      <a
                        href={`tel:${phone.replace(/\s/g, "")}`}
                        className="font-semibold text-ink hover:text-brand transition"
                      >
                        {phone}
                      </a>
                    </div>
                  </div>
                  <div className="flex gap-4">
                    <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-red-50 text-red-500">
                      <Siren size={19} />
                    </span>
                    <div>
                      <p className="text-[13px] font-semibold uppercase tracking-wide text-ink-faint">
                        Emergency (24/7)
                      </p>
                      <a
                        href={`tel:${emergencyPhone.replace(/\s/g, "")}`}
                        className="font-semibold text-ink hover:text-red-500 transition"
                      >
                        {emergencyPhone}
                      </a>
                    </div>
                  </div>
                  {email && (
                    <div className="flex gap-4">
                      <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-brand-soft text-brand">
                        <Mail size={19} />
                      </span>
                      <div>
                        <p className="text-[13px] font-semibold uppercase tracking-wide text-ink-faint">
                          Email
                        </p>
                        <a
                          href={`mailto:${email}`}
                          className="font-semibold text-ink hover:text-brand transition"
                        >
                          {email}
                        </a>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              <div className="rounded-3xl border border-line/70 bg-white p-7 shadow-[0_8px_30px_rgba(11,21,38,0.05)]">
                <div className="flex items-center gap-2.5 mb-4">
                  <Clock size={17} className="text-brand" />
                  <p className="font-display font-bold text-ink">Opening Hours</p>
                </div>
                <div className="space-y-1.5">
                  {ORDER.map((weekday) => {
                    const hours = workingHours[weekday];
                    const isToday = weekday === todayWeekday;
                    return (
                      <div
                        key={weekday}
                        className={`flex items-center justify-between rounded-xl px-3 py-1.5 text-[14px] ${
                          isToday ? "bg-brand-soft font-semibold text-ink" : "text-ink-soft"
                        }`}
                      >
                        <span>
                          {DAY_LABELS[weekday]}
                          {isToday && (
                            <span className="ml-2 text-[11px] font-bold uppercase text-brand">
                              Today
                            </span>
                          )}
                        </span>
                        <span className={hours.closed ? "text-ink-faint" : ""}>
                          {hours.closed
                            ? "Closed"
                            : `${formatTime(hours.open)} – ${formatTime(hours.close)}`}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          </Reveal>

          <Reveal delay={0.1}>
            <div className="h-full min-h-[420px] overflow-hidden rounded-3xl border border-line/70 shadow-[0_8px_30px_rgba(11,21,38,0.05)]">
              <iframe
                src={mapsEmbedUrl}
                className="h-full w-full"
                style={{ border: 0, minHeight: 420 }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                title="Clinic location"
              />
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
