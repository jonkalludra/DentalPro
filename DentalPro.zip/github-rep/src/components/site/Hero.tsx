"use client";

import { ToothIcon, WhiteningIcon } from "@/components/icons";
import { motion } from "framer-motion";
import { BadgeCheck, CalendarCheck2, MessageSquareText, Phone, ShieldCheck, Star } from "lucide-react";
import Link from "next/link";

const ease = [0.21, 0.65, 0.32, 1] as const;

export function Hero({
  base,
  headline,
  subheadline,
  phone,
  patients,
}: {
  base: string;
  headline: string;
  subheadline: string;
  phone: string;
  patients: number;
}) {
  return (
    <section className="relative overflow-hidden pt-32 sm:pt-40 pb-16 sm:pb-24">
      {/* ambient background */}
      <div
        aria-hidden
        className="absolute inset-0 -z-10"
        style={{
          background:
            "radial-gradient(900px 480px at 78% 8%, color-mix(in srgb, var(--brand) 9%, transparent), transparent 65%), radial-gradient(700px 420px at 8% 42%, color-mix(in srgb, var(--brand) 5%, transparent), transparent 60%), linear-gradient(180deg, #ffffff 0%, #f7f9fd 100%)",
        }}
      />
      <div
        aria-hidden
        className="absolute -top-24 right-[-140px] -z-10 h-[420px] w-[420px] rounded-full opacity-60 blur-3xl"
        style={{ background: "color-mix(in srgb, var(--brand) 14%, white)" }}
      />

      <div className="mx-auto grid max-w-6xl items-center gap-14 lg:gap-8 px-5 sm:px-6 lg:grid-cols-[1.05fr_0.95fr]">
        {/* copy */}
        <div className="text-center lg:text-left">
          <motion.div
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, ease }}
            className="inline-flex items-center gap-2 rounded-full border border-brand/15 bg-brand-soft px-4 py-1.5 text-[13px] font-semibold text-brand"
          >
            <BadgeCheck size={15} />
            Trusted by {patients.toLocaleString()}+ patients
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.08, ease }}
            className="font-display mt-5 text-[42px] leading-[1.05] sm:text-6xl lg:text-[64px] font-extrabold tracking-[-0.03em] text-ink text-balance"
          >
            {headline.includes("Smiles") ? (
              <>
                {headline.split("Smiles")[0]}
                <span className="text-brand">Smiles</span>
                {headline.split("Smiles")[1]}
              </>
            ) : (
              headline
            )}
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.16, ease }}
            className="mx-auto lg:mx-0 mt-5 max-w-xl text-lg sm:text-xl leading-relaxed text-ink-soft text-balance"
          >
            {subheadline}
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.24, ease }}
            className="mt-8 flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-3"
          >
            <Link
              href={`${base}/book`}
              className="btn-liquid inline-flex h-[54px] items-center justify-center gap-2 rounded-full px-9 text-[16px] font-semibold w-full sm:w-auto"
            >
              <CalendarCheck2 size={19} />
              Book Appointment
            </Link>
            <a
              href={`tel:${phone.replace(/\s/g, "")}`}
              className="btn-glass inline-flex h-[54px] items-center justify-center gap-2 rounded-full px-8 text-[16px] font-semibold w-full sm:w-auto"
            >
              <Phone size={18} className="text-brand" />
              Call Clinic
            </a>
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="mt-8 flex flex-wrap items-center justify-center lg:justify-start gap-x-6 gap-y-2 text-[13px] font-medium text-ink-faint"
          >
            <span className="inline-flex items-center gap-1.5">
              <ShieldCheck size={15} className="text-emerald-500" /> No account needed
            </span>
            <span className="inline-flex items-center gap-1.5">
              <MessageSquareText size={15} className="text-brand" /> SMS confirmation
            </span>
            <span className="inline-flex items-center gap-1.5">
              <Star size={15} className="text-amber-400 fill-amber-400" /> 5.0 patient rating
            </span>
          </motion.div>
        </div>

        {/* visual composition */}
        <motion.div
          initial={{ opacity: 0, scale: 0.94, y: 30 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          transition={{ duration: 0.9, delay: 0.2, ease }}
          className="relative mx-auto w-full max-w-[440px] lg:max-w-none"
        >
          <div className="relative aspect-[10/11] sm:aspect-square">
            {/* main visual card */}
            <div
              className="absolute inset-4 sm:inset-8 rounded-[2.5rem] overflow-hidden"
              style={{
                background:
                  "linear-gradient(150deg, color-mix(in srgb, var(--brand) 88%, white) 0%, var(--brand) 45%, var(--brand-dark) 100%)",
                boxShadow:
                  "0 30px 80px color-mix(in srgb, var(--brand) 35%, transparent), inset 0 2px 0 rgba(255,255,255,.35)",
              }}
            >
              <div
                aria-hidden
                className="absolute inset-0"
                style={{
                  background:
                    "radial-gradient(340px 340px at 82% 12%, rgba(255,255,255,.28), transparent 60%)",
                }}
              />
              <ToothIcon
                className="absolute -bottom-10 -right-8 text-white/12"
                size={300}
                strokeWidth={1}
              />
              <div className="absolute inset-x-7 top-8 text-white">
                <p className="font-display text-2xl font-bold leading-snug">
                  Your smile,
                  <br />
                  our passion.
                </p>
                <p className="mt-2 text-sm text-white/75">
                  Modern equipment · Gentle care
                </p>
              </div>
            </div>

            {/* floating booking card */}
            <div className="glass-deep animate-float-slow absolute -left-1 sm:left-0 bottom-14 sm:bottom-20 w-[230px] rounded-3xl p-4">
              <div className="flex items-center gap-2.5">
                <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-brand-soft text-brand">
                  <CalendarCheck2 size={17} />
                </span>
                <div>
                  <p className="text-[13px] font-bold text-ink">Appointment booked</p>
                  <p className="text-xs text-ink-faint">in 48 seconds</p>
                </div>
              </div>
              <div className="mt-3 rounded-2xl bg-white/80 border border-line px-3 py-2.5">
                <p className="text-xs font-semibold text-ink">Tomorrow · 10:30 AM</p>
                <p className="text-[11px] text-ink-faint mt-0.5">General Checkup · Dr. Krasniqi</p>
              </div>
              <div className="mt-2.5 flex items-center gap-1.5 text-[11px] font-medium text-emerald-600">
                <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse" />
                Confirmed by SMS
              </div>
            </div>

            {/* floating rating chip */}
            <div className="glass-deep animate-float-slower absolute right-0 sm:right-2 top-16 sm:top-20 rounded-2xl px-4 py-3">
              <div className="flex items-center gap-1">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} size={13} className="text-amber-400 fill-amber-400" />
                ))}
              </div>
              <p className="mt-1 text-xs font-semibold text-ink">
                {patients.toLocaleString()}+ happy patients
              </p>
            </div>

            {/* floating whitening chip */}
            <div className="glass-deep animate-float-slow absolute right-6 sm:right-10 -bottom-1 sm:bottom-4 rounded-2xl px-4 py-3 flex items-center gap-2.5">
              <span className="flex h-8 w-8 items-center justify-center rounded-xl bg-brand-soft text-brand">
                <WhiteningIcon size={18} />
              </span>
              <p className="text-xs font-semibold text-ink leading-tight">
                Pain-free
                <br />
                <span className="text-ink-faint font-medium">modern dentistry</span>
              </p>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
