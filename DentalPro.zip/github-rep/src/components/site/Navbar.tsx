"use client";

import { LogoMark } from "@/components/icons";
import { cn } from "@/lib/utils";
import { AnimatePresence, motion } from "framer-motion";
import { Menu, Phone, X } from "lucide-react";
import Link from "next/link";
import { useEffect, useState } from "react";

const LINKS = [
  { label: "Home", href: "" },
  { label: "Services", href: "#services" },
  { label: "About", href: "#about" },
  { label: "Reviews", href: "#reviews" },
  { label: "Contact", href: "#contact" },
];

export function Navbar({
  base,
  name,
  logoUrl,
  phone,
}: {
  base: string;
  name: string;
  logoUrl: string | null;
  phone: string;
}) {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header className="fixed inset-x-0 top-0 z-40 px-3 sm:px-6 pt-3 sm:pt-4">
      <nav
        className={cn(
          "glass mx-auto flex max-w-6xl items-center justify-between rounded-full pl-4 pr-2 py-2 transition-all duration-300",
          scrolled && "glass-deep shadow-[0_14px_44px_rgba(11,21,38,0.12)]"
        )}
      >
        <Link href={base || "/"} className="flex items-center gap-2.5 min-w-0">
          {logoUrl ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img
              src={logoUrl}
              alt={name}
              className="h-9 w-9 rounded-xl object-cover"
            />
          ) : (
            <LogoMark size={36} />
          )}
          <span className="font-display font-extrabold text-[17px] tracking-tight text-ink truncate">
            {name}
          </span>
        </Link>

        <div className="hidden lg:flex items-center gap-1">
          {LINKS.map((l) => (
            <Link
              key={l.label}
              href={`${base}${l.href}` || "/"}
              className="rounded-full px-4 py-2 text-sm font-medium text-ink-soft transition hover:text-ink hover:bg-white/70"
            >
              {l.label}
            </Link>
          ))}
        </div>

        <div className="flex items-center gap-2">
          <a
            href={`tel:${phone.replace(/\s/g, "")}`}
            className="btn-glass hidden sm:inline-flex items-center gap-2 rounded-full px-4 h-10 text-sm font-semibold"
          >
            <Phone size={15} className="text-brand" />
            <span className="hidden md:inline">{phone}</span>
            <span className="md:hidden">Call</span>
          </a>
          <Link
            href={`${base}/book`}
            className="btn-liquid inline-flex items-center rounded-full px-5 h-10 text-sm font-semibold"
          >
            Book Appointment
          </Link>
          <button
            className="lg:hidden rounded-full p-2.5 text-ink hover:bg-white/70 transition cursor-pointer"
            onClick={() => setOpen(!open)}
            aria-label="Menu"
          >
            {open ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </nav>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: -8, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -8, scale: 0.98 }}
            transition={{ duration: 0.2 }}
            className="glass-deep mx-auto mt-2 max-w-6xl rounded-3xl p-3 lg:hidden"
          >
            {LINKS.map((l) => (
              <Link
                key={l.label}
                href={`${base}${l.href}` || "/"}
                onClick={() => setOpen(false)}
                className="block rounded-2xl px-4 py-3 text-[15px] font-medium text-ink hover:bg-white/70"
              >
                {l.label}
              </Link>
            ))}
            <a
              href={`tel:${phone.replace(/\s/g, "")}`}
              className="block rounded-2xl px-4 py-3 text-[15px] font-medium text-brand"
            >
              Call {phone}
            </a>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
