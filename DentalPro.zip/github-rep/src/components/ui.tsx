"use client";

import { cn } from "@/lib/utils";
import { AnimatePresence, motion } from "framer-motion";
import { X } from "lucide-react";
import type {
  ButtonHTMLAttributes,
  InputHTMLAttributes,
  ReactNode,
  SelectHTMLAttributes,
  TextareaHTMLAttributes,
} from "react";

/* ---------- buttons ---------- */

type ButtonVariant = "liquid" | "glass" | "ghost" | "danger" | "plain";

export function Button({
  variant = "liquid",
  size = "md",
  className,
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: ButtonVariant;
  size?: "sm" | "md" | "lg";
}) {
  return (
    <button
      className={cn(
        "inline-flex items-center justify-center gap-2 font-semibold rounded-full cursor-pointer select-none whitespace-nowrap transition disabled:opacity-45 disabled:pointer-events-none",
        size === "sm" && "text-[13px] px-4 h-9",
        size === "md" && "text-sm px-6 h-11",
        size === "lg" && "text-[15px] px-8 h-[52px]",
        variant === "liquid" && "btn-liquid",
        variant === "glass" && "btn-glass",
        variant === "ghost" &&
          "text-ink-soft hover:text-ink hover:bg-mist active:scale-97",
        variant === "danger" &&
          "bg-red-50 text-red-600 border border-red-100 hover:bg-red-100 active:scale-97",
        variant === "plain" && "bg-ink text-white hover:bg-ink/90 active:scale-97",
        className
      )}
      {...props}
    />
  );
}

/* ---------- form fields ---------- */

const fieldClasses =
  "w-full rounded-2xl border border-line bg-white px-4 py-3 text-[15px] text-ink placeholder:text-ink-faint outline-none transition focus:border-brand focus:ring-4 focus:ring-brand/10";

export function Input({
  className,
  ...props
}: InputHTMLAttributes<HTMLInputElement>) {
  return <input className={cn(fieldClasses, className)} {...props} />;
}

export function Textarea({
  className,
  ...props
}: TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return (
    <textarea
      className={cn(fieldClasses, "resize-none min-h-[110px]", className)}
      {...props}
    />
  );
}

export function Select({
  className,
  children,
  ...props
}: SelectHTMLAttributes<HTMLSelectElement>) {
  return (
    <select className={cn(fieldClasses, "appearance-none cursor-pointer", className)} {...props}>
      {children}
    </select>
  );
}

export function Label({
  children,
  className,
  htmlFor,
}: {
  children: ReactNode;
  className?: string;
  htmlFor?: string;
}) {
  return (
    <label
      htmlFor={htmlFor}
      className={cn("block text-[13px] font-semibold text-ink-soft mb-1.5", className)}
    >
      {children}
    </label>
  );
}

/* ---------- badge ---------- */

const badgeStyles: Record<string, string> = {
  pending: "bg-amber-50 text-amber-700 border-amber-200/70",
  confirmed: "bg-emerald-50 text-emerald-700 border-emerald-200/70",
  completed: "bg-slate-100 text-slate-600 border-slate-200",
  cancelled: "bg-red-50 text-red-600 border-red-200/70",
  blue: "bg-brand-soft text-brand border-brand/15",
  neutral: "bg-mist text-ink-soft border-line",
};

export function Badge({
  tone = "neutral",
  children,
  className,
}: {
  tone?: string;
  children: ReactNode;
  className?: string;
}) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-full border px-2.5 py-0.5 text-xs font-semibold capitalize",
        badgeStyles[tone] ?? badgeStyles.neutral,
        className
      )}
    >
      {children}
    </span>
  );
}

/* ---------- card ---------- */

export function Card({
  children,
  className,
}: {
  children: ReactNode;
  className?: string;
}) {
  return (
    <div
      className={cn(
        "rounded-3xl bg-white border border-line/70 shadow-[0_8px_30px_rgba(11,21,38,0.06)]",
        className
      )}
    >
      {children}
    </div>
  );
}

/* ---------- modal ---------- */

export function Modal({
  open,
  onClose,
  title,
  children,
  wide,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  children: ReactNode;
  wide?: boolean;
}) {
  return (
    <AnimatePresence>
      {open && (
        <motion.div
          className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-6"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
        >
          <div
            className="absolute inset-0 bg-ink/25 backdrop-blur-sm"
            onClick={onClose}
          />
          <motion.div
            initial={{ opacity: 0, y: 24, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 24, scale: 0.98 }}
            transition={{ type: "spring", duration: 0.45, bounce: 0.2 }}
            className={cn(
              "relative w-full glass-deep rounded-t-3xl sm:rounded-3xl p-6 sm:p-7 max-h-[92vh] overflow-y-auto scroll-thin",
              wide ? "sm:max-w-2xl" : "sm:max-w-md"
            )}
          >
            <div className="flex items-center justify-between mb-5">
              <h3 className="font-display text-lg font-bold text-ink">{title}</h3>
              <button
                onClick={onClose}
                className="rounded-full p-2 text-ink-faint hover:bg-mist hover:text-ink transition cursor-pointer"
                aria-label="Close"
              >
                <X size={18} />
              </button>
            </div>
            {children}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

/* ---------- spinner ---------- */

export function Spinner({ className }: { className?: string }) {
  return (
    <span
      className={cn(
        "inline-block h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent",
        className
      )}
      aria-label="Loading"
    />
  );
}

/* ---------- section reveal animation ---------- */

export function Reveal({
  children,
  delay = 0,
  className,
  y = 28,
}: {
  children: ReactNode;
  delay?: number;
  className?: string;
  y?: number;
}) {
  return (
    <motion.div
      className={className}
      initial={{ opacity: 0, y }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-60px" }}
      transition={{ duration: 0.7, delay, ease: [0.21, 0.65, 0.32, 1] }}
    >
      {children}
    </motion.div>
  );
}
