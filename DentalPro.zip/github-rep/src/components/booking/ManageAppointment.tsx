"use client";

import { LogoMark } from "@/components/icons";
import { Badge, Button, Modal, Spinner } from "@/components/ui";
import { addDays, cn, formatDateLong, formatDateShort, formatTime, todayString } from "@/lib/utils";
import { motion } from "framer-motion";
import { CalendarDays, CalendarX2, Clock, Download, MapPin, Phone, RefreshCcw, UserRound } from "lucide-react";
import Link from "next/link";
import { useEffect, useState } from "react";

interface ManagedAppointment {
  id: string;
  date: string;
  startTime: string;
  status: string;
  service: string;
  dentist: string;
  manageable: boolean;
}

export function ManageAppointment({
  slug,
  token,
  clinicName,
  logoUrl,
  clinicPhone,
  address,
  patientFirstName,
  appointment: initial,
  icsUrl,
}: {
  slug: string;
  token: string;
  clinicName: string;
  logoUrl: string | null;
  clinicPhone: string;
  address: string;
  patientFirstName: string;
  appointment: ManagedAppointment;
  icsUrl: string;
}) {
  const base = `/clinic/${slug}`;
  const [appointment, setAppointment] = useState(initial);
  const [reschedule, setReschedule] = useState(false);
  const [cancelConfirm, setCancelConfirm] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  // reschedule state
  const [date, setDate] = useState(appointment.date);
  const [anyDentist, setAnyDentist] = useState(false);
  const [slots, setSlots] = useState<string[]>([]);
  const [slotsLoading, setSlotsLoading] = useState(false);
  const [time, setTime] = useState<string | null>(null);

  const dates = Array.from({ length: 21 }, (_, i) => addDays(todayString(), i));

  useEffect(() => {
    if (!reschedule) return;
    let cancelled = false;
    setSlotsLoading(true);
    setTime(null);
    fetch(
      `/api/public/${slug}/manage/${token}?date=${date}${anyDentist ? "&any=1" : ""}`
    )
      .then((r) => r.json())
      .then((d: { slots?: string[] }) => !cancelled && setSlots(d.slots ?? []))
      .finally(() => !cancelled && setSlotsLoading(false));
    return () => {
      cancelled = true;
    };
  }, [slug, token, date, anyDentist, reschedule]);

  async function doCancel() {
    setBusy(true);
    setError(null);
    try {
      const res = await fetch(`/api/public/${slug}/manage/${token}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "cancel" }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error ?? "Could not cancel. Please call the clinic.");
        return;
      }
      setAppointment((a) => ({ ...a, status: "cancelled", manageable: false }));
      setNotice("Your appointment has been cancelled.");
      setCancelConfirm(false);
    } finally {
      setBusy(false);
    }
  }

  async function doReschedule() {
    if (!time) return;
    setBusy(true);
    setError(null);
    try {
      const res = await fetch(`/api/public/${slug}/manage/${token}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "reschedule", date, time, any: anyDentist }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.message ?? data.error ?? "That slot is no longer free.");
        return;
      }
      setAppointment((a) => ({ ...a, date: data.date, startTime: data.time }));
      setNotice(`Moved to ${data.dateLong} at ${data.timeLabel}.`);
      setReschedule(false);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="min-h-screen bg-mist">
      <header className="fixed inset-x-0 top-0 z-40 px-3 sm:px-6 pt-3">
        <div className="glass-deep mx-auto flex max-w-xl items-center justify-between rounded-full pl-4 pr-4 py-2">
          <Link href={base} className="flex items-center gap-2.5">
            {logoUrl ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={logoUrl} alt="" className="h-8 w-8 rounded-lg object-cover" />
            ) : (
              <LogoMark size={32} />
            )}
            <span className="font-display font-bold text-[15px] text-ink">
              {clinicName}
            </span>
          </Link>
          <a
            href={`tel:${clinicPhone.replace(/\s/g, "")}`}
            className="inline-flex items-center gap-1.5 text-sm font-semibold text-brand"
          >
            <Phone size={15} /> Call
          </a>
        </div>
      </header>

      <main className="mx-auto max-w-xl px-4 pt-24 pb-16">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <h1 className="font-display text-2xl sm:text-3xl font-extrabold tracking-tight text-ink">
            {patientFirstName ? `Hi ${patientFirstName} 👋` : "Your appointment"}
          </h1>
          <p className="mt-1.5 text-[15px] text-ink-soft">
            Here you can review, reschedule or cancel your appointment.
          </p>

          {notice && (
            <div className="mt-5 rounded-2xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm font-medium text-emerald-700">
              {notice}
            </div>
          )}
          {error && (
            <div className="mt-5 rounded-2xl border border-red-100 bg-red-50 px-4 py-3 text-sm font-medium text-red-600">
              {error}
            </div>
          )}

          <div className="mt-6 rounded-[2rem] border border-line/70 bg-white p-7 shadow-[0_8px_30px_rgba(11,21,38,0.06)]">
            <div className="flex items-center justify-between">
              <p className="font-display text-lg font-bold text-ink">{appointment.service}</p>
              <Badge tone={appointment.status}>{appointment.status}</Badge>
            </div>
            <div className="mt-5 space-y-3 text-[15px]">
              <p className="flex items-center gap-3 text-ink">
                <CalendarDays size={17} className="text-brand shrink-0" />
                {formatDateLong(appointment.date)}
              </p>
              <p className="flex items-center gap-3 text-ink">
                <Clock size={17} className="text-brand shrink-0" />
                {formatTime(appointment.startTime)}
              </p>
              {appointment.dentist && (
                <p className="flex items-center gap-3 text-ink">
                  <UserRound size={17} className="text-brand shrink-0" />
                  {appointment.dentist}
                </p>
              )}
              <p className="flex items-center gap-3 text-ink">
                <MapPin size={17} className="text-brand shrink-0" />
                {clinicName}, {address}
              </p>
            </div>

            {appointment.manageable && (
              <div className="mt-7 grid grid-cols-2 gap-2.5">
                <Button variant="glass" onClick={() => setReschedule(true)}>
                  <RefreshCcw size={16} /> Reschedule
                </Button>
                <Button variant="danger" onClick={() => setCancelConfirm(true)}>
                  <CalendarX2 size={16} /> Cancel
                </Button>
              </div>
            )}

            <a
              href={icsUrl}
              className="mt-3 btn-glass inline-flex w-full h-11 items-center justify-center gap-2 rounded-full text-sm font-semibold"
            >
              <Download size={15} /> Add to calendar
            </a>
          </div>

          <p className="mt-5 text-center text-[13px] text-ink-faint">
            Questions? Call us at{" "}
            <a
              href={`tel:${clinicPhone.replace(/\s/g, "")}`}
              className="font-semibold text-brand"
            >
              {clinicPhone}
            </a>
          </p>
        </motion.div>
      </main>

      {/* cancel modal */}
      <Modal
        open={cancelConfirm}
        onClose={() => setCancelConfirm(false)}
        title="Cancel appointment?"
      >
        <p className="text-[15px] text-ink-soft">
          Your {appointment.service} on {formatDateLong(appointment.date)} at{" "}
          {formatTime(appointment.startTime)} will be cancelled. This cannot be undone.
        </p>
        <div className="mt-6 grid grid-cols-2 gap-2.5">
          <Button variant="glass" onClick={() => setCancelConfirm(false)}>
            Keep it
          </Button>
          <Button variant="danger" onClick={doCancel} disabled={busy}>
            {busy ? <Spinner /> : <CalendarX2 size={16} />} Yes, cancel
          </Button>
        </div>
      </Modal>

      {/* reschedule modal */}
      <Modal
        open={reschedule}
        onClose={() => setReschedule(false)}
        title="Pick a new time"
        wide
      >
        <label className="flex items-center gap-2.5 mb-4 cursor-pointer select-none">
          <input
            type="checkbox"
            checked={anyDentist}
            onChange={(e) => setAnyDentist(e.target.checked)}
            className="h-4 w-4 accent-[var(--brand)]"
          />
          <span className="text-sm text-ink-soft">
            Any available dentist (more free slots)
          </span>
        </label>

        <div className="flex gap-2 overflow-x-auto pb-2 scroll-thin">
          {dates.map((d) => (
            <button
              key={d}
              onClick={() => setDate(d)}
              className={cn(
                "shrink-0 rounded-xl border px-3 py-2 text-[13px] font-semibold transition cursor-pointer",
                date === d
                  ? "border-brand bg-brand text-white"
                  : "border-line bg-white text-ink hover:border-brand/40"
              )}
            >
              {formatDateShort(d)}
            </button>
          ))}
        </div>

        <div className="mt-4 min-h-[120px]">
          {slotsLoading ? (
            <div className="flex justify-center py-8">
              <Spinner className="text-brand h-5 w-5" />
            </div>
          ) : slots.length === 0 ? (
            <p className="py-8 text-center text-sm text-ink-faint">
              No free slots this day.
            </p>
          ) : (
            <div className="grid grid-cols-4 gap-2">
              {slots.map((t) => (
                <button
                  key={t}
                  onClick={() => setTime(t)}
                  className={cn(
                    "rounded-xl border px-2 py-2 text-[13px] font-semibold transition cursor-pointer",
                    time === t
                      ? "border-brand bg-brand text-white"
                      : "border-line bg-white text-ink hover:border-brand hover:text-brand"
                  )}
                >
                  {formatTime(t)}
                </button>
              ))}
            </div>
          )}
        </div>

        <Button
          size="lg"
          className="w-full mt-5"
          disabled={!time || busy}
          onClick={doReschedule}
        >
          {busy ? <Spinner /> : <RefreshCcw size={17} />}
          Confirm new time
        </Button>
      </Modal>
    </div>
  );
}
