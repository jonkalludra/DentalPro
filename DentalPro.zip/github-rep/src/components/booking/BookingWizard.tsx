"use client";

import { LogoMark, ServiceIcon } from "@/components/icons";
import { Button, Input, Label, Spinner, Textarea } from "@/components/ui";
import { cn, formatDateLong, formatTime, initials } from "@/lib/utils";
import { AnimatePresence, motion } from "framer-motion";
import {
  ArrowLeft, CalendarPlus, Check, ChevronRight, Clock, Download,
  MapPin, MessageSquareText, Phone, Sparkles, UserRound, X,
} from "lucide-react";
import Link from "next/link";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";

/* ---------- types ---------- */

interface ServiceOption {
  id: string;
  name: string;
  description: string;
  durationMinutes: number;
  price: number | null;
  icon: string;
}

interface DentistOption {
  id: string;
  name: string;
  title: string;
}

interface DaySummary {
  date: string;
  slotCount: number;
}

interface SuccessData {
  appointment: {
    dateLong: string;
    timeLabel: string;
    service: string;
    dentist: string;
    clinicName: string;
    address: string;
    phone: string;
  };
  manageUrl: string;
  icsUrl: string;
  googleCalendarUrl: string;
  smsPreview?: string;
}

const STEPS = ["Service", "Dentist", "Time", "Details", "Verify"];
const ease = [0.21, 0.65, 0.32, 1] as const;

/* ---------- main wizard ---------- */

export function BookingWizard({
  slug,
  clinicName,
  logoUrl,
  phone: clinicPhone,
  address,
  instructions,
  services,
  dentists,
  preselectedServiceId,
}: {
  slug: string;
  clinicName: string;
  logoUrl: string | null;
  phone: string;
  address: string;
  instructions: string;
  services: ServiceOption[];
  dentists: DentistOption[];
  preselectedServiceId: string | null;
}) {
  const base = `/clinic/${slug}`;
  const preselected = services.find((s) => s.id === preselectedServiceId);

  const [step, setStep] = useState(preselected ? 1 : 0);
  const [direction, setDirection] = useState(1);
  const [serviceId, setServiceId] = useState<string | null>(preselected?.id ?? null);
  const [dentistId, setDentistId] = useState<string>("any");
  const [days, setDays] = useState<DaySummary[]>([]);
  const [daysLoading, setDaysLoading] = useState(false);
  const [date, setDate] = useState<string | null>(null);
  const [slots, setSlots] = useState<string[]>([]);
  const [slotsLoading, setSlotsLoading] = useState(false);
  const [time, setTime] = useState<string | null>(null);
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [phone, setPhone] = useState("");
  const [issue, setIssue] = useState("");
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [demoCode, setDemoCode] = useState<string | null>(null);
  const [code, setCode] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<SuccessData | null>(null);

  const service = services.find((s) => s.id === serviceId) ?? null;
  const dentist = dentists.find((d) => d.id === dentistId) ?? null;

  const goTo = useCallback((next: number) => {
    setDirection((prev) => (next > prev ? 1 : -1));
    setError(null);
    setStep(next);
  }, []);

  /* ---- availability fetching ---- */

  useEffect(() => {
    if (!serviceId) return;
    let cancelled = false;
    setDaysLoading(true);
    fetch(
      `/api/public/${slug}/days?serviceId=${serviceId}&dentistId=${dentistId}&count=28`
    )
      .then((r) => r.json())
      .then((data: { days?: DaySummary[] }) => {
        if (cancelled || !data.days) return;
        setDays(data.days);
        const firstOpen = data.days.find((d) => d.slotCount > 0);
        setDate((current) => {
          const stillValid = data.days!.some(
            (d) => d.date === current && d.slotCount > 0
          );
          return stillValid ? current : (firstOpen?.date ?? null);
        });
      })
      .finally(() => !cancelled && setDaysLoading(false));
    return () => {
      cancelled = true;
    };
  }, [slug, serviceId, dentistId]);

  useEffect(() => {
    if (!serviceId || !date) {
      setSlots([]);
      return;
    }
    let cancelled = false;
    setSlotsLoading(true);
    setTime(null);
    fetch(
      `/api/public/${slug}/slots?serviceId=${serviceId}&dentistId=${dentistId}&date=${date}`
    )
      .then((r) => r.json())
      .then((data: { slots?: string[] }) => {
        if (!cancelled) setSlots(data.slots ?? []);
      })
      .finally(() => !cancelled && setSlotsLoading(false));
    return () => {
      cancelled = true;
    };
  }, [slug, serviceId, dentistId, date]);

  /* ---- actions ---- */

  async function startBooking() {
    if (!service || !date || !time) return;
    if (firstName.trim().length < 2 || lastName.trim().length < 2) {
      setError("Please enter your first and last name.");
      return;
    }
    if (phone.replace(/\D/g, "").length < 8) {
      setError("Please enter a valid phone number.");
      return;
    }
    setBusy(true);
    setError(null);
    try {
      const res = await fetch(`/api/public/${slug}/book/start`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          serviceId: service.id,
          dentistId,
          date,
          time,
          firstName: firstName.trim(),
          lastName: lastName.trim(),
          phone: phone.trim(),
          issue: issue.trim(),
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        if (data.error === "slot_taken") {
          setError(data.message);
          goTo(2);
          setDate((d) => d); // triggers slot refetch via time reset below
          setTime(null);
          setSlots([]);
          if (date && serviceId) {
            const r = await fetch(
              `/api/public/${slug}/slots?serviceId=${serviceId}&dentistId=${dentistId}&date=${date}`
            );
            const s = await r.json();
            setSlots(s.slots ?? []);
          }
        } else {
          setError(data.error ?? "Something went wrong. Please try again.");
        }
        return;
      }
      setSessionId(data.sessionId);
      setDemoCode(data.demoCode ?? null);
      setCode("");
      goTo(4);
    } catch {
      setError("Network error. Please try again.");
    } finally {
      setBusy(false);
    }
  }

  const verifyCode = useCallback(
    async (fullCode: string) => {
      if (!sessionId || busy) return;
      setBusy(true);
      setError(null);
      try {
        const res = await fetch(`/api/public/${slug}/book/verify`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ sessionId, code: fullCode }),
        });
        const data = await res.json();
        if (!res.ok) {
          if (data.error === "slot_taken") {
            setError(data.message);
            setSessionId(null);
            goTo(2);
          } else if (data.error === "session_expired") {
            setError(data.message);
            setSessionId(null);
            goTo(3);
          } else {
            setError(data.error ?? "Verification failed.");
            setCode("");
          }
          return;
        }
        setSuccess(data);
        setStep(5);
      } catch {
        setError("Network error. Please try again.");
      } finally {
        setBusy(false);
      }
    },
    [busy, goTo, sessionId, slug]
  );

  /* ---- render ---- */

  if (success) {
    return (
      <SuccessScreen
        base={base}
        data={success}
        instructions={instructions}
      />
    );
  }

  return (
    <div className="min-h-screen bg-mist">
      {/* top bar */}
      <header className="fixed inset-x-0 top-0 z-40 px-3 sm:px-6 pt-3">
        <div className="glass-deep mx-auto flex max-w-3xl items-center justify-between rounded-full pl-4 pr-2 py-2">
          <Link href={base} className="flex items-center gap-2.5 min-w-0">
            {logoUrl ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={logoUrl} alt="" className="h-8 w-8 rounded-lg object-cover" />
            ) : (
              <LogoMark size={32} />
            )}
            <span className="font-display font-bold text-[15px] text-ink truncate">
              {clinicName}
            </span>
          </Link>
          <div className="flex items-center gap-2">
            <span className="hidden sm:inline-flex items-center gap-1.5 text-xs font-semibold text-ink-faint pr-1">
              <Sparkles size={13} className="text-brand" />
              Under a minute
            </span>
            <Link
              href={base}
              aria-label="Close booking"
              className="flex h-9 w-9 items-center justify-center rounded-full text-ink-soft hover:bg-white/80 transition"
            >
              <X size={18} />
            </Link>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-3xl px-4 sm:px-6 pt-24 sm:pt-28 pb-16">
        {/* progress */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            {STEPS.map((label, i) => (
              <div key={label} className="flex flex-1 items-center last:flex-none">
                <button
                  onClick={() => i < step && goTo(i)}
                  disabled={i >= step}
                  className={cn(
                    "flex items-center gap-2",
                    i < step && "cursor-pointer"
                  )}
                >
                  <span
                    className={cn(
                      "flex h-7 w-7 items-center justify-center rounded-full text-xs font-bold transition-all duration-300",
                      i < step
                        ? "bg-brand text-white"
                        : i === step
                          ? "bg-brand text-white ring-4 ring-brand/15"
                          : "bg-white border border-line text-ink-faint"
                    )}
                  >
                    {i < step ? <Check size={13} strokeWidth={3} /> : i + 1}
                  </span>
                  <span
                    className={cn(
                      "hidden sm:block text-[13px] font-semibold",
                      i <= step ? "text-ink" : "text-ink-faint"
                    )}
                  >
                    {label}
                  </span>
                </button>
                {i < STEPS.length - 1 && (
                  <div className="mx-2 sm:mx-3 h-px flex-1 bg-line relative overflow-hidden rounded">
                    <div
                      className="absolute inset-y-0 left-0 bg-brand transition-all duration-500"
                      style={{ width: i < step ? "100%" : "0%" }}
                    />
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {error && (
          <motion.div
            initial={{ opacity: 0, y: -6 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-5 rounded-2xl border border-red-100 bg-red-50 px-4 py-3 text-sm font-medium text-red-600"
          >
            {error}
          </motion.div>
        )}

        <AnimatePresence mode="wait" custom={direction}>
          <motion.div
            key={step}
            custom={direction}
            initial={{ opacity: 0, x: direction * 40 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: direction * -40 }}
            transition={{ duration: 0.35, ease }}
          >
            {/* STEP 0 — service */}
            {step === 0 && (
              <div>
                <StepTitle
                  title="What do you need?"
                  subtitle="Choose a service — you can describe your issue later."
                />
                <div className="grid gap-3 sm:grid-cols-2">
                  {services.map((s) => (
                    <button
                      key={s.id}
                      onClick={() => {
                        setServiceId(s.id);
                        goTo(1);
                      }}
                      className={cn(
                        "group flex items-center gap-4 rounded-3xl border bg-white p-5 text-left transition-all hover:-translate-y-0.5 hover:shadow-[0_12px_36px_rgba(11,21,38,0.09)] cursor-pointer",
                        serviceId === s.id
                          ? "border-brand ring-4 ring-brand/10"
                          : "border-line/70"
                      )}
                    >
                      <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-brand-soft text-brand transition-colors group-hover:bg-brand group-hover:text-white">
                        <ServiceIcon icon={s.icon} size={24} />
                      </span>
                      <span className="min-w-0 flex-1">
                        <span className="block font-semibold text-ink">{s.name}</span>
                        <span className="mt-0.5 flex items-center gap-2 text-[13px] text-ink-faint">
                          <Clock size={12} /> {s.durationMinutes} min
                          {s.price !== null && <span>· from €{s.price}</span>}
                        </span>
                      </span>
                      <ChevronRight
                        size={17}
                        className="text-ink-faint transition group-hover:text-brand group-hover:translate-x-0.5"
                      />
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* STEP 1 — dentist */}
            {step === 1 && (
              <div>
                <StepTitle
                  title="Choose your dentist"
                  subtitle="Or let us match you with the first available."
                />
                <div className="grid gap-3">
                  <DentistCard
                    selected={dentistId === "any"}
                    onClick={() => {
                      setDentistId("any");
                      goTo(2);
                    }}
                    avatar={
                      <span className="flex h-12 w-12 items-center justify-center rounded-full bg-brand-soft text-brand">
                        <UserRound size={22} />
                      </span>
                    }
                    name="No preference"
                    title="First available dentist"
                  />
                  {dentists.map((d) => (
                    <DentistCard
                      key={d.id}
                      selected={dentistId === d.id}
                      onClick={() => {
                        setDentistId(d.id);
                        goTo(2);
                      }}
                      avatar={
                        <span
                          className="flex h-12 w-12 items-center justify-center rounded-full text-sm font-bold text-white"
                          style={{
                            background:
                              "linear-gradient(145deg, color-mix(in srgb, var(--brand) 75%, white), var(--brand-dark))",
                          }}
                        >
                          {initials(d.name)}
                        </span>
                      }
                      name={d.name}
                      title={d.title}
                    />
                  ))}
                </div>
                <BackButton onClick={() => goTo(0)} />
              </div>
            )}

            {/* STEP 2 — date & time */}
            {step === 2 && (
              <div>
                <StepTitle
                  title="Pick a date & time"
                  subtitle={
                    service
                      ? `${service.name} · ${service.durationMinutes} min${dentist ? ` · ${dentist.name}` : ""}`
                      : ""
                  }
                />
                {daysLoading ? (
                  <CenteredSpinner label="Loading availability…" />
                ) : (
                  <>
                    <div className="flex gap-2 overflow-x-auto pb-3 scroll-thin -mx-1 px-1">
                      {days.map((d) => {
                        const dt = new Date(d.date + "T12:00:00");
                        const disabled = d.slotCount === 0;
                        const selected = date === d.date;
                        return (
                          <button
                            key={d.date}
                            disabled={disabled}
                            onClick={() => setDate(d.date)}
                            className={cn(
                              "flex w-[68px] shrink-0 flex-col items-center rounded-2xl border px-2 py-3 transition-all cursor-pointer",
                              selected
                                ? "border-brand bg-brand text-white shadow-[0_8px_20px_color-mix(in_srgb,var(--brand)_35%,transparent)]"
                                : disabled
                                  ? "border-line/60 bg-white/50 text-ink-faint opacity-45 cursor-not-allowed"
                                  : "border-line/70 bg-white text-ink hover:border-brand/40"
                            )}
                          >
                            <span
                              className={cn(
                                "text-[11px] font-semibold uppercase",
                                selected ? "text-white/75" : "text-ink-faint"
                              )}
                            >
                              {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"][dt.getDay()]}
                            </span>
                            <span className="font-display text-xl font-bold mt-0.5">
                              {dt.getDate()}
                            </span>
                            <span
                              className={cn(
                                "text-[10px] font-medium",
                                selected ? "text-white/75" : "text-ink-faint"
                              )}
                            >
                              {["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"][dt.getMonth()]}
                            </span>
                          </button>
                        );
                      })}
                    </div>

                    <div className="mt-5 rounded-3xl border border-line/70 bg-white p-5 min-h-[180px]">
                      {date ? (
                        <>
                          <p className="text-sm font-semibold text-ink-soft mb-4">
                            {formatDateLong(date)}
                          </p>
                          {slotsLoading ? (
                            <CenteredSpinner label="Checking free slots…" />
                          ) : slots.length === 0 ? (
                            <p className="text-sm text-ink-faint py-6 text-center">
                              No free slots this day — please pick another date.
                            </p>
                          ) : (
                            <div className="grid grid-cols-3 sm:grid-cols-5 gap-2">
                              {slots.map((t) => (
                                <button
                                  key={t}
                                  onClick={() => {
                                    setTime(t);
                                    goTo(3);
                                  }}
                                  className={cn(
                                    "rounded-xl border px-2 py-2.5 text-sm font-semibold transition-all cursor-pointer",
                                    time === t
                                      ? "border-brand bg-brand text-white"
                                      : "border-line/80 bg-white text-ink hover:border-brand hover:text-brand hover:-translate-y-0.5"
                                  )}
                                >
                                  {formatTime(t)}
                                </button>
                              ))}
                            </div>
                          )}
                        </>
                      ) : (
                        <p className="text-sm text-ink-faint py-6 text-center">
                          No availability in the next weeks. Please call the clinic:{" "}
                          <a href={`tel:${clinicPhone.replace(/\s/g, "")}`} className="font-semibold text-brand">
                            {clinicPhone}
                          </a>
                        </p>
                      )}
                    </div>
                  </>
                )}
                <BackButton onClick={() => goTo(1)} />
              </div>
            )}

            {/* STEP 3 — details */}
            {step === 3 && service && date && time && (
              <div>
                <StepTitle
                  title="Almost there"
                  subtitle="Tell us who you are — no account needed."
                />
                <div className="rounded-3xl border border-brand/20 bg-brand-soft px-5 py-4 mb-5 flex flex-wrap items-center gap-x-6 gap-y-1 text-sm">
                  <span className="font-semibold text-ink">{service.name}</span>
                  <span className="text-ink-soft">{formatDateLong(date)}</span>
                  <span className="text-ink-soft">{formatTime(time)}</span>
                  <span className="text-ink-soft">
                    {dentist ? dentist.name : "First available dentist"}
                  </span>
                  <button
                    onClick={() => goTo(2)}
                    className="ml-auto text-[13px] font-semibold text-brand hover:underline cursor-pointer"
                  >
                    Change
                  </button>
                </div>

                <div className="rounded-3xl border border-line/70 bg-white p-6 space-y-4">
                  <div className="grid gap-4 sm:grid-cols-2">
                    <div>
                      <Label htmlFor="firstName">First name</Label>
                      <Input
                        id="firstName"
                        placeholder="Arta"
                        value={firstName}
                        onChange={(e) => setFirstName(e.target.value)}
                        autoComplete="given-name"
                      />
                    </div>
                    <div>
                      <Label htmlFor="lastName">Last name</Label>
                      <Input
                        id="lastName"
                        placeholder="Krasniqi"
                        value={lastName}
                        onChange={(e) => setLastName(e.target.value)}
                        autoComplete="family-name"
                      />
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="phone">Phone number</Label>
                    <Input
                      id="phone"
                      type="tel"
                      placeholder="044 123 456"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      autoComplete="tel"
                    />
                    <p className="mt-1.5 text-[12px] text-ink-faint">
                      We'll text a 6-digit code to confirm — nothing else, no spam.
                    </p>
                  </div>
                  <div>
                    <Label htmlFor="issue">
                      Describe your issue{" "}
                      <span className="font-normal text-ink-faint">(optional)</span>
                    </Label>
                    <Textarea
                      id="issue"
                      placeholder="e.g. My lower left tooth hurts when I drink something cold…"
                      value={issue}
                      onChange={(e) => setIssue(e.target.value)}
                      maxLength={600}
                    />
                  </div>
                  <Button
                    size="lg"
                    className="w-full"
                    onClick={startBooking}
                    disabled={busy}
                  >
                    {busy ? <Spinner /> : <MessageSquareText size={18} />}
                    Continue — get SMS code
                  </Button>
                </div>
                <BackButton onClick={() => goTo(2)} />
              </div>
            )}

            {/* STEP 4 — verify */}
            {step === 4 && (
              <div className="mx-auto max-w-md">
                <StepTitle
                  title="Enter your code"
                  subtitle={`We sent a 6-digit code by SMS to ${phone.trim()}.`}
                  center
                />
                {demoCode && (
                  <div className="mb-5 rounded-2xl border border-amber-200 bg-amber-50 px-4 py-3 text-center text-sm text-amber-800">
                    <span className="font-bold">Demo mode</span> — no real SMS sent.
                    Your code: <span className="font-mono font-bold tracking-widest">{demoCode}</span>
                  </div>
                )}
                <div className="rounded-3xl border border-line/70 bg-white p-6">
                  <OtpInput
                    value={code}
                    onChange={setCode}
                    onComplete={verifyCode}
                    disabled={busy}
                  />
                  <Button
                    size="lg"
                    className="w-full mt-5"
                    disabled={code.length !== 6 || busy}
                    onClick={() => verifyCode(code)}
                  >
                    {busy ? <Spinner /> : <Check size={18} />}
                    Confirm appointment
                  </Button>
                  <button
                    onClick={startBooking}
                    disabled={busy}
                    className="mt-4 w-full text-center text-[13px] font-semibold text-brand hover:underline cursor-pointer disabled:opacity-50"
                  >
                    Didn't receive it? Resend code
                  </button>
                </div>
                <BackButton onClick={() => goTo(3)} center />
              </div>
            )}
          </motion.div>
        </AnimatePresence>
      </main>
    </div>
  );
}

/* ---------- pieces ---------- */

function StepTitle({
  title,
  subtitle,
  center,
}: {
  title: string;
  subtitle: string;
  center?: boolean;
}) {
  return (
    <div className={cn("mb-6", center && "text-center")}>
      <h1 className="font-display text-2xl sm:text-[32px] font-extrabold tracking-[-0.02em] text-ink">
        {title}
      </h1>
      <p className="mt-1.5 text-[15px] text-ink-soft">{subtitle}</p>
    </div>
  );
}

function DentistCard({
  selected,
  onClick,
  avatar,
  name,
  title,
}: {
  selected: boolean;
  onClick: () => void;
  avatar: React.ReactNode;
  name: string;
  title: string;
}) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "group flex items-center gap-4 rounded-3xl border bg-white p-5 text-left transition-all hover:-translate-y-0.5 hover:shadow-[0_12px_36px_rgba(11,21,38,0.09)] cursor-pointer",
        selected ? "border-brand ring-4 ring-brand/10" : "border-line/70"
      )}
    >
      {avatar}
      <span className="flex-1 min-w-0">
        <span className="block font-semibold text-ink">{name}</span>
        <span className="block text-[13px] text-ink-faint">{title}</span>
      </span>
      <ChevronRight
        size={17}
        className="text-ink-faint transition group-hover:text-brand group-hover:translate-x-0.5"
      />
    </button>
  );
}

function BackButton({ onClick, center }: { onClick: () => void; center?: boolean }) {
  return (
    <div className={cn("mt-6", center && "text-center")}>
      <button
        onClick={onClick}
        className="inline-flex items-center gap-1.5 text-sm font-semibold text-ink-faint hover:text-ink transition cursor-pointer"
      >
        <ArrowLeft size={15} /> Back
      </button>
    </div>
  );
}

function CenteredSpinner({ label }: { label: string }) {
  return (
    <div className="flex flex-col items-center justify-center gap-3 py-10 text-ink-faint">
      <Spinner className="h-6 w-6 text-brand" />
      <p className="text-sm">{label}</p>
    </div>
  );
}

/* ---------- OTP input ---------- */

function OtpInput({
  value,
  onChange,
  onComplete,
  disabled,
}: {
  value: string;
  onChange: (v: string) => void;
  onComplete: (v: string) => void;
  disabled?: boolean;
}) {
  const refs = useRef<(HTMLInputElement | null)[]>([]);
  const digits = useMemo(() => {
    const arr = value.split("");
    while (arr.length < 6) arr.push("");
    return arr;
  }, [value]);

  function handleChange(index: number, char: string) {
    const clean = char.replace(/\D/g, "");
    if (!clean) return;
    const next = (value.slice(0, index) + clean + value.slice(index + 1)).slice(0, 6);
    onChange(next);
    const target = Math.min(index + clean.length, 5);
    refs.current[target]?.focus();
    if (next.length === 6) onComplete(next);
  }

  function handleKeyDown(index: number, e: React.KeyboardEvent<HTMLInputElement>) {
    if (e.key === "Backspace") {
      e.preventDefault();
      if (digits[index]) {
        onChange(value.slice(0, index) + value.slice(index + 1));
      } else if (index > 0) {
        onChange(value.slice(0, index - 1) + value.slice(index));
        refs.current[index - 1]?.focus();
      }
    }
    if (e.key === "ArrowLeft" && index > 0) refs.current[index - 1]?.focus();
    if (e.key === "ArrowRight" && index < 5) refs.current[index + 1]?.focus();
  }

  function handlePaste(e: React.ClipboardEvent) {
    e.preventDefault();
    const pasted = e.clipboardData.getData("text").replace(/\D/g, "").slice(0, 6);
    if (!pasted) return;
    onChange(pasted);
    refs.current[Math.min(pasted.length, 5)]?.focus();
    if (pasted.length === 6) onComplete(pasted);
  }

  return (
    <div className="flex justify-center gap-2 sm:gap-2.5" onPaste={handlePaste}>
      {digits.map((digit, i) => (
        <input
          key={i}
          ref={(el) => {
            refs.current[i] = el;
          }}
          inputMode="numeric"
          autoComplete={i === 0 ? "one-time-code" : "off"}
          maxLength={1}
          value={digit}
          disabled={disabled}
          autoFocus={i === 0}
          onChange={(e) => handleChange(i, e.target.value)}
          onKeyDown={(e) => handleKeyDown(i, e)}
          className="h-14 w-11 sm:w-12 rounded-2xl border border-line bg-white text-center font-display text-xl font-bold text-ink outline-none transition focus:border-brand focus:ring-4 focus:ring-brand/10 disabled:opacity-50"
        />
      ))}
    </div>
  );
}

/* ---------- success ---------- */

function SuccessScreen({
  base,
  data,
  instructions,
}: {
  base: string;
  data: SuccessData;
  instructions: string;
}) {
  const a = data.appointment;
  return (
    <div className="min-h-screen bg-mist flex items-center justify-center px-4 py-12">
      <motion.div
        initial={{ opacity: 0, y: 24, scale: 0.98 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.5, ease }}
        className="w-full max-w-lg"
      >
        <div className="rounded-[2rem] border border-line/70 bg-white p-8 shadow-[0_18px_60px_rgba(11,21,38,0.1)] text-center">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: "spring", delay: 0.15, duration: 0.6, bounce: 0.4 }}
            className="mx-auto flex h-20 w-20 items-center justify-center rounded-full bg-emerald-50 animate-pulse-ring"
            style={{ ["--brand" as string]: "#10b981" }}
          >
            <span className="flex h-14 w-14 items-center justify-center rounded-full bg-emerald-500 text-white shadow-[0_8px_24px_rgba(16,185,129,0.4)]">
              <Check size={28} strokeWidth={3} />
            </span>
          </motion.div>

          <h1 className="font-display mt-6 text-2xl sm:text-[28px] font-extrabold tracking-tight text-ink">
            Your appointment has been
            <br />
            successfully booked
          </h1>
          <p className="mt-2 text-[15px] text-ink-soft">
            A confirmation SMS is on its way to your phone.
          </p>

          <div className="mt-7 rounded-3xl bg-mist p-5 text-left space-y-3.5">
            <SuccessRow icon={<CalendarPlus size={17} />} label="Date & time">
              <span className="font-semibold">{a.dateLong}</span> · {a.timeLabel}
            </SuccessRow>
            <SuccessRow icon={<Sparkles size={17} />} label="Treatment">
              {a.service} with {a.dentist}
            </SuccessRow>
            <SuccessRow icon={<MapPin size={17} />} label="Where">
              {a.clinicName}, {a.address}
            </SuccessRow>
            <SuccessRow icon={<Phone size={17} />} label="Clinic phone">
              <a
                href={`tel:${a.phone.replace(/\s/g, "")}`}
                className="text-brand font-semibold"
              >
                {a.phone}
              </a>
            </SuccessRow>
          </div>

          {instructions && (
            <p className="mt-4 rounded-2xl border border-brand/15 bg-brand-soft px-4 py-3 text-[13px] text-ink-soft text-left">
              {instructions}
            </p>
          )}

          <div className="mt-6 grid grid-cols-2 gap-2.5">
            <a
              href={data.googleCalendarUrl}
              target="_blank"
              rel="noreferrer"
              className="btn-liquid inline-flex h-11 items-center justify-center gap-2 rounded-full text-sm font-semibold"
            >
              <CalendarPlus size={16} /> Google Calendar
            </a>
            <a
              href={data.icsUrl}
              className="btn-glass inline-flex h-11 items-center justify-center gap-2 rounded-full text-sm font-semibold"
            >
              <Download size={16} /> Apple / .ics
            </a>
          </div>

          <p className="mt-5 text-[12px] leading-relaxed text-ink-faint">
            Need to change something? Use the secure link in your SMS
            to reschedule or cancel — no calls needed.
          </p>

          {data.smsPreview && (
            <div className="mt-4 rounded-2xl border border-amber-200 bg-amber-50 p-4 text-left">
              <p className="text-[11px] font-bold uppercase tracking-wide text-amber-700 mb-1.5">
                Demo mode — SMS that would be sent:
              </p>
              <p className="text-[13px] leading-relaxed text-amber-900 break-words">
                {data.smsPreview}
              </p>
            </div>
          )}

          <Link
            href={base}
            className="mt-6 inline-flex items-center gap-1.5 text-sm font-semibold text-ink-soft hover:text-ink transition"
          >
            <ArrowLeft size={15} /> Back to website
          </Link>
        </div>
      </motion.div>
    </div>
  );
}

function SuccessRow({
  icon,
  label,
  children,
}: {
  icon: React.ReactNode;
  label: string;
  children: React.ReactNode;
}) {
  return (
    <div className="flex items-start gap-3">
      <span className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-white text-brand border border-line/60">
        {icon}
      </span>
      <div className="min-w-0">
        <p className="text-[11px] font-bold uppercase tracking-wide text-ink-faint">
          {label}
        </p>
        <p className="text-[14px] text-ink mt-0.5">{children}</p>
      </div>
    </div>
  );
}
