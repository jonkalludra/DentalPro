import type { SVGProps } from "react";

/**
 * Hand-drawn dental icon set — stroke-based, inherits currentColor,
 * consistent with the light/premium look of the platform.
 */

type IconProps = SVGProps<SVGSVGElement> & { size?: number };

const TOOTH_PATH =
  "M12 4.2c-1.6-1.1-3.4-1.4-4.9-.7C5.2 4.4 4.3 6.2 4.3 8.1c0 2.7.9 4.3 1.4 6.5.4 1.9.7 5.2 2.2 5.2 1.6 0 1.1-3.5 4.1-3.5s2.5 3.5 4.1 3.5c1.5 0 1.8-3.3 2.2-5.2.5-2.2 1.4-3.8 1.4-6.5 0-1.9-.9-3.7-2.8-4.6-1.5-.7-3.3-.4-4.9.7z";

function Base({ size = 24, children, ...props }: IconProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.7}
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      {children}
    </svg>
  );
}

function ToothWithAccent({
  size,
  accent,
  ...props
}: IconProps & { accent: React.ReactNode }) {
  return (
    <Base size={size} {...props}>
      <g transform="translate(-1.4 1.6) scale(0.9)">
        <path d={TOOTH_PATH} />
      </g>
      {accent}
    </Base>
  );
}

export function ToothIcon(props: IconProps) {
  return (
    <Base {...props}>
      <path d={TOOTH_PATH} />
    </Base>
  );
}

export function CheckupIcon(props: IconProps) {
  return (
    <ToothWithAccent
      {...props}
      accent={<path d="M16.5 3.6l1.7 1.7 3-3.2" />}
    />
  );
}

export function WhiteningIcon(props: IconProps) {
  return (
    <ToothWithAccent
      {...props}
      accent={
        <>
          <path d="M18.2 1.6l.7 1.7 1.7.7-1.7.7-.7 1.7-.7-1.7-1.7-.7 1.7-.7z" />
          <path d="M21.2 7.4l.4 1 1 .4-1 .4-.4 1-.4-1-1-.4 1-.4z" />
        </>
      }
    />
  );
}

export function FillingIcon(props: IconProps) {
  return (
    <ToothWithAccent
      {...props}
      accent={<circle cx="9.4" cy="9.6" r="1.8" fill="currentColor" stroke="none" />}
    />
  );
}

export function RootCanalIcon(props: IconProps) {
  return (
    <ToothWithAccent
      {...props}
      accent={<path d="M9.4 6.2v7.4" strokeDasharray="0.5 2.4" />}
    />
  );
}

export function ImplantIcon(props: IconProps) {
  return (
    <Base {...props}>
      <path d="M8.5 3.5h7l-.8 3.4H9.3z" />
      <path d="M9.8 6.9h4.4v7l-2.2 3.4-2.2-3.4z" />
      <path d="M9.8 9.3h4.4M9.8 11.6h4.4M10.6 14h2.8" />
      <path d="M7 20.5h10" />
    </Base>
  );
}

export function BracesIcon(props: IconProps) {
  return (
    <ToothWithAccent
      {...props}
      accent={
        <>
          <path d="M2.5 10.9h19" />
          <rect x="7.6" y="9.3" width="3.4" height="3.2" rx="0.8" />
        </>
      }
    />
  );
}

export function CosmeticIcon(props: IconProps) {
  return (
    <ToothWithAccent
      {...props}
      accent={<path d="M18.5 1.8l.9 2.1 2.1.9-2.1.9-.9 2.1-.9-2.1-2.1-.9 2.1-.9z" />}
    />
  );
}

export function EmergencyIcon(props: IconProps) {
  return (
    <ToothWithAccent
      {...props}
      accent={<path d="M18.7 1.5l-2.4 4h2L16 10l4.3-5h-2l1.6-3.5z" />}
    />
  );
}

export function OtherIcon(props: IconProps) {
  return (
    <ToothWithAccent
      {...props}
      accent={<path d="M18.6 2.4v5.4M15.9 5.1h5.4" />}
    />
  );
}

const SERVICE_ICONS: Record<string, (props: IconProps) => React.ReactElement> = {
  checkup: CheckupIcon,
  whitening: WhiteningIcon,
  filling: FillingIcon,
  "root-canal": RootCanalIcon,
  implant: ImplantIcon,
  braces: BracesIcon,
  cosmetic: CosmeticIcon,
  emergency: EmergencyIcon,
  other: OtherIcon,
};

export const SERVICE_ICON_KEYS = Object.keys(SERVICE_ICONS);

export function ServiceIcon({
  icon,
  ...props
}: IconProps & { icon: string }) {
  const Component = SERVICE_ICONS[icon] ?? ToothIcon;
  return <Component {...props} />;
}

/** Rounded-square logo mark used when a clinic has no uploaded logo. */
export function LogoMark({
  size = 36,
  className,
}: {
  size?: number;
  className?: string;
}) {
  return (
    <span
      className={className}
      style={{
        width: size,
        height: size,
        display: "inline-flex",
        alignItems: "center",
        justifyContent: "center",
        borderRadius: size * 0.3,
        background:
          "linear-gradient(145deg, color-mix(in srgb, var(--brand) 80%, white), var(--brand-dark))",
        color: "#fff",
        boxShadow:
          "0 4px 14px color-mix(in srgb, var(--brand) 35%, transparent), inset 0 1px 0 rgba(255,255,255,.45)",
      }}
    >
      <ToothIcon size={size * 0.58} strokeWidth={2} />
    </span>
  );
}
