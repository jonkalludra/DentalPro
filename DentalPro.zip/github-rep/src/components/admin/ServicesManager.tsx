"use client";

import { SERVICE_ICON_KEYS, ServiceIcon } from "@/components/icons";
import { Badge, Button, Input, Label, Modal, Spinner, Textarea } from "@/components/ui";
import type { Service } from "@/lib/types";
import { cn } from "@/lib/utils";
import { Clock, Pencil, Plus, Trash2 } from "lucide-react";
import { useRouter } from "next/navigation";
import { useState } from "react";

interface Editable {
  id: string | null;
  name: string;
  description: string;
  durationMinutes: number;
  price: number | null;
  icon: string;
  active: boolean;
}

const EMPTY: Editable = {
  id: null,
  name: "",
  description: "",
  durationMinutes: 30,
  price: null,
  icon: "checkup",
  active: true,
};

export function ServicesManager({ services }: { services: Service[] }) {
  const router = useRouter();
  const [editing, setEditing] = useState<Editable | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function submit() {
    if (!editing) return;
    setBusy(true);
    setError(null);
    try {
      const body = {
        name: editing.name,
        description: editing.description,
        durationMinutes: Number(editing.durationMinutes),
        price: editing.price === null || Number.isNaN(editing.price) ? null : Number(editing.price),
        icon: editing.icon,
        active: editing.active,
      };
      const res = await fetch(
        editing.id ? `/api/admin/services/${editing.id}` : "/api/admin/services",
        {
          method: editing.id ? "PATCH" : "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(body),
        }
      );
      const data = await res.json();
      if (!res.ok) {
        setError(data.error ?? "Could not save.");
        return;
      }
      router.refresh();
      setEditing(null);
    } finally {
      setBusy(false);
    }
  }

  async function remove(id: string) {
    setBusy(true);
    setError(null);
    try {
      const res = await fetch(`/api/admin/services/${id}`, { method: "DELETE" });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error ?? "Could not delete.");
        return;
      }
      router.refresh();
      setEditing(null);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div>
      <div className="mb-5 flex justify-end">
        <Button onClick={() => { setError(null); setEditing({ ...EMPTY }); }}>
          <Plus size={16} /> Add service
        </Button>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {services.map((s) => (
          <div
            key={s.id}
            className={cn(
              "rounded-3xl border border-line/70 bg-white p-6 transition",
              !s.active && "opacity-55"
            )}
          >
            <div className="flex items-start justify-between">
              <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-brand-soft text-brand">
                <ServiceIcon icon={s.icon} size={24} />
              </span>
              <div className="flex items-center gap-1.5">
                {!s.active && <Badge tone="neutral">hidden</Badge>}
                <button
                  onClick={() => { setError(null); setEditing({ ...s }); }}
                  className="rounded-full p-2 text-ink-faint hover:bg-brand-soft hover:text-brand transition cursor-pointer"
                  aria-label={`Edit ${s.name}`}
                >
                  <Pencil size={15} />
                </button>
              </div>
            </div>
            <p className="font-display mt-4 font-bold text-ink">{s.name}</p>
            <p className="mt-1 line-clamp-2 text-[13.5px] text-ink-soft">{s.description}</p>
            <div className="mt-4 flex items-center gap-3 text-[13px] font-semibold">
              <span className="inline-flex items-center gap-1.5 text-ink-faint">
                <Clock size={13} /> {s.durationMinutes} min
              </span>
              {s.price !== null && (
                <span className="rounded-full bg-mist px-2.5 py-0.5 text-ink">
                  €{s.price}
                </span>
              )}
            </div>
          </div>
        ))}
      </div>

      <Modal
        open={editing !== null}
        onClose={() => setEditing(null)}
        title={editing?.id ? "Edit service" : "New service"}
        wide
      >
        {editing && (
          <div>
            {error && (
              <div className="mb-4 rounded-2xl border border-red-100 bg-red-50 px-4 py-3 text-sm font-medium text-red-600">
                {error}
              </div>
            )}
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="sm:col-span-2">
                <Label>Name</Label>
                <Input
                  value={editing.name}
                  onChange={(e) => setEditing({ ...editing, name: e.target.value })}
                />
              </div>
              <div className="sm:col-span-2">
                <Label>Description</Label>
                <Textarea
                  className="min-h-[80px]"
                  value={editing.description}
                  onChange={(e) =>
                    setEditing({ ...editing, description: e.target.value })
                  }
                />
              </div>
              <div>
                <Label>Duration (minutes)</Label>
                <Input
                  type="number"
                  min={5}
                  max={480}
                  step={5}
                  value={editing.durationMinutes}
                  onChange={(e) =>
                    setEditing({ ...editing, durationMinutes: Number(e.target.value) })
                  }
                />
              </div>
              <div>
                <Label>
                  Price € <span className="font-normal text-ink-faint">(empty = hidden)</span>
                </Label>
                <Input
                  type="number"
                  min={0}
                  value={editing.price ?? ""}
                  onChange={(e) =>
                    setEditing({
                      ...editing,
                      price: e.target.value === "" ? null : Number(e.target.value),
                    })
                  }
                />
              </div>
              <div className="sm:col-span-2">
                <Label>Icon</Label>
                <div className="flex flex-wrap gap-2">
                  {SERVICE_ICON_KEYS.map((key) => (
                    <button
                      key={key}
                      type="button"
                      onClick={() => setEditing({ ...editing, icon: key })}
                      className={cn(
                        "flex h-11 w-11 items-center justify-center rounded-xl border transition cursor-pointer",
                        editing.icon === key
                          ? "border-brand bg-brand text-white"
                          : "border-line bg-white text-ink-soft hover:border-brand/50"
                      )}
                      aria-label={key}
                    >
                      <ServiceIcon icon={key} size={22} />
                    </button>
                  ))}
                </div>
              </div>
              <label className="flex items-center gap-2.5 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={editing.active}
                  onChange={(e) => setEditing({ ...editing, active: e.target.checked })}
                  className="h-4 w-4 accent-[var(--brand)]"
                />
                <span className="text-sm font-medium text-ink">
                  Visible & bookable online
                </span>
              </label>
            </div>
            <div className="mt-6 flex items-center gap-2.5">
              {editing.id && (
                <Button
                  variant="danger"
                  onClick={() => remove(editing.id!)}
                  disabled={busy}
                >
                  <Trash2 size={15} /> Delete
                </Button>
              )}
              <Button className="flex-1" onClick={submit} disabled={busy || !editing.name}>
                {busy ? <Spinner /> : null}
                {editing.id ? "Save changes" : "Add service"}
              </Button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}
