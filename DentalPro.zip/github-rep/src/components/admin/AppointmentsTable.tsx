"use client";

import type { AppointmentView } from "@/lib/adminData";
import { addDays, cn, formatDateShort, formatTime, todayString } from "@/lib/utils";
import { Badge, Button, Input, Label, Modal, Select, Spinner } from "@/components/ui";
import {
  BellRing, CalendarPlus, ChevronDown, Download, MessageCircleMore,
  Pencil, Phone, Plus, Search, X,
} from "lucide-react";
import { useRouter } from "next/navigation";
import { useEffect, useMemo, useState } from "react";

export interface ServiceRef {
  id: string;
  name: string;
  durationMinutes: number;
}
export interface DentistRef {
  id: string;
  name: string;
}

const STATUS_OPTIONS = ["pending", "confirmed", "completed", "cancelled"] as const;

/* ================= main table ================= */

export function AppointmentsTable({
  appointments,
  services,
  dentists,
  role,
  showFilters = true,
  showNewButton = true,
  emptyLabel = "No appointments found.",
}: {
  appointments: AppointmentView[];
  services: ServiceRef[];
  dentists: DentistRef[];
  role: string;
  showFilters?: boolean;
  showNewButton?: boolean;
  emptyLabel?: string;
}) {
  const router = useRouter();
  const [query, setQuery] = useState("");
  const [status, setStatus] = useState<string>("all");
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");
  const [dentistId, setDentistId] = useState("all");
  const [reschedule, setReschedule] = useState<AppointmentView | null>(null);
  const [createOpen, setCreateOpen] = useState(false);
  const [busyId, setBusyId] = useState<string | null>(null);

  const canEdit = role !== "dentist";

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return appointments.filter((a) => {
      if (q && !`${a.patientName} ${a.patientPhone} ${a.serviceName}`.toLowerCase().includes(q))
        return false;
      if (status !== "all" && a.status !== status) return false;
      if (dentistId !== "all" && a.dentistId !== dentistId) return false;
      if (dateFrom && a.date < dateFrom) return false;
      if (dateTo && a.date > dateTo) return false;
      return true;
    });
  }, [appointments, query, status, dentistId, dateFrom, dateTo]);

  async function updateStatus(a: AppointmentView, next: string) {
    setBusyId(a.id);
    try {
      const notify = next === "cancelled" && a.status !== "cancelled";
      const res = await fetch(`/api/admin/appointments/${a.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "status", status: next, notify }),
      });
      if (res.ok) router.refresh();
    } finally {
      setBusyId(null);
    }
  }

  async function sendReminder(a: AppointmentView) {
    setBusyId(a.id);
    try {
      const res = await fetch(`/api/admin/appointments/${a.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "remind" }),
      });
      if (res.ok) router.refresh();
    } finally {
      setBusyId(null);
    }
  }

  return (
    <div>
      {showFilters && (
        <div className="mb-5 flex flex-wrap items-center gap-2.5">
          <div className="relative flex-1 min-w-[200px]">
            <Search
              size={16}
              className="absolute left-4 top-1/2 -translate-y-1/2 text-ink-faint"
            />
            <Input
              placeholder="Search patient, phone or service…"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="pl-10 h-11 py-0"
            />
          </div>
          <Select
            value={status}
            onChange={(e) => setStatus(e.target.value)}
            className="w-auto h-11 py-0"
          >
            <option value="all">All statuses</option>
            {STATUS_OPTIONS.map((s) => (
              <option key={s} value={s}>
                {s[0].toUpperCase() + s.slice(1)}
              </option>
            ))}
          </Select>
          <Select
            value={dentistId}
            onChange={(e) => setDentistId(e.target.value)}
            className="w-auto h-11 py-0 max-w-[180px]"
          >
            <option value="all">All dentists</option>
            {dentists.map((d) => (
              <option key={d.id} value={d.id}>
                {d.name}
              </option>
            ))}
          </Select>
          <Input
            type="date"
            value={dateFrom}
            onChange={(e) => setDateFrom(e.target.value)}
            className="w-auto h-11 py-0"
            aria-label="From date"
          />
          <Input
            type="date"
            value={dateTo}
            onChange={(e) => setDateTo(e.target.value)}
            className="w-auto h-11 py-0"
            aria-label="To date"
          />
          {(query || status !== "all" || dateFrom || dateTo || dentistId !== "all") && (
            <button
              onClick={() => {
                setQuery("");
                setStatus("all");
                setDateFrom("");
                setDateTo("");
                setDentistId("all");
              }}
              className="inline-flex items-center gap-1 text-[13px] font-semibold text-ink-faint hover:text-ink cursor-pointer"
            >
              <X size={14} /> Clear
            </button>
          )}
          <div className="ml-auto flex items-center gap-2">
            {canEdit && (
              <a
                href="/api/admin/export?type=appointments"
                className="btn-glass inline-flex h-11 items-center gap-2 rounded-full px-5 text-sm font-semibold"
              >
                <Download size={15} /> CSV
              </a>
            )}
            {canEdit && showNewButton && (
              <Button onClick={() => setCreateOpen(true)}>
                <Plus size={16} /> New appointment
              </Button>
            )}
          </div>
        </div>
      )}

      <div className="overflow-hidden rounded-3xl border border-line/70 bg-white">
        {filtered.length === 0 ? (
          <p className="py-14 text-center text-sm text-ink-faint">{emptyLabel}</p>
        ) : (
          <div className="overflow-x-auto scroll-thin">
            <table className="w-full min-w-[820px] text-left text-[14px]">
              <thead>
                <tr className="border-b border-line/70 text-[12px] uppercase tracking-wide text-ink-faint">
                  <th className="px-5 py-3.5 font-bold">When</th>
                  <th className="px-4 py-3.5 font-bold">Patient</th>
                  <th className="px-4 py-3.5 font-bold">Service</th>
                  <th className="px-4 py-3.5 font-bold">Dentist</th>
                  <th className="px-4 py-3.5 font-bold">Status</th>
                  <th className="px-4 py-3.5 font-bold text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((a) => (
                  <tr
                    key={a.id}
                    className="border-b border-line/50 last:border-0 hover:bg-mist/60 transition-colors"
                  >
                    <td className="px-5 py-3.5 whitespace-nowrap">
                      <p className="font-semibold text-ink">{formatDateShort(a.date)}</p>
                      <p className="text-[13px] text-ink-faint">
                        {formatTime(a.startTime)} – {formatTime(a.endTime)}
                      </p>
                    </td>
                    <td className="px-4 py-3.5">
                      <p className="font-semibold text-ink">{a.patientName}</p>
                      <a
                        href={`tel:${a.patientPhone}`}
                        className="inline-flex items-center gap-1 text-[13px] text-ink-faint hover:text-brand"
                      >
                        <Phone size={11} /> {a.patientPhone}
                      </a>
                    </td>
                    <td className="px-4 py-3.5">
                      <p className="text-ink">{a.serviceName}</p>
                      {a.issue && (
                        <p
                          className="mt-0.5 max-w-[220px] truncate text-[12px] text-ink-faint"
                          title={a.issue}
                        >
                          <MessageCircleMore size={11} className="mr-1 inline" />
                          {a.issue}
                        </p>
                      )}
                    </td>
                    <td className="px-4 py-3.5 text-ink-soft whitespace-nowrap">
                      {a.dentistName.replace("Dr. ", "Dr. ")}
                    </td>
                    <td className="px-4 py-3.5">
                      {canEdit ? (
                        <StatusSelect
                          value={a.status}
                          disabled={busyId === a.id}
                          onChange={(s) => updateStatus(a, s)}
                        />
                      ) : (
                        <Badge tone={a.status}>{a.status}</Badge>
                      )}
                    </td>
                    <td className="px-4 py-3.5">
                      <div className="flex items-center justify-end gap-1">
                        {busyId === a.id && <Spinner className="h-3.5 w-3.5 text-brand mr-1" />}
                        {canEdit && (a.status === "confirmed" || a.status === "pending") && (
                          <>
                            <IconAction
                              title="Send SMS reminder now"
                              onClick={() => sendReminder(a)}
                            >
                              <BellRing size={15} />
                            </IconAction>
                            <IconAction
                              title="Reschedule"
                              onClick={() => setReschedule(a)}
                            >
                              <Pencil size={15} />
                            </IconAction>
                          </>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {reschedule && (
        <RescheduleModal
          appointment={reschedule}
          services={services}
          dentists={dentists}
          onClose={() => setReschedule(null)}
        />
      )}
      {createOpen && (
        <NewAppointmentModal
          services={services}
          dentists={dentists}
          onClose={() => setCreateOpen(false)}
        />
      )}
    </div>
  );
}

/* ================= bits ================= */

function IconAction({
  title,
  onClick,
  children,
}: {
  title: string;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      title={title}
      onClick={onClick}
      className="rounded-full p-2 text-ink-faint transition hover:bg-brand-soft hover:text-brand cursor-pointer"
    >
      {children}
    </button>
  );
}

const STATUS_TONES: Record<string, string> = {
  pending: "bg-amber-50 text-amber-700 border-amber-200/80",
  confirmed: "bg-emerald-50 text-emerald-700 border-emerald-200/80",
  completed: "bg-slate-100 text-slate-600 border-slate-200",
  cancelled: "bg-red-50 text-red-600 border-red-200/80",
};

function StatusSelect({
  value,
  onChange,
  disabled,
}: {
  value: string;
  onChange: (v: string) => void;
  disabled?: boolean;
}) {
  return (
    <div className="relative inline-block">
      <select
        value={value}
        disabled={disabled}
        onChange={(e) => onChange(e.target.value)}
        className={cn(
          "appearance-none cursor-pointer rounded-full border py-1 pl-3 pr-7 text-xs font-semibold capitalize outline-none transition disabled:opacity-50",
          STATUS_TONES[value]
        )}
      >
        {STATUS_OPTIONS.map((s) => (
          <option key={s} value={s}>
            {s[0].toUpperCase() + s.slice(1)}
          </option>
        ))}
      </select>
      <ChevronDown
        size={12}
        className="pointer-events-none absolute right-2.5 top-1/2 -translate-y-1/2 opacity-60"
      />
    </div>
  );
}

/* ================= slot picker (shared) ================= */

function SlotPicker({
  serviceId,
  dentistId,
  date,
  ignoreId,
  value,
  onChange,
}: {
  serviceId: string;
  dentistId: string;
  date: string;
  ignoreId?: string;
  value: string | null;
  onChange: (t: string) => void;
}) {
  const [slots, setSlots] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!serviceId || !date) return;
    let cancelled = false;
    setLoading(true);
    const params = new URLSearchParams({ serviceId, dentistId, date });
    if (ignoreId) params.set("ignore", ignoreId);
    fetch(`/api/admin/slots?${params.toString()}`)
      .then((r) => r.json())
      .then((d: { slots?: string[] }) => !cancelled && setSlots(d.slots ?? []))
      .finally(() => !cancelled && setLoading(false));
    return () => {
      cancelled = true;
    };
  }, [serviceId, dentistId, date, ignoreId]);

  if (loading) {
    return (
      <div className="flex justify-center py-6">
        <Spinner className="h-5 w-5 text-brand" />
      </div>
    );
  }
  if (slots.length === 0) {
    return (
      <p className="py-6 text-center text-sm text-ink-faint">
        No free slots this day.
      </p>
    );
  }
  return (
    <div className="grid grid-cols-4 gap-2 max-h-[180px] overflow-y-auto scroll-thin pr-1">
      {slots.map((t) => (
        <button
          key={t}
          type="button"
          onClick={() => onChange(t)}
          className={cn(
            "rounded-xl border px-2 py-2 text-[13px] font-semibold transition cursor-pointer",
            value === t
              ? "border-brand bg-brand text-white"
              : "border-line bg-white text-ink hover:border-brand hover:text-brand"
          )}
        >
          {formatTime(t)}
        </button>
      ))}
    </div>
  );
}

/* ================= reschedule modal ================= */

function RescheduleModal({
  appointment,
  services,
  dentists,
  onClose,
}: {
  appointment: AppointmentView;
  services: ServiceRef[];
  dentists: DentistRef[];
  onClose: () => void;
}) {
  const router = useRouter();
  const [date, setDate] = useState(
    appointment.date >= todayString() ? appointment.date : todayString()
  );
  const [dentistId, setDentistId] = useState(appointment.dentistId);
  const [time, setTime] = useState<string | null>(null);
  const [notify, setNotify] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function submit() {
    if (!time) return;
    setBusy(true);
    setError(null);
    try {
      const res = await fetch(`/api/admin/appointments/${appointment.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "reschedule", date, time, dentistId, notify }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error ?? "Could not reschedule.");
        return;
      }
      router.refresh();
      onClose();
    } finally {
      setBusy(false);
    }
  }

  return (
    <Modal open onClose={onClose} title={`Reschedule — ${appointment.patientName}`} wide>
      {error && (
        <div className="mb-4 rounded-2xl border border-red-100 bg-red-50 px-4 py-3 text-sm font-medium text-red-600">
          {error}
        </div>
      )}
      <div className="grid gap-4 sm:grid-cols-2">
        <div>
          <Label>Date</Label>
          <Input
            type="date"
            min={todayString()}
            max={addDays(todayString(), 120)}
            value={date}
            onChange={(e) => setDate(e.target.value)}
          />
        </div>
        <div>
          <Label>Dentist</Label>
          <Select value={dentistId} onChange={(e) => setDentistId(e.target.value)}>
            <option value="any">First available</option>
            {dentists.map((d) => (
              <option key={d.id} value={d.id}>
                {d.name}
              </option>
            ))}
          </Select>
        </div>
      </div>
      <div className="mt-4">
        <Label>Available times</Label>
        <SlotPicker
          serviceId={appointment.serviceId}
          dentistId={dentistId}
          date={date}
          ignoreId={appointment.id}
          value={time}
          onChange={setTime}
        />
      </div>
      <label className="mt-4 flex items-center gap-2.5 cursor-pointer select-none">
        <input
          type="checkbox"
          checked={notify}
          onChange={(e) => setNotify(e.target.checked)}
          className="h-4 w-4 accent-[var(--brand)]"
        />
        <span className="text-sm text-ink-soft">Notify the patient by SMS</span>
      </label>
      <Button size="lg" className="mt-5 w-full" disabled={!time || busy} onClick={submit}>
        {busy ? <Spinner /> : <CalendarPlus size={17} />}
        Confirm new time
      </Button>
    </Modal>
  );
}

/* ================= new appointment modal ================= */

function NewAppointmentModal({
  services,
  dentists,
  onClose,
}: {
  services: ServiceRef[];
  dentists: DentistRef[];
  onClose: () => void;
}) {
  const router = useRouter();
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [phone, setPhone] = useState("");
  const [serviceId, setServiceId] = useState(services[0]?.id ?? "");
  const [dentistId, setDentistId] = useState("any");
  const [date, setDate] = useState(todayString());
  const [time, setTime] = useState<string | null>(null);
  const [issue, setIssue] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function submit() {
    if (!time) return;
    setBusy(true);
    setError(null);
    try {
      const res = await fetch("/api/admin/appointments", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          firstName, lastName, phone, serviceId, dentistId, date, time, issue,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error ?? "Could not create the appointment.");
        return;
      }
      router.refresh();
      onClose();
    } finally {
      setBusy(false);
    }
  }

  return (
    <Modal open onClose={onClose} title="New appointment" wide>
      {error && (
        <div className="mb-4 rounded-2xl border border-red-100 bg-red-50 px-4 py-3 text-sm font-medium text-red-600">
          {error}
        </div>
      )}
      <div className="grid gap-4 sm:grid-cols-2">
        <div>
          <Label>First name</Label>
          <Input value={firstName} onChange={(e) => setFirstName(e.target.value)} />
        </div>
        <div>
          <Label>Last name</Label>
          <Input value={lastName} onChange={(e) => setLastName(e.target.value)} />
        </div>
        <div>
          <Label>Phone</Label>
          <Input
            type="tel"
            placeholder="044 123 456"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
          />
        </div>
        <div>
          <Label>Service</Label>
          <Select value={serviceId} onChange={(e) => setServiceId(e.target.value)}>
            {services.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name} ({s.durationMinutes} min)
              </option>
            ))}
          </Select>
        </div>
        <div>
          <Label>Dentist</Label>
          <Select value={dentistId} onChange={(e) => setDentistId(e.target.value)}>
            <option value="any">First available</option>
            {dentists.map((d) => (
              <option key={d.id} value={d.id}>
                {d.name}
              </option>
            ))}
          </Select>
        </div>
        <div>
          <Label>Date</Label>
          <Input
            type="date"
            min={todayString()}
            value={date}
            onChange={(e) => setDate(e.target.value)}
          />
        </div>
      </div>
      <div className="mt-4">
        <Label>Available times</Label>
        <SlotPicker
          serviceId={serviceId}
          dentistId={dentistId}
          date={date}
          value={time}
          onChange={setTime}
        />
      </div>
      <div className="mt-4">
        <Label>
          Notes <span className="font-normal text-ink-faint">(optional)</span>
        </Label>
        <Input
          placeholder="Reason for visit…"
          value={issue}
          onChange={(e) => setIssue(e.target.value)}
        />
      </div>
      <Button
        size="lg"
        className="mt-5 w-full"
        disabled={!time || busy || !firstName || !lastName || !phone}
        onClick={submit}
      >
        {busy ? <Spinner /> : <Plus size={17} />}
        Create appointment
      </Button>
    </Modal>
  );
}
