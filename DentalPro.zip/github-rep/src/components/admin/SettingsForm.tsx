"use client";

import { WeekHoursEditor } from "@/components/admin/WeekHoursEditor";
import { Button, Input, Label, Spinner, Textarea } from "@/components/ui";
import { SMS_PLACEHOLDERS } from "@/lib/clientDefaults";
import type { Clinic, DayHours, Holiday } from "@/lib/types";
import { cn, renderTemplate } from "@/lib/utils";
import { Check, Image as ImageIcon, Plus, Trash2, X } from "lucide-react";
import { useRouter } from "next/navigation";
import { useRef, useState } from "react";

const TABS = ["Branding", "Contact", "Hours & Holidays", "Booking Rules", "SMS Messages"] as const;
type Tab = (typeof TABS)[number];

const COLOR_PRESETS = ["#2563eb", "#0ea5e9", "#0d9488", "#7c3aed", "#db2777", "#16a34a", "#ea580c", "#0f172a"];

export function SettingsForm({ clinic }: { clinic: Clinic }) {
  const router = useRouter();
  const [tab, setTab] = useState<Tab>("Branding");
  const [busy, setBusy] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // local editable state
  const [form, setForm] = useState(() => ({
    name: clinic.name,
    tagline: clinic.tagline,
    logoUrl: clinic.logoUrl,
    primaryColor: clinic.primaryColor,
    heroHeadline: clinic.heroHeadline,
    heroSubheadline: clinic.heroSubheadline,
    aboutText: clinic.aboutText,
    patientInstructions: clinic.patientInstructions,
    stats: { ...clinic.stats },
    address: clinic.address,
    city: clinic.city,
    phone: clinic.phone,
    emergencyPhone: clinic.emergencyPhone,
    email: clinic.email,
    mapsEmbedUrl: clinic.mapsEmbedUrl,
    socials: { ...clinic.socials },
    workingHours: clinic.workingHours.map((h) => ({ ...h })) as DayHours[],
    holidays: clinic.holidays.map((h) => ({ ...h })) as Holiday[],
    slotStepMinutes: clinic.slotStepMinutes,
    minLeadMinutes: clinic.minLeadMinutes,
    maxAdvanceDays: clinic.maxAdvanceDays,
    smsTemplates: { ...clinic.smsTemplates },
    published: clinic.published,
  }));

  const fileRef = useRef<HTMLInputElement>(null);
  const [holidayDate, setHolidayDate] = useState("");
  const [holidayName, setHolidayName] = useState("");

  function set<K extends keyof typeof form>(key: K, value: (typeof form)[K]) {
    setForm((f) => ({ ...f, [key]: value }));
    setSaved(false);
  }

  async function saveAll() {
    setBusy(true);
    setError(null);
    try {
      const res = await fetch("/api/admin/clinic", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...form,
          slotStepMinutes: Number(form.slotStepMinutes),
          minLeadMinutes: Number(form.minLeadMinutes),
          maxAdvanceDays: Number(form.maxAdvanceDays),
          stats: {
            yearsExperience: Number(form.stats.yearsExperience),
            happyPatients: Number(form.stats.happyPatients),
            certifiedDentists: Number(form.stats.certifiedDentists),
          },
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error ?? "Could not save settings.");
        return;
      }
      setSaved(true);
      router.refresh();
    } finally {
      setBusy(false);
    }
  }

  function onLogoFile(file: File) {
    if (file.size > 300_000) {
      setError("Logo must be under 300 KB. Use a small square PNG.");
      return;
    }
    const reader = new FileReader();
    reader.onload = () => set("logoUrl", reader.result as string);
    reader.readAsDataURL(file);
  }

  const previewVars = {
    clinic: form.name,
    service: "General Checkup",
    dentist: "Dr. Arta Krasniqi",
    date: "Monday, July 20, 2026",
    time: "10:30 AM",
    link: "https://…/manage/abc123",
  };

  return (
    <div>
      <div className="mb-7 flex flex-wrap items-center gap-4">
        <div>
          <h1 className="font-display text-2xl sm:text-3xl font-extrabold tracking-tight text-ink">
            Settings
          </h1>
          <p className="mt-1 text-[15px] text-ink-soft">
            Everything about your clinic's website, hours and messages.
          </p>
        </div>
        <div className="ml-auto flex items-center gap-3">
          {saved && (
            <span className="inline-flex items-center gap-1.5 text-sm font-semibold text-emerald-600">
              <Check size={16} /> Saved
            </span>
          )}
          <Button onClick={saveAll} disabled={busy}>
            {busy ? <Spinner /> : <Check size={16} />}
            Save changes
          </Button>
        </div>
      </div>

      {error && (
        <div className="mb-5 rounded-2xl border border-red-100 bg-red-50 px-4 py-3 text-sm font-medium text-red-600">
          {error}
        </div>
      )}

      <div className="mb-6 flex flex-wrap gap-2">
        {TABS.map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={cn(
              "rounded-full px-4 py-2 text-[13.5px] font-semibold transition cursor-pointer",
              tab === t
                ? "bg-brand text-white shadow-[0_6px_18px_color-mix(in_srgb,var(--brand)_35%,transparent)]"
                : "bg-white border border-line text-ink-soft hover:text-ink"
            )}
          >
            {t}
          </button>
        ))}
      </div>

      <div className="rounded-3xl border border-line/70 bg-white p-6 sm:p-8">
        {/* ---------- Branding ---------- */}
        {tab === "Branding" && (
          <div className="grid gap-5 max-w-2xl">
            <div className="grid gap-5 sm:grid-cols-2">
              <div>
                <Label>Clinic name</Label>
                <Input value={form.name} onChange={(e) => set("name", e.target.value)} />
              </div>
              <div>
                <Label>Tagline</Label>
                <Input value={form.tagline} onChange={(e) => set("tagline", e.target.value)} />
              </div>
            </div>

            <div>
              <Label>Logo</Label>
              <div className="flex items-center gap-4">
                {form.logoUrl ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img
                    src={form.logoUrl}
                    alt="Logo"
                    className="h-14 w-14 rounded-2xl object-cover border border-line"
                  />
                ) : (
                  <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-mist text-ink-faint">
                    <ImageIcon size={22} />
                  </span>
                )}
                <input
                  ref={fileRef}
                  type="file"
                  accept="image/png,image/jpeg,image/webp,image/svg+xml"
                  className="hidden"
                  onChange={(e) => e.target.files?.[0] && onLogoFile(e.target.files[0])}
                />
                <Button size="sm" variant="glass" onClick={() => fileRef.current?.click()}>
                  Upload logo
                </Button>
                {form.logoUrl && (
                  <button
                    onClick={() => set("logoUrl", null)}
                    className="text-[13px] font-semibold text-ink-faint hover:text-red-500 cursor-pointer"
                  >
                    Remove
                  </button>
                )}
              </div>
            </div>

            <div>
              <Label>Brand color</Label>
              <div className="flex flex-wrap items-center gap-2">
                {COLOR_PRESETS.map((c) => (
                  <button
                    key={c}
                    onClick={() => set("primaryColor", c)}
                    className={cn(
                      "h-9 w-9 rounded-full border-2 transition cursor-pointer",
                      form.primaryColor === c
                        ? "border-ink scale-110"
                        : "border-white shadow-sm hover:scale-105"
                    )}
                    style={{ background: c }}
                    aria-label={c}
                  />
                ))}
                <input
                  type="color"
                  value={form.primaryColor}
                  onChange={(e) => set("primaryColor", e.target.value)}
                  className="h-9 w-12 cursor-pointer rounded-lg border border-line bg-white"
                  aria-label="Custom color"
                />
                <span className="font-mono text-[13px] text-ink-soft">{form.primaryColor}</span>
              </div>
            </div>

            <div>
              <Label>Hero headline</Label>
              <Input
                value={form.heroHeadline}
                onChange={(e) => set("heroHeadline", e.target.value)}
              />
            </div>
            <div>
              <Label>Hero subheadline</Label>
              <Input
                value={form.heroSubheadline}
                onChange={(e) => set("heroSubheadline", e.target.value)}
              />
            </div>
            <div>
              <Label>About text</Label>
              <Textarea
                value={form.aboutText}
                onChange={(e) => set("aboutText", e.target.value)}
              />
            </div>
            <div>
              <Label>Patient instructions (shown after booking)</Label>
              <Textarea
                className="min-h-[70px]"
                value={form.patientInstructions}
                onChange={(e) => set("patientInstructions", e.target.value)}
              />
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div>
                <Label>Years experience</Label>
                <Input
                  type="number"
                  min={0}
                  value={form.stats.yearsExperience}
                  onChange={(e) =>
                    set("stats", { ...form.stats, yearsExperience: Number(e.target.value) })
                  }
                />
              </div>
              <div>
                <Label>Happy patients</Label>
                <Input
                  type="number"
                  min={0}
                  value={form.stats.happyPatients}
                  onChange={(e) =>
                    set("stats", { ...form.stats, happyPatients: Number(e.target.value) })
                  }
                />
              </div>
              <div>
                <Label>Certified dentists</Label>
                <Input
                  type="number"
                  min={0}
                  value={form.stats.certifiedDentists}
                  onChange={(e) =>
                    set("stats", { ...form.stats, certifiedDentists: Number(e.target.value) })
                  }
                />
              </div>
            </div>

            <label className="flex items-center gap-2.5 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={form.published}
                onChange={(e) => set("published", e.target.checked)}
                className="h-4 w-4 accent-[var(--brand)]"
              />
              <span className="text-sm font-medium text-ink">
                Website published{" "}
                <span className="text-ink-faint font-normal">
                  (unpublish to hide the site while you set things up)
                </span>
              </span>
            </label>
          </div>
        )}

        {/* ---------- Contact ---------- */}
        {tab === "Contact" && (
          <div className="grid gap-5 max-w-2xl">
            <div className="grid gap-5 sm:grid-cols-2">
              <div>
                <Label>Street address</Label>
                <Input value={form.address} onChange={(e) => set("address", e.target.value)} />
              </div>
              <div>
                <Label>City</Label>
                <Input value={form.city} onChange={(e) => set("city", e.target.value)} />
              </div>
              <div>
                <Label>Phone</Label>
                <Input value={form.phone} onChange={(e) => set("phone", e.target.value)} />
              </div>
              <div>
                <Label>Emergency phone</Label>
                <Input
                  value={form.emergencyPhone}
                  onChange={(e) => set("emergencyPhone", e.target.value)}
                />
              </div>
              <div className="sm:col-span-2">
                <Label>Email</Label>
                <Input value={form.email} onChange={(e) => set("email", e.target.value)} />
              </div>
            </div>
            <div>
              <Label>Google Maps embed URL</Label>
              <Input
                value={form.mapsEmbedUrl}
                onChange={(e) => set("mapsEmbedUrl", e.target.value)}
                placeholder="https://www.google.com/maps?q=…&output=embed"
              />
              <p className="mt-1.5 text-[12.5px] text-ink-faint">
                Tip: https://www.google.com/maps?q=YOUR+ADDRESS&output=embed
              </p>
            </div>
            <div className="grid gap-5 sm:grid-cols-3">
              <div>
                <Label>Facebook</Label>
                <Input
                  value={form.socials.facebook}
                  onChange={(e) => set("socials", { ...form.socials, facebook: e.target.value })}
                />
              </div>
              <div>
                <Label>Instagram</Label>
                <Input
                  value={form.socials.instagram}
                  onChange={(e) => set("socials", { ...form.socials, instagram: e.target.value })}
                />
              </div>
              <div>
                <Label>TikTok</Label>
                <Input
                  value={form.socials.tiktok}
                  onChange={(e) => set("socials", { ...form.socials, tiktok: e.target.value })}
                />
              </div>
            </div>
          </div>
        )}

        {/* ---------- Hours & Holidays ---------- */}
        {tab === "Hours & Holidays" && (
          <div className="grid gap-8 lg:grid-cols-2">
            <div>
              <h3 className="font-display font-bold text-ink mb-3">Working hours</h3>
              <WeekHoursEditor
                value={form.workingHours}
                onChange={(v) => set("workingHours", v)}
              />
            </div>
            <div>
              <h3 className="font-display font-bold text-ink mb-3">
                Holidays & closed days
              </h3>
              <div className="space-y-2">
                {form.holidays
                  .slice()
                  .sort((a, b) => a.date.localeCompare(b.date))
                  .map((h) => (
                    <div
                      key={h.date}
                      className="flex items-center gap-3 rounded-2xl border border-line/80 bg-white px-4 py-2.5"
                    >
                      <span className="font-mono text-[13px] font-semibold text-ink">
                        {h.date}
                      </span>
                      <span className="flex-1 text-[14px] text-ink-soft truncate">
                        {h.name}
                      </span>
                      <button
                        onClick={() =>
                          set("holidays", form.holidays.filter((x) => x.date !== h.date))
                        }
                        className="text-ink-faint hover:text-red-500 cursor-pointer"
                        aria-label={`Remove ${h.name}`}
                      >
                        <X size={15} />
                      </button>
                    </div>
                  ))}
                {form.holidays.length === 0 && (
                  <p className="text-sm text-ink-faint py-2">No holidays added yet.</p>
                )}
              </div>
              <div className="mt-4 flex gap-2">
                <Input
                  type="date"
                  value={holidayDate}
                  onChange={(e) => setHolidayDate(e.target.value)}
                  className="w-auto"
                />
                <Input
                  placeholder="Name (e.g. Independence Day)"
                  value={holidayName}
                  onChange={(e) => setHolidayName(e.target.value)}
                  className="flex-1"
                />
                <Button
                  variant="glass"
                  size="md"
                  disabled={!holidayDate}
                  onClick={() => {
                    if (!form.holidays.some((h) => h.date === holidayDate)) {
                      set("holidays", [
                        ...form.holidays,
                        { date: holidayDate, name: holidayName || "Closed" },
                      ]);
                    }
                    setHolidayDate("");
                    setHolidayName("");
                  }}
                >
                  <Plus size={15} />
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* ---------- Booking rules ---------- */}
        {tab === "Booking Rules" && (
          <div className="grid gap-5 max-w-lg">
            <div>
              <Label>Time slot step (minutes)</Label>
              <Input
                type="number"
                min={5}
                max={120}
                step={5}
                value={form.slotStepMinutes}
                onChange={(e) => set("slotStepMinutes", Number(e.target.value))}
              />
              <p className="mt-1.5 text-[12.5px] text-ink-faint">
                Appointments can start every N minutes (e.g. 30 → 9:00, 9:30, 10:00…).
              </p>
            </div>
            <div>
              <Label>Minimum lead time (minutes)</Label>
              <Input
                type="number"
                min={0}
                max={1440}
                step={15}
                value={form.minLeadMinutes}
                onChange={(e) => set("minLeadMinutes", Number(e.target.value))}
              />
              <p className="mt-1.5 text-[12.5px] text-ink-faint">
                How far in advance patients must book today's slots.
              </p>
            </div>
            <div>
              <Label>Booking window (days ahead)</Label>
              <Input
                type="number"
                min={1}
                max={365}
                value={form.maxAdvanceDays}
                onChange={(e) => set("maxAdvanceDays", Number(e.target.value))}
              />
              <p className="mt-1.5 text-[12.5px] text-ink-faint">
                Patients can book at most this many days into the future.
              </p>
            </div>
          </div>
        )}

        {/* ---------- SMS ---------- */}
        {tab === "SMS Messages" && (
          <div className="grid gap-8 lg:grid-cols-2">
            <div className="space-y-6">
              <div>
                <Label>Confirmation SMS</Label>
                <Textarea
                  value={form.smsTemplates.confirmation}
                  onChange={(e) =>
                    set("smsTemplates", {
                      ...form.smsTemplates,
                      confirmation: e.target.value,
                    })
                  }
                />
              </div>
              <div>
                <Label>24-hour reminder SMS</Label>
                <Textarea
                  value={form.smsTemplates.reminder}
                  onChange={(e) =>
                    set("smsTemplates", { ...form.smsTemplates, reminder: e.target.value })
                  }
                />
              </div>
              <div>
                <p className="text-[13px] font-semibold text-ink mb-2">Placeholders</p>
                <div className="flex flex-wrap gap-1.5">
                  {SMS_PLACEHOLDERS.map((p) => (
                    <span
                      key={p.token}
                      title={p.label}
                      className="rounded-full bg-mist px-2.5 py-1 font-mono text-[12px] font-semibold text-ink-soft"
                    >
                      {p.token}
                    </span>
                  ))}
                </div>
              </div>
            </div>
            <div>
              <p className="text-[13px] font-semibold text-ink mb-3">Live preview</p>
              <div className="rounded-3xl bg-mist p-5 space-y-3">
                <SmsBubble text={renderTemplate(form.smsTemplates.confirmation, previewVars)} />
                <SmsBubble text={renderTemplate(form.smsTemplates.reminder, previewVars)} />
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function SmsBubble({ text }: { text: string }) {
  return (
    <div className="max-w-[320px] rounded-3xl rounded-bl-lg bg-white border border-line px-4 py-3 text-[13.5px] leading-relaxed text-ink shadow-sm">
      {text}
    </div>
  );
}
