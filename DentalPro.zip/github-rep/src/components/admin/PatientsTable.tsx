"use client";

import { Input } from "@/components/ui";
import { initials } from "@/lib/utils";
import { Download, Phone, Search } from "lucide-react";
import { useMemo, useState } from "react";

interface PatientRow {
  id: string;
  name: string;
  phone: string;
  email: string | null;
  createdAt: string;
  visits: number;
  lastVisit: string;
  nextVisit: string;
}

export function PatientsTable({ patients }: { patients: PatientRow[] }) {
  const [query, setQuery] = useState("");

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return patients;
    return patients.filter((p) =>
      `${p.name} ${p.phone} ${p.email ?? ""}`.toLowerCase().includes(q)
    );
  }, [patients, query]);

  return (
    <div>
      <div className="mb-5 flex flex-wrap items-center gap-2.5">
        <div className="relative flex-1 min-w-[220px]">
          <Search
            size={16}
            className="absolute left-4 top-1/2 -translate-y-1/2 text-ink-faint"
          />
          <Input
            placeholder="Search by name or phone…"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="pl-10 h-11 py-0"
          />
        </div>
        <a
          href="/api/admin/export?type=patients"
          className="btn-glass ml-auto inline-flex h-11 items-center gap-2 rounded-full px-5 text-sm font-semibold"
        >
          <Download size={15} /> Export CSV
        </a>
      </div>

      <div className="overflow-hidden rounded-3xl border border-line/70 bg-white">
        {filtered.length === 0 ? (
          <p className="py-14 text-center text-sm text-ink-faint">No patients found.</p>
        ) : (
          <div className="overflow-x-auto scroll-thin">
            <table className="w-full min-w-[720px] text-left text-[14px]">
              <thead>
                <tr className="border-b border-line/70 text-[12px] uppercase tracking-wide text-ink-faint">
                  <th className="px-5 py-3.5 font-bold">Patient</th>
                  <th className="px-4 py-3.5 font-bold">Phone</th>
                  <th className="px-4 py-3.5 font-bold text-center">Visits</th>
                  <th className="px-4 py-3.5 font-bold">Last visit</th>
                  <th className="px-4 py-3.5 font-bold">Next visit</th>
                  <th className="px-4 py-3.5 font-bold">Since</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((p) => (
                  <tr
                    key={p.id}
                    className="border-b border-line/50 last:border-0 hover:bg-mist/60 transition-colors"
                  >
                    <td className="px-5 py-3.5">
                      <div className="flex items-center gap-3">
                        <span
                          className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-[12px] font-bold text-white"
                          style={{
                            background:
                              "linear-gradient(145deg, color-mix(in srgb, var(--brand) 70%, white), var(--brand-dark))",
                          }}
                        >
                          {initials(p.name)}
                        </span>
                        <span className="font-semibold text-ink">{p.name}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3.5">
                      <a
                        href={`tel:${p.phone}`}
                        className="inline-flex items-center gap-1.5 text-ink-soft hover:text-brand"
                      >
                        <Phone size={12} /> {p.phone}
                      </a>
                    </td>
                    <td className="px-4 py-3.5 text-center">
                      <span className="inline-flex h-7 min-w-7 items-center justify-center rounded-full bg-brand-soft px-2 text-[13px] font-bold text-brand">
                        {p.visits}
                      </span>
                    </td>
                    <td className="px-4 py-3.5 text-ink-soft">{p.lastVisit}</td>
                    <td className="px-4 py-3.5">
                      {p.nextVisit !== "—" ? (
                        <span className="font-semibold text-emerald-600">{p.nextVisit}</span>
                      ) : (
                        <span className="text-ink-faint">—</span>
                      )}
                    </td>
                    <td className="px-4 py-3.5 text-ink-faint">{p.createdAt}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
