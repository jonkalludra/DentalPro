"use client";

import type { DayHours } from "@/lib/types";
import { cn } from "@/lib/utils";

const DAY_LABELS = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
const ORDER = [1, 2, 3, 4, 5, 6, 0];

export function WeekHoursEditor({
  value,
  onChange,
}: {
  value: DayHours[];
  onChange: (next: DayHours[]) => void;
}) {
  function update(weekday: number, patch: Partial<DayHours>) {
    onChange(value.map((h, i) => (i === weekday ? { ...h, ...patch } : h)));
  }

  return (
    <div className="space-y-2">
      {ORDER.map((weekday) => {
        const hours = value[weekday];
        return (
          <div
            key={weekday}
            className={cn(
              "flex items-center gap-3 rounded-2xl border px-4 py-2.5 transition",
              hours.closed ? "border-line/60 bg-mist/60" : "border-line/80 bg-white"
            )}
          >
            <label className="flex w-[118px] shrink-0 items-center gap-2.5 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={!hours.closed}
                onChange={(e) => update(weekday, { closed: !e.target.checked })}
                className="h-4 w-4 accent-[var(--brand)]"
              />
              <span
                className={cn(
                  "text-[13.5px] font-semibold",
                  hours.closed ? "text-ink-faint" : "text-ink"
                )}
              >
                {DAY_LABELS[weekday]}
              </span>
            </label>
            {hours.closed ? (
              <span className="text-[13px] text-ink-faint">Closed</span>
            ) : (
              <div className="flex items-center gap-2">
                <input
                  type="time"
                  value={hours.open}
                  onChange={(e) => update(weekday, { open: e.target.value })}
                  className="rounded-xl border border-line bg-white px-2.5 py-1.5 text-[13.5px] font-medium outline-none focus:border-brand"
                />
                <span className="text-ink-faint text-sm">–</span>
                <input
                  type="time"
                  value={hours.close}
                  onChange={(e) => update(weekday, { close: e.target.value })}
                  className="rounded-xl border border-line bg-white px-2.5 py-1.5 text-[13.5px] font-medium outline-none focus:border-brand"
                />
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}
