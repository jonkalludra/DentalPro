"use client";

import { WeekHoursEditor } from "@/components/admin/WeekHoursEditor";
import { Badge, Button, Input, Label, Modal, Select, Spinner, Textarea } from "@/components/ui";
import { DEFAULT_WEEK_HOURS } from "@/lib/clientDefaults";
import type { Dentist, DayHours } from "@/lib/types";
import { cn, initials } from "@/lib/utils";
import { CalendarOff, Pencil, Plus, Trash2, UserRound, X } from "lucide-react";
import { useRouter } from "next/navigation";
import { useState } from "react";

interface UserRow {
  id: string;
  name: string;
  email: string;
  role: string;
  dentistId: string | null;
}

interface EditableDentist {
  id: string | null;
  name: string;
  title: string;
  bio: string;
  workingHours: DayHours[] | null;
  daysOff: string[];
  active: boolean;
}

const EMPTY_DENTIST: EditableDentist = {
  id: null,
  name: "",
  title: "",
  bio: "",
  workingHours: null,
  daysOff: [],
  active: true,
};

const ROLE_LABEL: Record<string, string> = {
  owner: "Clinic Owner",
  receptionist: "Receptionist",
  dentist: "Dentist",
  super_admin: "Platform Admin",
};

export function StaffManager({
  dentists,
  users,
  currentUserId,
}: {
  dentists: Dentist[];
  users: UserRow[];
  currentUserId: string;
}) {
  const router = useRouter();
  const [editing, setEditing] = useState<EditableDentist | null>(null);
  const [userModal, setUserModal] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function saveDentist() {
    if (!editing) return;
    setBusy(true);
    setError(null);
    try {
      const res = await fetch(
        editing.id ? `/api/admin/dentists/${editing.id}` : "/api/admin/dentists",
        {
          method: editing.id ? "PATCH" : "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            name: editing.name,
            title: editing.title,
            bio: editing.bio,
            workingHours: editing.workingHours,
            daysOff: editing.daysOff,
            active: editing.active,
          }),
        }
      );
      const data = await res.json();
      if (!res.ok) {
        setError(data.error ?? "Could not save.");
        return;
      }
      router.refresh();
      setEditing(null);
    } finally {
      setBusy(false);
    }
  }

  async function removeDentist(id: string) {
    setBusy(true);
    setError(null);
    try {
      const res = await fetch(`/api/admin/dentists/${id}`, { method: "DELETE" });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error ?? "Could not delete.");
        return;
      }
      router.refresh();
      setEditing(null);
    } finally {
      setBusy(false);
    }
  }

  async function removeUser(id: string) {
    const res = await fetch(`/api/admin/users/${id}`, { method: "DELETE" });
    if (res.ok) router.refresh();
  }

  return (
    <div>
      <div className="mb-7">
        <h1 className="font-display text-2xl sm:text-3xl font-extrabold tracking-tight text-ink">
          Staff
        </h1>
        <p className="mt-1 text-[15px] text-ink-soft">
          Dentists with their own schedules, plus dashboard accounts for your team.
        </p>
      </div>

      {/* dentists */}
      <section>
        <div className="mb-4 flex items-center justify-between">
          <h2 className="font-display text-lg font-bold text-ink">Dentists</h2>
          <Button size="sm" onClick={() => { setError(null); setEditing({ ...EMPTY_DENTIST }); }}>
            <Plus size={15} /> Add dentist
          </Button>
        </div>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {dentists.map((d) => (
            <div
              key={d.id}
              className={cn(
                "rounded-3xl border border-line/70 bg-white p-6",
                !d.active && "opacity-55"
              )}
            >
              <div className="flex items-start justify-between">
                <span
                  className="flex h-12 w-12 items-center justify-center rounded-full text-[15px] font-bold text-white"
                  style={{
                    background:
                      "linear-gradient(145deg, color-mix(in srgb, var(--brand) 75%, white), var(--brand-dark))",
                  }}
                >
                  {initials(d.name)}
                </span>
                <div className="flex items-center gap-1.5">
                  {!d.active && <Badge tone="neutral">inactive</Badge>}
                  <button
                    onClick={() => {
                      setError(null);
                      setEditing({
                        id: d.id,
                        name: d.name,
                        title: d.title,
                        bio: d.bio,
                        workingHours: d.workingHours
                          ? d.workingHours.map((h) => ({ ...h }))
                          : null,
                        daysOff: [...d.daysOff],
                        active: d.active,
                      });
                    }}
                    className="rounded-full p-2 text-ink-faint hover:bg-brand-soft hover:text-brand transition cursor-pointer"
                    aria-label={`Edit ${d.name}`}
                  >
                    <Pencil size={15} />
                  </button>
                </div>
              </div>
              <p className="font-display mt-4 font-bold text-ink">{d.name}</p>
              <p className="text-[13.5px] text-brand font-semibold">{d.title}</p>
              <p className="mt-1.5 line-clamp-2 text-[13px] text-ink-soft">{d.bio}</p>
              <div className="mt-4 flex flex-wrap gap-2 text-[12px] font-semibold text-ink-faint">
                <span className="rounded-full bg-mist px-2.5 py-1">
                  {d.workingHours ? "Custom hours" : "Clinic hours"}
                </span>
                {d.daysOff.length > 0 && (
                  <span className="rounded-full bg-mist px-2.5 py-1 inline-flex items-center gap-1">
                    <CalendarOff size={11} /> {d.daysOff.length} days off
                  </span>
                )}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* team accounts */}
      <section className="mt-12">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="font-display text-lg font-bold text-ink">Team accounts</h2>
          <Button size="sm" variant="glass" onClick={() => { setError(null); setUserModal(true); }}>
            <Plus size={15} /> Add account
          </Button>
        </div>
        <div className="overflow-hidden rounded-3xl border border-line/70 bg-white">
          {users.map((u, i) => (
            <div
              key={u.id}
              className={cn(
                "flex items-center gap-4 px-5 py-4",
                i > 0 && "border-t border-line/50"
              )}
            >
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-mist text-ink-soft">
                <UserRound size={18} />
              </span>
              <div className="min-w-0 flex-1">
                <p className="font-semibold text-ink truncate">{u.name}</p>
                <p className="text-[13px] text-ink-faint truncate">{u.email}</p>
              </div>
              <Badge tone={u.role === "owner" ? "blue" : "neutral"}>
                {ROLE_LABEL[u.role] ?? u.role}
              </Badge>
              {u.id !== currentUserId && (
                <button
                  onClick={() => removeUser(u.id)}
                  className="rounded-full p-2 text-ink-faint hover:bg-red-50 hover:text-red-500 transition cursor-pointer"
                  aria-label={`Remove ${u.name}`}
                >
                  <Trash2 size={15} />
                </button>
              )}
            </div>
          ))}
        </div>
      </section>

      {/* dentist modal */}
      <Modal
        open={editing !== null}
        onClose={() => setEditing(null)}
        title={editing?.id ? "Edit dentist" : "New dentist"}
        wide
      >
        {editing && (
          <div>
            {error && (
              <div className="mb-4 rounded-2xl border border-red-100 bg-red-50 px-4 py-3 text-sm font-medium text-red-600">
                {error}
              </div>
            )}
            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <Label>Full name</Label>
                <Input
                  placeholder="Dr. Arta Krasniqi"
                  value={editing.name}
                  onChange={(e) => setEditing({ ...editing, name: e.target.value })}
                />
              </div>
              <div>
                <Label>Specialty</Label>
                <Input
                  placeholder="Orthodontics"
                  value={editing.title}
                  onChange={(e) => setEditing({ ...editing, title: e.target.value })}
                />
              </div>
              <div className="sm:col-span-2">
                <Label>Short bio</Label>
                <Textarea
                  className="min-h-[70px]"
                  value={editing.bio}
                  onChange={(e) => setEditing({ ...editing, bio: e.target.value })}
                />
              </div>
            </div>

            <div className="mt-5">
              <label className="flex items-center gap-2.5 cursor-pointer select-none mb-3">
                <input
                  type="checkbox"
                  checked={editing.workingHours !== null}
                  onChange={(e) =>
                    setEditing({
                      ...editing,
                      workingHours: e.target.checked
                        ? DEFAULT_WEEK_HOURS.map((h) => ({ ...h }))
                        : null,
                    })
                  }
                  className="h-4 w-4 accent-[var(--brand)]"
                />
                <span className="text-sm font-medium text-ink">
                  Custom working hours{" "}
                  <span className="text-ink-faint font-normal">
                    (otherwise clinic hours apply)
                  </span>
                </span>
              </label>
              {editing.workingHours && (
                <WeekHoursEditor
                  value={editing.workingHours}
                  onChange={(workingHours) => setEditing({ ...editing, workingHours })}
                />
              )}
            </div>

            <div className="mt-5">
              <Label>Days off / vacation</Label>
              <div className="flex flex-wrap items-center gap-2">
                {editing.daysOff.sort().map((d) => (
                  <span
                    key={d}
                    className="inline-flex items-center gap-1.5 rounded-full bg-mist px-3 py-1.5 text-[13px] font-semibold text-ink"
                  >
                    {d}
                    <button
                      onClick={() =>
                        setEditing({
                          ...editing,
                          daysOff: editing.daysOff.filter((x) => x !== d),
                        })
                      }
                      className="text-ink-faint hover:text-red-500 cursor-pointer"
                      aria-label={`Remove ${d}`}
                    >
                      <X size={13} />
                    </button>
                  </span>
                ))}
                <input
                  type="date"
                  className="rounded-xl border border-line bg-white px-3 py-1.5 text-[13px] font-medium outline-none focus:border-brand"
                  onChange={(e) => {
                    const v = e.target.value;
                    if (v && !editing.daysOff.includes(v)) {
                      setEditing({ ...editing, daysOff: [...editing.daysOff, v] });
                      e.target.value = "";
                    }
                  }}
                />
              </div>
            </div>

            <label className="mt-5 flex items-center gap-2.5 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={editing.active}
                onChange={(e) => setEditing({ ...editing, active: e.target.checked })}
                className="h-4 w-4 accent-[var(--brand)]"
              />
              <span className="text-sm font-medium text-ink">Active & bookable</span>
            </label>

            <div className="mt-6 flex items-center gap-2.5">
              {editing.id && (
                <Button variant="danger" onClick={() => removeDentist(editing.id!)} disabled={busy}>
                  <Trash2 size={15} /> Delete
                </Button>
              )}
              <Button className="flex-1" onClick={saveDentist} disabled={busy || !editing.name}>
                {busy ? <Spinner /> : null}
                {editing.id ? "Save changes" : "Add dentist"}
              </Button>
            </div>
          </div>
        )}
      </Modal>

      {/* new user modal */}
      {userModal && (
        <NewUserModal
          dentists={dentists}
          onClose={() => setUserModal(false)}
        />
      )}
    </div>
  );
}

function NewUserModal({
  dentists,
  onClose,
}: {
  dentists: Dentist[];
  onClose: () => void;
}) {
  const router = useRouter();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState("receptionist");
  const [dentistId, setDentistId] = useState<string>(dentists[0]?.id ?? "");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function submit() {
    setBusy(true);
    setError(null);
    try {
      const res = await fetch("/api/admin/users", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name,
          email,
          password,
          role,
          dentistId: role === "dentist" ? dentistId : null,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error ?? "Could not create the account.");
        return;
      }
      router.refresh();
      onClose();
    } finally {
      setBusy(false);
    }
  }

  return (
    <Modal open onClose={onClose} title="New team account">
      {error && (
        <div className="mb-4 rounded-2xl border border-red-100 bg-red-50 px-4 py-3 text-sm font-medium text-red-600">
          {error}
        </div>
      )}
      <div className="space-y-4">
        <div>
          <Label>Name</Label>
          <Input value={name} onChange={(e) => setName(e.target.value)} />
        </div>
        <div>
          <Label>Email</Label>
          <Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
        </div>
        <div>
          <Label>Password (min 8 characters)</Label>
          <Input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>
        <div>
          <Label>Role</Label>
          <Select value={role} onChange={(e) => setRole(e.target.value)}>
            <option value="receptionist">Receptionist — appointments & patients</option>
            <option value="dentist">Dentist — own schedule only</option>
            <option value="owner">Owner — full access</option>
          </Select>
        </div>
        {role === "dentist" && (
          <div>
            <Label>Linked dentist profile</Label>
            <Select value={dentistId} onChange={(e) => setDentistId(e.target.value)}>
              {dentists.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.name}
                </option>
              ))}
            </Select>
          </div>
        )}
        <Button
          size="lg"
          className="w-full"
          onClick={submit}
          disabled={busy || !name || !email || password.length < 8}
        >
          {busy ? <Spinner /> : <Plus size={16} />}
          Create account
        </Button>
      </div>
    </Modal>
  );
}
