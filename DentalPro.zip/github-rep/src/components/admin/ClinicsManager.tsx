"use client";

import { Badge, Button, Input, Label, Modal, Spinner } from "@/components/ui";
import { cn } from "@/lib/utils";
import { ArrowRight, Building2, ExternalLink, Plus } from "lucide-react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";

interface ClinicRow {
  id: string;
  slug: string;
  name: string;
  city: string;
  phone: string;
  primaryColor: string;
  published: boolean;
  patients: number;
  upcoming: number;
  total: number;
}

export function ClinicsManager({
  clinics,
  activeClinicId,
}: {
  clinics: ClinicRow[];
  activeClinicId: string | null;
}) {
  const router = useRouter();
  const [createOpen, setCreateOpen] = useState(false);
  const [switching, setSwitching] = useState<string | null>(null);

  async function openDashboard(clinicId: string) {
    setSwitching(clinicId);
    try {
      const res = await fetch("/api/admin/switch-clinic", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ clinicId }),
      });
      if (res.ok) {
        router.push("/admin");
        router.refresh();
      }
    } finally {
      setSwitching(null);
    }
  }

  return (
    <div>
      <div className="mb-7 flex flex-wrap items-center gap-4">
        <div>
          <h1 className="font-display text-2xl sm:text-3xl font-extrabold tracking-tight text-ink">
            Clinics
          </h1>
          <p className="mt-1 text-[15px] text-ink-soft">
            Every clinic on the platform — isolated data, own branding, own team.
          </p>
        </div>
        <Button className="ml-auto" onClick={() => setCreateOpen(true)}>
          <Plus size={16} /> New clinic
        </Button>
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        {clinics.map((c) => (
          <div
            key={c.id}
            className={cn(
              "rounded-3xl border bg-white p-6 transition",
              c.id === activeClinicId
                ? "border-brand ring-4 ring-brand/10"
                : "border-line/70"
            )}
          >
            <div className="flex items-start gap-4">
              <span
                className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl text-white"
                style={{
                  background: `linear-gradient(145deg, color-mix(in srgb, ${c.primaryColor} 78%, white), ${c.primaryColor})`,
                }}
              >
                <Building2 size={22} />
              </span>
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2">
                  <p className="font-display font-bold text-ink truncate">{c.name}</p>
                  {!c.published && <Badge tone="neutral">draft</Badge>}
                  {c.id === activeClinicId && <Badge tone="blue">active</Badge>}
                </div>
                <p className="text-[13px] text-ink-faint truncate">
                  /{c.slug} · {c.city} · {c.phone}
                </p>
              </div>
            </div>

            <div className="mt-5 grid grid-cols-3 gap-3 text-center">
              {[
                { label: "Patients", value: c.patients },
                { label: "Upcoming", value: c.upcoming },
                { label: "All time", value: c.total },
              ].map((s) => (
                <div key={s.label} className="rounded-2xl bg-mist px-2 py-3">
                  <p className="font-display text-lg font-extrabold text-ink">{s.value}</p>
                  <p className="text-[11px] font-semibold text-ink-faint">{s.label}</p>
                </div>
              ))}
            </div>

            <div className="mt-5 flex items-center gap-2">
              <Button
                size="sm"
                className="flex-1"
                onClick={() => openDashboard(c.id)}
                disabled={switching !== null}
              >
                {switching === c.id ? <Spinner /> : <ArrowRight size={15} />}
                Open dashboard
              </Button>
              <Link
                href={`/clinic/${c.slug}`}
                target="_blank"
                className="btn-glass inline-flex h-9 items-center gap-1.5 rounded-full px-4 text-[13px] font-semibold"
              >
                <ExternalLink size={13} /> Site
              </Link>
            </div>
          </div>
        ))}
      </div>

      {createOpen && <NewClinicModal onClose={() => setCreateOpen(false)} />}
    </div>
  );
}

function NewClinicModal({ onClose }: { onClose: () => void }) {
  const router = useRouter();
  const [form, setForm] = useState({
    name: "",
    slug: "",
    city: "",
    address: "",
    phone: "",
    primaryColor: "#2563eb",
    ownerName: "",
    ownerEmail: "",
    ownerPassword: "",
  });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  function set(key: keyof typeof form, value: string) {
    setForm((f) => {
      const next = { ...f, [key]: value };
      if (key === "name") {
        next.slug = value
          .toLowerCase()
          .replace(/[^a-z0-9]+/g, "-")
          .replace(/^-+|-+$/g, "")
          .slice(0, 30);
      }
      return next;
    });
  }

  async function submit() {
    setBusy(true);
    setError(null);
    try {
      const res = await fetch("/api/admin/clinics", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error ?? "Could not create the clinic.");
        return;
      }
      router.refresh();
      onClose();
    } finally {
      setBusy(false);
    }
  }

  const valid =
    form.name.length >= 2 &&
    form.slug.length >= 3 &&
    form.city.length >= 2 &&
    form.phone.length >= 5 &&
    form.ownerName.length >= 2 &&
    /@/.test(form.ownerEmail) &&
    form.ownerPassword.length >= 8;

  return (
    <Modal open onClose={onClose} title="New clinic" wide>
      {error && (
        <div className="mb-4 rounded-2xl border border-red-100 bg-red-50 px-4 py-3 text-sm font-medium text-red-600">
          {error}
        </div>
      )}
      <div className="grid gap-4 sm:grid-cols-2">
        <div>
          <Label>Clinic name</Label>
          <Input
            placeholder="Denta Lux"
            value={form.name}
            onChange={(e) => set("name", e.target.value)}
          />
        </div>
        <div>
          <Label>Subdomain slug</Label>
          <Input
            placeholder="denta-lux"
            value={form.slug}
            onChange={(e) => set("slug", e.target.value)}
          />
        </div>
        <div>
          <Label>City</Label>
          <Input value={form.city} onChange={(e) => set("city", e.target.value)} />
        </div>
        <div>
          <Label>Phone</Label>
          <Input value={form.phone} onChange={(e) => set("phone", e.target.value)} />
        </div>
        <div className="sm:col-span-2">
          <Label>Address</Label>
          <Input value={form.address} onChange={(e) => set("address", e.target.value)} />
        </div>
        <div>
          <Label>Brand color</Label>
          <div className="flex items-center gap-2">
            <input
              type="color"
              value={form.primaryColor}
              onChange={(e) => set("primaryColor", e.target.value)}
              className="h-11 w-14 cursor-pointer rounded-xl border border-line bg-white"
            />
            <span className="font-mono text-[13px] text-ink-soft">
              {form.primaryColor}
            </span>
          </div>
        </div>
      </div>

      <p className="font-display mt-6 mb-3 font-bold text-ink">Owner account</p>
      <div className="grid gap-4 sm:grid-cols-2">
        <div>
          <Label>Owner name</Label>
          <Input value={form.ownerName} onChange={(e) => set("ownerName", e.target.value)} />
        </div>
        <div>
          <Label>Owner email</Label>
          <Input
            type="email"
            value={form.ownerEmail}
            onChange={(e) => set("ownerEmail", e.target.value)}
          />
        </div>
        <div className="sm:col-span-2">
          <Label>Owner password (min 8 characters)</Label>
          <Input
            type="password"
            value={form.ownerPassword}
            onChange={(e) => set("ownerPassword", e.target.value)}
          />
        </div>
      </div>

      <Button size="lg" className="mt-6 w-full" onClick={submit} disabled={!valid || busy}>
        {busy ? <Spinner /> : <Plus size={17} />}
        Create clinic
      </Button>
    </Modal>
  );
}
