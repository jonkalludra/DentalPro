"use client";

import { LogoMark } from "@/components/icons";
import { cn, initials } from "@/lib/utils";
import { AnimatePresence, motion } from "framer-motion";
import {
  Building2, CalendarDays, CalendarRange, LayoutDashboard, LogOut,
  Menu, Settings, Stethoscope, Users, UsersRound, ExternalLink, X,
} from "lucide-react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useState, type CSSProperties, type ReactNode } from "react";

const NAV = [
  { href: "/admin", label: "Dashboard", icon: LayoutDashboard, permission: "appointments" },
  { href: "/admin/appointments", label: "Appointments", icon: CalendarDays, permission: "appointments" },
  { href: "/admin/calendar", label: "Calendar", icon: CalendarRange, permission: "appointments" },
  { href: "/admin/patients", label: "Patients", icon: UsersRound, permission: "patients" },
  { href: "/admin/services", label: "Services", icon: Stethoscope, permission: "services" },
  { href: "/admin/staff", label: "Staff", icon: Users, permission: "staff" },
  { href: "/admin/settings", label: "Settings", icon: Settings, permission: "settings" },
  { href: "/admin/clinics", label: "Clinics", icon: Building2, permission: "clinics" },
] as const;

const ROLE_LABELS: Record<string, string> = {
  super_admin: "Platform Admin",
  owner: "Clinic Owner",
  receptionist: "Receptionist",
  dentist: "Dentist",
};

export function AdminShell({
  userName,
  role,
  clinicName,
  clinicSlug,
  brandColor,
  permissions,
  children,
}: {
  userName: string;
  role: string;
  clinicName: string;
  clinicSlug: string | null;
  brandColor: string;
  permissions: string[];
  children: ReactNode;
}) {
  const pathname = usePathname();
  const router = useRouter();
  const [mobileOpen, setMobileOpen] = useState(false);

  const items = NAV.filter((n) => permissions.includes(n.permission));

  async function logout() {
    await fetch("/api/admin/logout", { method: "POST" });
    router.push("/admin/login");
    router.refresh();
  }

  const sidebar = (
    <div className="flex h-full flex-col">
      <div className="flex items-center gap-2.5 px-5 pt-6 pb-5">
        <LogoMark size={36} />
        <div className="min-w-0">
          <p className="font-display truncate text-[15px] font-bold text-ink leading-tight">
            {clinicName}
          </p>
          <p className="text-[11px] font-semibold uppercase tracking-wide text-ink-faint">
            {ROLE_LABELS[role] ?? role}
          </p>
        </div>
      </div>

      <nav className="flex-1 space-y-1 px-3">
        {items.map((item) => {
          const active =
            item.href === "/admin"
              ? pathname === "/admin"
              : pathname.startsWith(item.href);
          return (
            <Link
              key={item.href}
              href={item.href}
              onClick={() => setMobileOpen(false)}
              className={cn(
                "flex items-center gap-3 rounded-2xl px-4 py-2.5 text-[14px] font-semibold transition",
                active
                  ? "bg-brand text-white shadow-[0_6px_18px_color-mix(in_srgb,var(--brand)_35%,transparent)]"
                  : "text-ink-soft hover:bg-white hover:text-ink"
              )}
            >
              <item.icon size={18} />
              {item.label}
            </Link>
          );
        })}
      </nav>

      <div className="px-3 pb-5 space-y-1">
        {clinicSlug && (
          <Link
            href={`/clinic/${clinicSlug}`}
            target="_blank"
            className="flex items-center gap-3 rounded-2xl px-4 py-2.5 text-[14px] font-semibold text-ink-soft hover:bg-white hover:text-ink transition"
          >
            <ExternalLink size={18} />
            View website
          </Link>
        )}
        <div className="flex items-center gap-3 rounded-2xl bg-white/70 border border-line/60 px-4 py-3 mx-1">
          <span
            className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-[12px] font-bold text-white"
            style={{
              background:
                "linear-gradient(145deg, color-mix(in srgb, var(--brand) 75%, white), var(--brand-dark))",
            }}
          >
            {initials(userName)}
          </span>
          <div className="min-w-0 flex-1">
            <p className="truncate text-[13px] font-bold text-ink">{userName}</p>
          </div>
          <button
            onClick={logout}
            aria-label="Log out"
            className="rounded-full p-2 text-ink-faint hover:bg-mist hover:text-red-500 transition cursor-pointer"
          >
            <LogOut size={16} />
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <div
      className="min-h-screen bg-mist"
      style={{ "--brand": brandColor } as CSSProperties}
    >
      {/* desktop sidebar */}
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-[248px] border-r border-line/60 bg-mist-deep/60 lg:block">
        {sidebar}
      </aside>

      {/* mobile top bar */}
      <div className="lg:hidden sticky top-0 z-30 flex items-center justify-between glass-deep px-4 py-3">
        <div className="flex items-center gap-2.5">
          <LogoMark size={30} />
          <span className="font-display text-[15px] font-bold text-ink truncate">
            {clinicName}
          </span>
        </div>
        <button
          onClick={() => setMobileOpen(true)}
          className="rounded-full p-2 hover:bg-white/70 transition cursor-pointer"
          aria-label="Open menu"
        >
          <Menu size={20} />
        </button>
      </div>

      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            className="fixed inset-0 z-50 lg:hidden"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <div
              className="absolute inset-0 bg-ink/30 backdrop-blur-sm"
              onClick={() => setMobileOpen(false)}
            />
            <motion.div
              initial={{ x: -280 }}
              animate={{ x: 0 }}
              exit={{ x: -280 }}
              transition={{ type: "spring", duration: 0.4, bounce: 0.1 }}
              className="absolute inset-y-0 left-0 w-[280px] bg-mist shadow-2xl"
            >
              <button
                onClick={() => setMobileOpen(false)}
                className="absolute right-3 top-5 rounded-full p-2 text-ink-faint hover:bg-white transition cursor-pointer"
                aria-label="Close menu"
              >
                <X size={18} />
              </button>
              {sidebar}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <main className="lg:pl-[248px]">
        <div className="mx-auto max-w-6xl px-4 sm:px-7 py-7 sm:py-9">{children}</div>
      </main>
    </div>
  );
}
