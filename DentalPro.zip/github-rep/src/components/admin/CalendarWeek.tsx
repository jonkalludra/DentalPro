"use client";

import type { AppointmentView } from "@/lib/adminData";
import type { BlockedSlot, DayHours, Holiday } from "@/lib/types";
import { addDays, cn, formatTime, todayString, toMinutes, toTimeString } from "@/lib/utils";
import { Button, Input, Label, Modal, Select, Spinner } from "@/components/ui";
import { Ban, ChevronLeft, ChevronRight, Trash2 } from "lucide-react";
import { useRouter } from "next/navigation";
import { useEffect, useMemo, useState } from "react";

const PX_PER_MIN = 1.05;
const DAY_LABELS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];

const STATUS_CHIP: Record<string, string> = {
  pending: "bg-amber-100/90 border-amber-300 text-amber-900",
  confirmed: "bg-[color-mix(in_srgb,var(--brand)_14%,white)] border-[color-mix(in_srgb,var(--brand)_40%,white)] text-ink",
  completed: "bg-slate-100 border-slate-300 text-slate-600",
};

export function CalendarWeek({
  weekStart,
  appointments,
  blocked,
  dentists,
  workingHours,
  holidays,
  role,
}: {
  weekStart: string;
  appointments: AppointmentView[];
  blocked: BlockedSlot[];
  dentists: { id: string; name: string }[];
  workingHours: DayHours[];
  holidays: Holiday[];
  role: string;
}) {
  const router = useRouter();
  const [dentistId, setDentistId] = useState("all");
  const [blockOpen, setBlockOpen] = useState(false);
  const [blockDefaults, setBlockDefaults] = useState<{ date: string; start: string } | null>(null);
  const [deleteBlock, setDeleteBlock] = useState<BlockedSlot | null>(null);
  const [nowMin, setNowMin] = useState(() => {
    const n = new Date();
    return n.getHours() * 60 + n.getMinutes();
  });

  useEffect(() => {
    const t = setInterval(() => {
      const n = new Date();
      setNowMin(n.getHours() * 60 + n.getMinutes());
    }, 60_000);
    return () => clearInterval(t);
  }, []);

  const days = Array.from({ length: 7 }, (_, i) => addDays(weekStart, i));
  const today = todayString();

  // Grid bounds: earliest open / latest close across the week (fallback 8–20).
  const { gridStart, gridEnd } = useMemo(() => {
    let start = Infinity;
    let end = -Infinity;
    for (const h of workingHours) {
      if (h.closed) continue;
      start = Math.min(start, toMinutes(h.open));
      end = Math.max(end, toMinutes(h.close));
    }
    if (!isFinite(start)) {
      start = 8 * 60;
      end = 20 * 60;
    }
    return { gridStart: start - 30, gridEnd: end + 30 };
  }, [workingHours]);

  const gridHeight = (gridEnd - gridStart) * PX_PER_MIN;
  const hourMarks: number[] = [];
  for (let m = Math.ceil(gridStart / 60) * 60; m <= gridEnd; m += 60) hourMarks.push(m);

  const visibleAppointments = appointments.filter(
    (a) => dentistId === "all" || a.dentistId === dentistId
  );
  const visibleBlocked = blocked.filter(
    (b) => dentistId === "all" || b.dentistId === null || b.dentistId === dentistId
  );

  const dentistName = (id: string | null) =>
    id === null ? "Whole clinic" : (dentists.find((d) => d.id === id)?.name ?? "");

  function navigate(offsetWeeks: number) {
    const target = offsetWeeks === 0 ? todayString() : addDays(weekStart, offsetWeeks * 7);
    router.push(`/admin/calendar?week=${target}`);
  }

  const monthLabel = new Date(days[3] + "T12:00:00").toLocaleDateString("en-US", {
    month: "long",
    year: "numeric",
  });

  return (
    <div>
      <div className="mb-6 flex flex-wrap items-center gap-3">
        <div>
          <h1 className="font-display text-2xl sm:text-3xl font-extrabold tracking-tight text-ink">
            Calendar
          </h1>
          <p className="mt-0.5 text-[15px] text-ink-soft">{monthLabel}</p>
        </div>
        <div className="ml-auto flex items-center gap-2">
          <Select
            value={dentistId}
            onChange={(e) => setDentistId(e.target.value)}
            className="w-auto h-10 py-0 text-sm"
          >
            <option value="all">All dentists</option>
            {dentists.map((d) => (
              <option key={d.id} value={d.id}>
                {d.name}
              </option>
            ))}
          </Select>
          <div className="flex items-center rounded-full border border-line bg-white p-1">
            <button
              onClick={() => navigate(-1)}
              className="rounded-full p-2 hover:bg-mist transition cursor-pointer"
              aria-label="Previous week"
            >
              <ChevronLeft size={16} />
            </button>
            <button
              onClick={() => navigate(0)}
              className="px-3 text-[13px] font-bold text-ink hover:text-brand transition cursor-pointer"
            >
              Today
            </button>
            <button
              onClick={() => navigate(1)}
              className="rounded-full p-2 hover:bg-mist transition cursor-pointer"
              aria-label="Next week"
            >
              <ChevronRight size={16} />
            </button>
          </div>
          <Button size="sm" variant="glass" onClick={() => { setBlockDefaults(null); setBlockOpen(true); }}>
            <Ban size={14} /> Block time
          </Button>
        </div>
      </div>

      <div className="overflow-x-auto rounded-3xl border border-line/70 bg-white scroll-thin">
        <div className="min-w-[860px]">
          {/* header row */}
          <div className="grid border-b border-line/70" style={{ gridTemplateColumns: "56px repeat(7, 1fr)" }}>
            <div />
            {days.map((date, i) => {
              const holiday = holidays.find((h) => h.date === date);
              const isToday = date === today;
              return (
                <div
                  key={date}
                  className={cn(
                    "border-l border-line/50 px-3 py-3 text-center",
                    isToday && "bg-brand-soft"
                  )}
                >
                  <p className="text-[11px] font-bold uppercase tracking-wide text-ink-faint">
                    {DAY_LABELS[i]}
                  </p>
                  <p
                    className={cn(
                      "font-display mx-auto mt-1 flex h-8 w-8 items-center justify-center rounded-full text-[15px] font-bold",
                      isToday ? "bg-brand text-white" : "text-ink"
                    )}
                  >
                    {Number(date.slice(8))}
                  </p>
                  {holiday && (
                    <p className="mt-1 truncate text-[10px] font-semibold text-red-500" title={holiday.name}>
                      {holiday.name}
                    </p>
                  )}
                </div>
              );
            })}
          </div>

          {/* grid */}
          <div className="grid" style={{ gridTemplateColumns: "56px repeat(7, 1fr)" }}>
            {/* hour gutter */}
            <div className="relative" style={{ height: gridHeight }}>
              {hourMarks.map((m) => (
                <span
                  key={m}
                  className="absolute right-2 -translate-y-1/2 text-[10.5px] font-semibold text-ink-faint"
                  style={{ top: (m - gridStart) * PX_PER_MIN }}
                >
                  {formatTime(toTimeString(m)).replace(":00", "")}
                </span>
              ))}
            </div>

            {days.map((date, dayIndex) => {
              const weekday = new Date(date + "T12:00:00").getDay();
              const hours = workingHours[weekday];
              const holiday = holidays.some((h) => h.date === date);
              const closed = hours.closed || holiday;
              const dayAppointments = visibleAppointments.filter((a) => a.date === date);
              const dayBlocked = visibleBlocked.filter((b) => b.date === date);
              const isToday = date === today;

              return (
                <div
                  key={date}
                  className={cn(
                    "relative border-l border-line/50",
                    dayIndex % 2 === 1 ? "bg-mist/30" : "bg-white"
                  )}
                  style={{ height: gridHeight }}
                  onDoubleClick={(e) => {
                    if (closed) return;
                    const rect = (e.currentTarget as HTMLDivElement).getBoundingClientRect();
                    const min = gridStart + (e.clientY - rect.top) / PX_PER_MIN;
                    const snapped = Math.floor(min / 30) * 30;
                    setBlockDefaults({ date, start: toTimeString(Math.max(snapped, 0)) });
                    setBlockOpen(true);
                  }}
                >
                  {/* hour lines */}
                  {hourMarks.map((m) => (
                    <div
                      key={m}
                      className="absolute inset-x-0 border-t border-line/40"
                      style={{ top: (m - gridStart) * PX_PER_MIN }}
                    />
                  ))}

                  {/* closed shading */}
                  {closed ? (
                    <div className="absolute inset-0 bg-[repeating-linear-gradient(135deg,transparent,transparent_8px,rgba(11,21,38,0.03)_8px,rgba(11,21,38,0.03)_16px)]">
                      <p className="mt-6 text-center text-[11px] font-bold uppercase tracking-wide text-ink-faint">
                        {holiday ? "Holiday" : "Closed"}
                      </p>
                    </div>
                  ) : (
                    <>
                      {/* outside working hours shading */}
                      <div
                        className="absolute inset-x-0 top-0 bg-mist/70"
                        style={{ height: (toMinutes(hours.open) - gridStart) * PX_PER_MIN }}
                      />
                      <div
                        className="absolute inset-x-0 bottom-0 bg-mist/70"
                        style={{ height: (gridEnd - toMinutes(hours.close)) * PX_PER_MIN }}
                      />
                    </>
                  )}

                  {/* now line */}
                  {isToday && nowMin > gridStart && nowMin < gridEnd && (
                    <div
                      className="absolute inset-x-0 z-20 flex items-center"
                      style={{ top: (nowMin - gridStart) * PX_PER_MIN }}
                    >
                      <span className="h-2 w-2 -ml-1 rounded-full bg-red-500" />
                      <div className="h-[2px] flex-1 bg-red-500/70" />
                    </div>
                  )}

                  {/* blocked slots */}
                  {dayBlocked.map((b) => (
                    <button
                      key={b.id}
                      onClick={() => role !== "dentist" && setDeleteBlock(b)}
                      title={`Blocked — ${b.reason || "unavailable"} (${dentistName(b.dentistId)})`}
                      className="absolute inset-x-1 z-10 overflow-hidden rounded-xl border border-slate-300 bg-[repeating-linear-gradient(135deg,#f1f5f9,#f1f5f9_6px,#e2e8f0_6px,#e2e8f0_12px)] px-2 py-1 text-left cursor-pointer"
                      style={{
                        top: (toMinutes(b.startTime) - gridStart) * PX_PER_MIN + 1,
                        height: (toMinutes(b.endTime) - toMinutes(b.startTime)) * PX_PER_MIN - 2,
                      }}
                    >
                      <p className="truncate text-[10.5px] font-bold text-slate-500">
                        <Ban size={9} className="mr-0.5 inline" />
                        {b.reason || "Blocked"}
                      </p>
                    </button>
                  ))}

                  {/* appointments */}
                  {dayAppointments.map((a) => {
                    const top = (toMinutes(a.startTime) - gridStart) * PX_PER_MIN;
                    const height =
                      (toMinutes(a.endTime) - toMinutes(a.startTime)) * PX_PER_MIN;
                    return (
                      <div
                        key={a.id}
                        title={`${formatTime(a.startTime)} · ${a.patientName} · ${a.serviceName} · ${a.dentistName}${a.issue ? `\n${a.issue}` : ""}`}
                        className={cn(
                          "absolute inset-x-1 z-10 overflow-hidden rounded-xl border px-2 py-1 shadow-sm",
                          STATUS_CHIP[a.status] ?? STATUS_CHIP.confirmed
                        )}
                        style={{ top: top + 1, height: Math.max(height - 2, 20) }}
                      >
                        <p className="truncate text-[10.5px] font-bold leading-tight">
                          {formatTime(a.startTime)} · {a.patientName}
                        </p>
                        {height > 34 && (
                          <p className="truncate text-[10px] opacity-75 leading-tight">
                            {a.serviceName}
                          </p>
                        )}
                        {height > 48 && dentistId === "all" && (
                          <p className="truncate text-[10px] opacity-60 leading-tight">
                            {a.dentistName}
                          </p>
                        )}
                      </div>
                    );
                  })}
                </div>
              );
            })}
          </div>
        </div>
      </div>

      <p className="mt-3 text-[12.5px] text-ink-faint">
        Tip: double-click any free area to block that time. Click a blocked strip to remove it.
      </p>

      {blockOpen && (
        <BlockTimeModal
          dentists={dentists}
          role={role}
          defaults={blockDefaults}
          weekStart={weekStart}
          onClose={() => setBlockOpen(false)}
        />
      )}

      <Modal
        open={deleteBlock !== null}
        onClose={() => setDeleteBlock(null)}
        title="Remove blocked time?"
      >
        {deleteBlock && (
          <DeleteBlockBody
            block={deleteBlock}
            dentistLabel={dentistName(deleteBlock.dentistId)}
            onClose={() => setDeleteBlock(null)}
          />
        )}
      </Modal>
    </div>
  );
}

/* ---------- block time modal ---------- */

function BlockTimeModal({
  dentists,
  role,
  defaults,
  weekStart,
  onClose,
}: {
  dentists: { id: string; name: string }[];
  role: string;
  defaults: { date: string; start: string } | null;
  weekStart: string;
  onClose: () => void;
}) {
  const router = useRouter();
  const [date, setDate] = useState(defaults?.date ?? (weekStart >= todayString() ? weekStart : todayString()));
  const [dentistId, setDentistId] = useState<string>("null");
  const [startTime, setStartTime] = useState(defaults?.start ?? "12:00");
  const [endTime, setEndTime] = useState(
    defaults ? toTimeString(Math.min(toMinutes(defaults.start) + 60, 23 * 60 + 30)) : "13:00"
  );
  const [reason, setReason] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function submit() {
    setBusy(true);
    setError(null);
    try {
      const res = await fetch("/api/admin/blocked", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          dentistId: dentistId === "null" ? null : dentistId,
          date,
          startTime,
          endTime,
          reason,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error ?? "Could not block this time.");
        return;
      }
      router.refresh();
      onClose();
    } finally {
      setBusy(false);
    }
  }

  return (
    <Modal open onClose={onClose} title="Block time">
      {error && (
        <div className="mb-4 rounded-2xl border border-red-100 bg-red-50 px-4 py-3 text-sm font-medium text-red-600">
          {error}
        </div>
      )}
      <div className="space-y-4">
        <div>
          <Label>Date</Label>
          <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
        </div>
        {role !== "dentist" && (
          <div>
            <Label>Applies to</Label>
            <Select value={dentistId} onChange={(e) => setDentistId(e.target.value)}>
              <option value="null">Whole clinic</option>
              {dentists.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.name}
                </option>
              ))}
            </Select>
          </div>
        )}
        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label>From</Label>
            <Input type="time" value={startTime} onChange={(e) => setStartTime(e.target.value)} />
          </div>
          <div>
            <Label>Until</Label>
            <Input type="time" value={endTime} onChange={(e) => setEndTime(e.target.value)} />
          </div>
        </div>
        <div>
          <Label>
            Reason <span className="font-normal text-ink-faint">(optional)</span>
          </Label>
          <Input
            placeholder="Lunch, training, equipment maintenance…"
            value={reason}
            onChange={(e) => setReason(e.target.value)}
          />
        </div>
        <Button size="lg" className="w-full" onClick={submit} disabled={busy}>
          {busy ? <Spinner /> : <Ban size={16} />}
          Block this time
        </Button>
      </div>
    </Modal>
  );
}

function DeleteBlockBody({
  block,
  dentistLabel,
  onClose,
}: {
  block: BlockedSlot;
  dentistLabel: string;
  onClose: () => void;
}) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);

  async function remove() {
    setBusy(true);
    try {
      const res = await fetch(`/api/admin/blocked/${block.id}`, { method: "DELETE" });
      if (res.ok) {
        router.refresh();
        onClose();
      }
    } finally {
      setBusy(false);
    }
  }

  return (
    <>
      <p className="text-[15px] text-ink-soft">
        {block.date} · {formatTime(block.startTime)}–{formatTime(block.endTime)} ·{" "}
        {dentistLabel}
        {block.reason && (
          <>
            <br />
            <span className="text-ink font-medium">"{block.reason}"</span>
          </>
        )}
      </p>
      <div className="mt-6 grid grid-cols-2 gap-2.5">
        <Button variant="glass" onClick={onClose}>
          Keep it
        </Button>
        <Button variant="danger" onClick={remove} disabled={busy}>
          {busy ? <Spinner /> : <Trash2 size={15} />} Remove
        </Button>
      </div>
    </>
  );
}
