"use client";

import { useEffect, useRef } from "react";
import * as THREE from "three";

type DottedSurfaceProps = {
  /** Pick the palette for the surface this sits on: dark → icy blue neon glow, light → deep blue neon glow. */
  variant: "dark" | "light";
  className?: string;
};

const AMOUNT_X = 44;
const AMOUNT_Z = 30;
const SEPARATION = 34;
const WAVE_HEIGHT = 13;

/** Resolves a CSS color expression (e.g. one of the app's color-mix() tokens)
 *  through the DOM so the neon dots pick up each clinic's own brand color. */
function resolveCssColor(expr: string, fallback: string): THREE.Color {
  const probe = document.createElement("div");
  probe.style.color = expr;
  document.body.appendChild(probe);
  const computed = getComputedStyle(probe).color;
  document.body.removeChild(probe);
  const color = new THREE.Color();
  try {
    color.setStyle(computed || fallback);
  } catch {
    color.setStyle(fallback);
  }
  return color;
}

/** Soft round sprite so points render as glowing dots instead of hard squares. */
function makeDotTexture(): THREE.CanvasTexture {
  const size = 64;
  const canvas = document.createElement("canvas");
  canvas.width = canvas.height = size;
  const ctx = canvas.getContext("2d")!;
  const grad = ctx.createRadialGradient(
    size / 2, size / 2, 0,
    size / 2, size / 2, size / 2
  );
  grad.addColorStop(0, "rgba(255,255,255,1)");
  grad.addColorStop(0.5, "rgba(255,255,255,0.55)");
  grad.addColorStop(1, "rgba(255,255,255,0)");
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, size, size);
  const texture = new THREE.CanvasTexture(canvas);
  texture.needsUpdate = true;
  return texture;
}

export function DottedSurface({ variant, className }: DottedSurfaceProps) {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const isDark = variant === "dark";
    const reduceMotion = window.matchMedia(
      "(prefers-reduced-motion: reduce)"
    ).matches;

    const dotColor = resolveCssColor(
      isDark
        ? "color-mix(in srgb, var(--brand) 55%, white)"
        : "color-mix(in srgb, var(--brand) 85%, black)",
      isDark ? "#bcdcff" : "#0f2f80"
    );

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(55, 1, 1, 3000);
    camera.position.set(0, 210, 480);
    camera.lookAt(0, -40, 0);

    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true });
    } catch {
      // WebGL unavailable (old browser, disabled GPU, restricted context) —
      // skip the decorative effect entirely rather than throwing.
      return;
    }
    if (!renderer.getContext()) {
      renderer.dispose();
      return;
    }
    renderer.setClearColor(0x000000, 0);
    container.appendChild(renderer.domElement);

    const texture = makeDotTexture();
    const positions: number[] = [];
    for (let ix = 0; ix < AMOUNT_X; ix++) {
      for (let iz = 0; iz < AMOUNT_Z; iz++) {
        positions.push(
          ix * SEPARATION - (AMOUNT_X * SEPARATION) / 2,
          0,
          iz * SEPARATION - (AMOUNT_Z * SEPARATION) / 2
        );
      }
    }
    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute(
      "position",
      new THREE.Float32BufferAttribute(positions, 3)
    );

    const material = new THREE.PointsMaterial({
      map: texture,
      size: 9,
      color: dotColor,
      transparent: true,
      opacity: isDark ? 0.95 : 0.85,
      depthWrite: false,
      blending: isDark ? THREE.AdditiveBlending : THREE.NormalBlending,
      sizeAttenuation: true,
    });
    const points = new THREE.Points(geometry, material);
    scene.add(points);

    const posAttr = geometry.attributes.position;
    const posArray = posAttr.array as Float32Array;

    const resize = () => {
      const { width, height } = container.getBoundingClientRect();
      if (width === 0 || height === 0) return;
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
      renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
      renderer.setSize(width, height);
    };
    resize();

    const ro = new ResizeObserver(resize);
    ro.observe(container);

    let raf = 0;
    let t = 0;

    const render = () => renderer.render(scene, camera);

    const animate = () => {
      raf = requestAnimationFrame(animate);
      let i = 0;
      for (let ix = 0; ix < AMOUNT_X; ix++) {
        for (let iz = 0; iz < AMOUNT_Z; iz++) {
          posArray[i * 3 + 1] =
            Math.sin((ix + t) * 0.3) * WAVE_HEIGHT +
            Math.sin((iz + t) * 0.4) * WAVE_HEIGHT;
          i++;
        }
      }
      posAttr.needsUpdate = true;
      t += 0.045;
      render();
    };

    if (reduceMotion) {
      render();
    } else {
      animate();
    }

    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
      geometry.dispose();
      texture.dispose();
      material.dispose();
      renderer.dispose();
      container.removeChild(renderer.domElement);
    };
  }, [variant]);

  return (
    <div
      ref={containerRef}
      aria-hidden
      className={`dotted-surface ${className ?? ""}`}
    />
  );
}
