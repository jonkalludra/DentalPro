import { clinicBySlug } from "@/lib/store";
import type { Metadata } from "next";
import { notFound } from "next/navigation";
import type { CSSProperties } from "react";

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const clinic = clinicBySlug(slug);
  if (!clinic) return {};
  return {
    title: {
      default: `${clinic.name} — ${clinic.tagline}`,
      template: `%s | ${clinic.name}`,
    },
    description: `${clinic.heroSubheadline} ${clinic.name}, ${clinic.address}, ${clinic.city}. Call ${clinic.phone}.`,
    openGraph: {
      title: clinic.name,
      description: clinic.heroSubheadline,
      type: "website",
    },
  };
}

export default async function ClinicLayout({
  children,
  params,
}: {
  children: React.ReactNode;
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const clinic = clinicBySlug(slug);
  if (!clinic || !clinic.published) notFound();

  return (
    <div
      style={{ "--brand": clinic.primaryColor } as CSSProperties}
      className="min-h-screen bg-white"
    >
      {children}
    </div>
  );
}
