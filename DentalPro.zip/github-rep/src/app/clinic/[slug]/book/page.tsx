import { BookingWizard } from "@/components/booking/BookingWizard";
import { clinicBySlug, dentistsOf, servicesOf } from "@/lib/store";
import type { Metadata } from "next";
import { notFound } from "next/navigation";

export const metadata: Metadata = { title: "Book Appointment" };

export default async function BookPage({
  params,
  searchParams,
}: {
  params: Promise<{ slug: string }>;
  searchParams: Promise<{ service?: string }>;
}) {
  const { slug } = await params;
  const { service } = await searchParams;
  const clinic = clinicBySlug(slug);
  if (!clinic) notFound();

  return (
    <BookingWizard
      slug={clinic.slug}
      clinicName={clinic.name}
      logoUrl={clinic.logoUrl}
      phone={clinic.phone}
      address={`${clinic.address}, ${clinic.city}`}
      instructions={clinic.patientInstructions}
      preselectedServiceId={service ?? null}
      services={servicesOf(clinic.id, true).map((s) => ({
        id: s.id,
        name: s.name,
        description: s.description,
        durationMinutes: s.durationMinutes,
        price: s.price,
        icon: s.icon,
      }))}
      dentists={dentistsOf(clinic.id, true).map((d) => ({
        id: d.id,
        name: d.name,
        title: d.title,
      }))}
    />
  );
}
