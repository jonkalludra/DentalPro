import { About } from "@/components/site/About";
import { Contact } from "@/components/site/Contact";
import { Footer } from "@/components/site/Footer";
import { Hero } from "@/components/site/Hero";
import { HowItWorks } from "@/components/site/HowItWorks";
import { MobileCta } from "@/components/site/MobileCta";
import { Navbar } from "@/components/site/Navbar";
import { Reviews } from "@/components/site/Reviews";
import { Services } from "@/components/site/Services";
import { clinicBySlug, dentistsOf, reviewsOf, servicesOf } from "@/lib/store";
import { notFound } from "next/navigation";

export default async function ClinicHomePage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const clinic = clinicBySlug(slug);
  if (!clinic) notFound();

  const base = `/clinic/${clinic.slug}`;
  const services = servicesOf(clinic.id, true);
  const dentists = dentistsOf(clinic.id, true);
  const reviews = reviewsOf(clinic.id);

  return (
    <>
      <Navbar
        base={base}
        name={clinic.name}
        logoUrl={clinic.logoUrl}
        phone={clinic.phone}
      />
      <main>
        <Hero
          base={base}
          headline={clinic.heroHeadline}
          subheadline={clinic.heroSubheadline}
          phone={clinic.phone}
          patients={clinic.stats.happyPatients}
        />
        <HowItWorks />
        <Services
          base={base}
          services={services.map((s) => ({
            id: s.id,
            name: s.name,
            description: s.description,
            durationMinutes: s.durationMinutes,
            price: s.price,
            icon: s.icon,
          }))}
        />
        <About
          name={clinic.name}
          aboutText={clinic.aboutText}
          stats={clinic.stats}
          dentists={dentists.map((d) => ({ id: d.id, name: d.name, title: d.title }))}
        />
        <Reviews
          reviews={reviews.map((r) => ({
            id: r.id,
            name: r.name,
            rating: r.rating,
            text: r.text,
            treatment: r.treatment,
          }))}
        />
        <Contact
          address={clinic.address}
          city={clinic.city}
          phone={clinic.phone}
          emergencyPhone={clinic.emergencyPhone}
          email={clinic.email}
          mapsEmbedUrl={clinic.mapsEmbedUrl}
          workingHours={clinic.workingHours}
        />
      </main>
      <Footer
        base={base}
        name={clinic.name}
        tagline={clinic.tagline}
        address={clinic.address}
        city={clinic.city}
        phone={clinic.phone}
        socials={clinic.socials}
        services={services.map((s) => ({ id: s.id, name: s.name }))}
      />
      <MobileCta base={base} phone={clinic.phone} />
    </>
  );
}
