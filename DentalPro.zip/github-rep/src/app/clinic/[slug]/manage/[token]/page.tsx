import { ManageAppointment } from "@/components/booking/ManageAppointment";
import { clinicBySlug, db, dentistsOf, servicesOf } from "@/lib/store";
import { todayString, toMinutes } from "@/lib/utils";
import type { Metadata } from "next";
import { notFound } from "next/navigation";

export const metadata: Metadata = { title: "Manage Appointment" };

export default async function ManagePage({
  params,
}: {
  params: Promise<{ slug: string; token: string }>;
}) {
  const { slug, token } = await params;
  const clinic = clinicBySlug(slug);
  if (!clinic) notFound();

  const appointment = db().appointments.find(
    (a) => a.clinicId === clinic.id && a.manageToken === token
  );
  if (!appointment) notFound();

  const service = servicesOf(clinic.id).find((s) => s.id === appointment.serviceId);
  const dentist = dentistsOf(clinic.id).find((d) => d.id === appointment.dentistId);
  const patient = db().patients.find((p) => p.id === appointment.patientId);

  const now = new Date();
  const isFuture =
    appointment.date > todayString() ||
    (appointment.date === todayString() &&
      toMinutes(appointment.startTime) > now.getHours() * 60 + now.getMinutes());
  const manageable =
    (appointment.status === "confirmed" || appointment.status === "pending") && isFuture;

  return (
    <ManageAppointment
      slug={clinic.slug}
      token={token}
      clinicName={clinic.name}
      logoUrl={clinic.logoUrl}
      clinicPhone={clinic.phone}
      address={`${clinic.address}, ${clinic.city}`}
      patientFirstName={patient?.firstName ?? ""}
      appointment={{
        id: appointment.id,
        date: appointment.date,
        startTime: appointment.startTime,
        status: appointment.status,
        service: service?.name ?? "Appointment",
        dentist: dentist?.name ?? "",
        manageable,
      }}
      icsUrl={`/api/public/${clinic.slug}/ics/${appointment.id}?token=${token}`}
    />
  );
}
