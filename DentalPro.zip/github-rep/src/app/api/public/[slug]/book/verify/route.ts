import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { resolveSlot } from "@/lib/availability";
import { confirmationSms, manageUrl, requestOrigin } from "@/lib/booking";
import { googleCalendarUrl } from "@/lib/ics";
import { isDemoSms, sendClinicSms, smsProvider } from "@/lib/sms";
import {
  clinicBySlug,
  db,
  dentistsOf,
  findPatientByPhone,
  save,
  servicesOf,
  token,
  uid,
} from "@/lib/store";
import type { Appointment } from "@/lib/types";
import { formatDateLong, formatTime, toMinutes, toTimeString } from "@/lib/utils";

const schema = z.object({
  sessionId: z.string().min(1),
  code: z.string().trim().regex(/^\d{4,8}$/),
});

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ slug: string }> }
) {
  const { slug } = await params;
  const clinic = clinicBySlug(slug);
  if (!clinic) return NextResponse.json({ error: "Clinic not found" }, { status: 404 });

  const parsed = schema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) {
    return NextResponse.json({ error: "Please enter the 6-digit code." }, { status: 400 });
  }

  const session = db().bookingSessions.find(
    (s) => s.id === parsed.data.sessionId && s.clinicId === clinic.id
  );
  if (!session || session.expiresAt < Date.now()) {
    return NextResponse.json(
      { error: "session_expired", message: "Your session expired. Please start again." },
      { status: 410 }
    );
  }

  session.attempts += 1;
  if (session.attempts > 6) {
    db().bookingSessions = db().bookingSessions.filter((s) => s.id !== session.id);
    save();
    return NextResponse.json(
      { error: "session_expired", message: "Too many attempts. Please start again." },
      { status: 429 }
    );
  }

  const check = await smsProvider().checkOtp(session.phone, parsed.data.code);
  if (!check.ok) {
    save();
    return NextResponse.json(
      { error: check.error ?? "Incorrect code. Please try again." },
      { status: 401 }
    );
  }

  const payload = session.payload;
  const service = servicesOf(clinic.id, true).find((s) => s.id === payload.serviceId);
  if (!service) return NextResponse.json({ error: "Service not found" }, { status: 404 });

  const candidates =
    payload.dentistId === "any"
      ? dentistsOf(clinic.id, true)
      : dentistsOf(clinic.id, true).filter((d) => d.id === payload.dentistId);

  // Final availability check — the slot may have been taken while verifying.
  const assignedDentistId = resolveSlot(
    clinic, service, candidates, payload.date, payload.time
  );
  if (!assignedDentistId) {
    return NextResponse.json(
      { error: "slot_taken", message: "That time was just booked. Please pick another slot." },
      { status: 409 }
    );
  }

  // Find or create the patient by phone (no accounts, ever).
  let patient = findPatientByPhone(clinic.id, session.phone);
  if (!patient) {
    patient = {
      id: uid(),
      clinicId: clinic.id,
      firstName: payload.firstName,
      lastName: payload.lastName,
      phone: session.phone,
      email: null,
      createdAt: new Date().toISOString(),
    };
    db().patients.push(patient);
  } else {
    patient.firstName = payload.firstName;
    patient.lastName = payload.lastName;
  }

  const startMin = toMinutes(payload.time);
  const appointment: Appointment = {
    id: uid(),
    clinicId: clinic.id,
    patientId: patient.id,
    dentistId: assignedDentistId,
    serviceId: service.id,
    date: payload.date,
    startTime: payload.time,
    endTime: toTimeString(startMin + service.durationMinutes),
    status: "confirmed",
    issue: payload.issue,
    manageToken: token(),
    source: "online",
    reminderSentAt: null,
    createdAt: new Date().toISOString(),
  };
  db().appointments.push(appointment);
  db().bookingSessions = db().bookingSessions.filter((s) => s.id !== session.id);
  save();

  const dentist = dentistsOf(clinic.id).find((d) => d.id === assignedDentistId);
  const origin = requestOrigin(req);
  const link = manageUrl(origin, clinic.slug, appointment.manageToken);
  const smsBody = confirmationSms(clinic, service, dentist, appointment, link);
  await sendClinicSms(clinic.id, session.phone, smsBody, "confirmation");

  return NextResponse.json({
    appointment: {
      id: appointment.id,
      date: appointment.date,
      dateLong: formatDateLong(appointment.date),
      startTime: appointment.startTime,
      timeLabel: formatTime(appointment.startTime),
      endTime: appointment.endTime,
      service: service.name,
      dentist: dentist?.name ?? "",
      clinicName: clinic.name,
      address: `${clinic.address}, ${clinic.city}`,
      phone: clinic.phone,
    },
    manageUrl: link,
    icsUrl: `/api/public/${clinic.slug}/ics/${appointment.id}?token=${appointment.manageToken}`,
    googleCalendarUrl: googleCalendarUrl(appointment, clinic, service),
    smsPreview: isDemoSms() ? smsBody : undefined,
  });
}
