import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { resolveSlot } from "@/lib/availability";
import { smsProvider } from "@/lib/sms";
import { clinicBySlug, db, dentistsOf, save, servicesOf, uid } from "@/lib/store";
import { normalizePhone } from "@/lib/utils";

const schema = z.object({
  serviceId: z.string().min(1),
  dentistId: z.string().min(1), // dentist id or "any"
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  time: z.string().regex(/^\d{2}:\d{2}$/),
  firstName: z.string().trim().min(2).max(60),
  lastName: z.string().trim().min(2).max(60),
  phone: z.string().trim().min(6).max(24),
  issue: z.string().trim().max(600).optional().default(""),
});

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ slug: string }> }
) {
  const { slug } = await params;
  const clinic = clinicBySlug(slug);
  if (!clinic) return NextResponse.json({ error: "Clinic not found" }, { status: 404 });

  const parsed = schema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Please check your details and try again." },
      { status: 400 }
    );
  }
  const data = parsed.data;

  const phone = normalizePhone(data.phone);
  if (!phone) {
    return NextResponse.json(
      { error: "Please enter a valid phone number." },
      { status: 400 }
    );
  }

  const service = servicesOf(clinic.id, true).find((s) => s.id === data.serviceId);
  if (!service) return NextResponse.json({ error: "Service not found" }, { status: 404 });

  const candidates =
    data.dentistId === "any"
      ? dentistsOf(clinic.id, true)
      : dentistsOf(clinic.id, true).filter((d) => d.id === data.dentistId);
  if (candidates.length === 0)
    return NextResponse.json({ error: "Dentist not found" }, { status: 404 });

  // Verify the slot is (still) available before sending a code.
  const assigned = resolveSlot(clinic, service, candidates, data.date, data.time);
  if (!assigned) {
    return NextResponse.json(
      { error: "slot_taken", message: "That time was just booked. Please pick another slot." },
      { status: 409 }
    );
  }

  // Light rate limiting per phone number.
  const now = Date.now();
  db().bookingSessions = db().bookingSessions.filter((s) => s.expiresAt > now);
  const recent = db().bookingSessions.filter((s) => s.phone === phone);
  if (recent.length >= 4) {
    return NextResponse.json(
      { error: "Too many attempts. Please wait a few minutes and try again." },
      { status: 429 }
    );
  }

  const sms = await smsProvider().sendOtp(phone);
  if (!sms.ok) {
    return NextResponse.json(
      { error: sms.error ?? "Could not send the verification code." },
      { status: 502 }
    );
  }

  const session = {
    id: uid(),
    clinicId: clinic.id,
    phone,
    payload: { ...data, phone },
    mockCode: sms.demoCode ?? null,
    attempts: 0,
    expiresAt: now + 10 * 60_000,
    createdAt: now,
  };
  db().bookingSessions.push(session);
  save();

  return NextResponse.json({
    sessionId: session.id,
    phone,
    // Only present with the mock provider — lets the demo run without real SMS.
    demoCode: sms.demoCode,
  });
}
