import { NextRequest, NextResponse } from "next/server";
import { daySummaries } from "@/lib/availability";
import { clinicBySlug, dentistsOf, servicesOf } from "@/lib/store";
import { todayString } from "@/lib/utils";

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ slug: string }> }
) {
  const { slug } = await params;
  const clinic = clinicBySlug(slug);
  if (!clinic) return NextResponse.json({ error: "Clinic not found" }, { status: 404 });

  const sp = req.nextUrl.searchParams;
  const serviceId = sp.get("serviceId") ?? "";
  const dentistId = sp.get("dentistId") ?? "any";
  const from = sp.get("from") ?? todayString();
  const count = Math.min(Number(sp.get("count") ?? 21), 62);

  const service = servicesOf(clinic.id, true).find((s) => s.id === serviceId);
  if (!service) return NextResponse.json({ error: "Service not found" }, { status: 404 });

  let dentists = dentistsOf(clinic.id, true);
  if (dentistId !== "any") {
    dentists = dentists.filter((d) => d.id === dentistId);
    if (dentists.length === 0)
      return NextResponse.json({ error: "Dentist not found" }, { status: 404 });
  }

  return NextResponse.json({
    days: daySummaries(clinic, service, dentists, from, count),
  });
}
