import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { resolveSlot, slotsForDay } from "@/lib/availability";
import { sendClinicSms } from "@/lib/sms";
import { clinicBySlug, db, dentistsOf, save, servicesOf } from "@/lib/store";
import {
  formatDateLong,
  formatTime,
  todayString,
  toMinutes,
  toTimeString,
} from "@/lib/utils";

function findAppointment(clinicId: string, manageToken: string) {
  return db().appointments.find(
    (a) => a.clinicId === clinicId && a.manageToken === manageToken
  );
}

function isManageable(a: { status: string; date: string; startTime: string }): boolean {
  if (a.status !== "confirmed" && a.status !== "pending") return false;
  const today = todayString();
  if (a.date > today) return true;
  if (a.date < today) return false;
  const now = new Date();
  return toMinutes(a.startTime) > now.getHours() * 60 + now.getMinutes();
}

/** GET — available slots for rescheduling (?date=YYYY-MM-DD&any=1) */
export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ slug: string; token: string }> }
) {
  const { slug, token } = await params;
  const clinic = clinicBySlug(slug);
  if (!clinic) return NextResponse.json({ error: "Clinic not found" }, { status: 404 });

  const appointment = findAppointment(clinic.id, token);
  if (!appointment)
    return NextResponse.json({ error: "Appointment not found" }, { status: 404 });

  const date = req.nextUrl.searchParams.get("date") ?? "";
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date))
    return NextResponse.json({ error: "Invalid date" }, { status: 400 });

  const service = servicesOf(clinic.id).find((s) => s.id === appointment.serviceId);
  if (!service) return NextResponse.json({ error: "Service not found" }, { status: 404 });

  const any = req.nextUrl.searchParams.get("any") === "1";
  const dentists = any
    ? dentistsOf(clinic.id, true)
    : dentistsOf(clinic.id, true).filter((d) => d.id === appointment.dentistId);

  const slots = slotsForDay(clinic, service, dentists, date, {
    ignoreAppointmentId: appointment.id,
  });
  return NextResponse.json({ slots: slots.map((s) => s.time) });
}

const actionSchema = z.discriminatedUnion("action", [
  z.object({ action: z.literal("cancel") }),
  z.object({
    action: z.literal("reschedule"),
    date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
    time: z.string().regex(/^\d{2}:\d{2}$/),
    any: z.boolean().optional().default(false),
  }),
]);

/** POST — cancel or reschedule via the secure SMS link. */
export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ slug: string; token: string }> }
) {
  const { slug, token } = await params;
  const clinic = clinicBySlug(slug);
  if (!clinic) return NextResponse.json({ error: "Clinic not found" }, { status: 404 });

  const appointment = findAppointment(clinic.id, token);
  if (!appointment)
    return NextResponse.json({ error: "Appointment not found" }, { status: 404 });

  const parsed = actionSchema.safeParse(await req.json().catch(() => null));
  if (!parsed.success)
    return NextResponse.json({ error: "Invalid request" }, { status: 400 });

  if (!isManageable(appointment)) {
    return NextResponse.json(
      { error: "This appointment can no longer be changed online. Please call the clinic." },
      { status: 409 }
    );
  }

  const patient = db().patients.find((p) => p.id === appointment.patientId);
  const service = servicesOf(clinic.id).find((s) => s.id === appointment.serviceId);

  if (parsed.data.action === "cancel") {
    appointment.status = "cancelled";
    save();
    if (patient) {
      await sendClinicSms(
        clinic.id,
        patient.phone,
        `${clinic.name}: Your appointment on ${formatDateLong(appointment.date)} at ${formatTime(appointment.startTime)} has been cancelled.`,
        "update"
      );
    }
    return NextResponse.json({ ok: true, status: "cancelled" });
  }

  // reschedule
  if (!service) return NextResponse.json({ error: "Service not found" }, { status: 404 });
  const candidates = parsed.data.any
    ? dentistsOf(clinic.id, true)
    : dentistsOf(clinic.id, true).filter((d) => d.id === appointment.dentistId);

  const assigned = resolveSlot(
    clinic, service, candidates, parsed.data.date, parsed.data.time,
    { ignoreAppointmentId: appointment.id }
  );
  if (!assigned) {
    return NextResponse.json(
      { error: "slot_taken", message: "That time is no longer available. Please pick another slot." },
      { status: 409 }
    );
  }

  appointment.dentistId = assigned;
  appointment.date = parsed.data.date;
  appointment.startTime = parsed.data.time;
  appointment.endTime = toTimeString(
    toMinutes(parsed.data.time) + service.durationMinutes
  );
  appointment.reminderSentAt = null; // re-arm the 24h reminder
  save();

  if (patient) {
    await sendClinicSms(
      clinic.id,
      patient.phone,
      `${clinic.name}: Your appointment has been moved to ${formatDateLong(appointment.date)} at ${formatTime(appointment.startTime)}.`,
      "update"
    );
  }
  return NextResponse.json({
    ok: true,
    status: "rescheduled",
    date: appointment.date,
    dateLong: formatDateLong(appointment.date),
    time: appointment.startTime,
    timeLabel: formatTime(appointment.startTime),
  });
}
