import { NextRequest, NextResponse } from "next/server";
import { buildIcs } from "@/lib/ics";
import { clinicBySlug, db, servicesOf } from "@/lib/store";

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ slug: string; id: string }> }
) {
  const { slug, id } = await params;
  const clinic = clinicBySlug(slug);
  if (!clinic) return NextResponse.json({ error: "Clinic not found" }, { status: 404 });

  const appointment = db().appointments.find(
    (a) => a.id === id && a.clinicId === clinic.id
  );
  const token = req.nextUrl.searchParams.get("token");
  if (!appointment || !token || appointment.manageToken !== token) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const service = servicesOf(clinic.id).find((s) => s.id === appointment.serviceId);
  if (!service) return NextResponse.json({ error: "Not found" }, { status: 404 });

  return new NextResponse(buildIcs(appointment, clinic, service), {
    headers: {
      "Content-Type": "text/calendar; charset=utf-8",
      "Content-Disposition": `attachment; filename="appointment-${appointment.date}.ics"`,
    },
  });
}
