import { NextRequest, NextResponse } from "next/server";
import { slotsForDay } from "@/lib/availability";
import { clinicBySlug, dentistsOf, servicesOf } from "@/lib/store";

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ slug: string }> }
) {
  const { slug } = await params;
  const clinic = clinicBySlug(slug);
  if (!clinic) return NextResponse.json({ error: "Clinic not found" }, { status: 404 });

  const sp = req.nextUrl.searchParams;
  const serviceId = sp.get("serviceId") ?? "";
  const dentistId = sp.get("dentistId") ?? "any";
  const date = sp.get("date") ?? "";

  if (!/^\d{4}-\d{2}-\d{2}$/.test(date))
    return NextResponse.json({ error: "Invalid date" }, { status: 400 });

  const service = servicesOf(clinic.id, true).find((s) => s.id === serviceId);
  if (!service) return NextResponse.json({ error: "Service not found" }, { status: 404 });

  let dentists = dentistsOf(clinic.id, true);
  if (dentistId !== "any") {
    dentists = dentists.filter((d) => d.id === dentistId);
    if (dentists.length === 0)
      return NextResponse.json({ error: "Dentist not found" }, { status: 404 });
  }

  const slots = slotsForDay(clinic, service, dentists, date);
  return NextResponse.json({ slots: slots.map((s) => s.time) });
}
