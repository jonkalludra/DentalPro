import { NextRequest, NextResponse } from "next/server";
import { requireAdmin } from "@/lib/adminAuth";
import { db, save } from "@/lib/store";
import { serviceSchema } from "@/lib/schemas";

export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const ctx = await requireAdmin(req, "services");
  if (ctx instanceof NextResponse) return ctx;
  const { clinic } = ctx;
  const { id } = await params;

  const service = db().services.find(
    (s) => s.id === id && s.clinicId === clinic.id
  );
  if (!service) return NextResponse.json({ error: "Not found" }, { status: 404 });

  const parsed = serviceSchema.partial().safeParse(await req.json().catch(() => null));
  if (!parsed.success) {
    return NextResponse.json({ error: "Please check the form." }, { status: 400 });
  }
  Object.assign(service, parsed.data);
  save();
  return NextResponse.json({ ok: true });
}

export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const ctx = await requireAdmin(req, "services");
  if (ctx instanceof NextResponse) return ctx;
  const { clinic } = ctx;
  const { id } = await params;

  const service = db().services.find(
    (s) => s.id === id && s.clinicId === clinic.id
  );
  if (!service) return NextResponse.json({ error: "Not found" }, { status: 404 });

  const used = db().appointments.some(
    (a) => a.clinicId === clinic.id && a.serviceId === id
  );
  if (used) {
    return NextResponse.json(
      { error: "This service has appointments. Deactivate it instead of deleting." },
      { status: 409 }
    );
  }

  db().services = db().services.filter((s) => s.id !== id);
  save();
  return NextResponse.json({ ok: true });
}
