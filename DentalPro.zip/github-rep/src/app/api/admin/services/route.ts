import { NextRequest, NextResponse } from "next/server";
import { requireAdmin } from "@/lib/adminAuth";
import { serviceSchema } from "@/lib/schemas";
import { db, save, servicesOf, uid } from "@/lib/store";

export async function POST(req: NextRequest) {
  const ctx = await requireAdmin(req, "services");
  if (ctx instanceof NextResponse) return ctx;
  const { clinic } = ctx;

  const parsed = serviceSchema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) {
    return NextResponse.json({ error: "Please check the form." }, { status: 400 });
  }

  const maxOrder = Math.max(0, ...servicesOf(clinic.id).map((s) => s.sortOrder));
  db().services.push({
    id: uid(),
    clinicId: clinic.id,
    ...parsed.data,
    sortOrder: maxOrder + 1,
  });
  save();
  return NextResponse.json({ ok: true });
}
