import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { requirePlatformAdmin } from "@/lib/adminAuth";
import { createSessionToken, SESSION_COOKIE } from "@/lib/session";
import { clinicById } from "@/lib/store";

/** Super admins can hop between clinic dashboards. */
export async function POST(req: NextRequest) {
  const session = await requirePlatformAdmin(req);
  if (session instanceof NextResponse) return session;

  const parsed = z
    .object({ clinicId: z.string().min(1) })
    .safeParse(await req.json().catch(() => null));
  if (!parsed.success || !clinicById(parsed.data.clinicId)) {
    return NextResponse.json({ error: "Clinic not found" }, { status: 404 });
  }

  const token = await createSessionToken({
    userId: session.userId,
    role: session.role,
    clinicId: parsed.data.clinicId,
    dentistId: session.dentistId,
    name: session.name,
  });

  const res = NextResponse.json({ ok: true });
  res.cookies.set(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    maxAge: 60 * 60 * 24 * 7,
    path: "/",
  });
  return res;
}
