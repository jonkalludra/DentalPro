import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { requirePlatformAdmin } from "@/lib/adminAuth";
import { hashPassword } from "@/lib/password";
import {
  db, DEFAULT_SERVICES, DEFAULT_SMS_TEMPLATES, DEFAULT_WEEK_HOURS,
  save, uid, userByEmail,
} from "@/lib/store";

const schema = z.object({
  name: z.string().trim().min(2).max(80),
  slug: z
    .string()
    .trim()
    .toLowerCase()
    .regex(/^[a-z0-9](?:[a-z0-9-]{1,38}[a-z0-9])$/, "Slug must be lowercase letters, numbers and dashes"),
  city: z.string().trim().min(2).max(80),
  address: z.string().trim().max(140).optional().default(""),
  phone: z.string().trim().min(5).max(30),
  primaryColor: z.string().regex(/^#[0-9a-fA-F]{6}$/).optional().default("#2563eb"),
  ownerName: z.string().trim().min(2).max(80),
  ownerEmail: z.string().email(),
  ownerPassword: z.string().min(8).max(100),
});

const RESERVED_SLUGS = new Set(["admin", "api", "clinic", "www", "app", "book"]);

/** Platform admin creates a new clinic with sensible defaults + owner login. */
export async function POST(req: NextRequest) {
  const session = await requirePlatformAdmin(req);
  if (session instanceof NextResponse) return session;

  const parsed = schema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) {
    const issue = parsed.error.issues[0];
    return NextResponse.json(
      { error: issue?.message ?? "Please check the form." },
      { status: 400 }
    );
  }
  const data = parsed.data;

  if (RESERVED_SLUGS.has(data.slug) || db().clinics.some((c) => c.slug === data.slug)) {
    return NextResponse.json(
      { error: "This subdomain is already taken." },
      { status: 409 }
    );
  }
  if (userByEmail(data.ownerEmail)) {
    return NextResponse.json(
      { error: "A user with this email already exists." },
      { status: 409 }
    );
  }

  const clinicId = uid();
  db().clinics.push({
    id: clinicId,
    slug: data.slug,
    name: data.name,
    tagline: `Modern dentistry in ${data.city}`,
    logoUrl: null,
    primaryColor: data.primaryColor,
    heroHeadline: "Healthy Smiles Start Here.",
    heroSubheadline:
      "Book your appointment in less than a minute. No account required.",
    aboutText: `${data.name} combines modern technology with a warm, personal approach. Our team takes time to listen, explain and make every visit comfortable.`,
    patientInstructions: "Please arrive 5 minutes before your appointment.",
    address: data.address,
    city: data.city,
    phone: data.phone,
    emergencyPhone: data.phone,
    email: "",
    mapsEmbedUrl: `https://www.google.com/maps?q=${encodeURIComponent(data.city)}&output=embed`,
    socials: { facebook: "", instagram: "", tiktok: "" },
    stats: { yearsExperience: 5, happyPatients: 1000, certifiedDentists: 2 },
    workingHours: DEFAULT_WEEK_HOURS.map((h) => ({ ...h })),
    holidays: [],
    slotStepMinutes: 30,
    minLeadMinutes: 60,
    maxAdvanceDays: 60,
    smsTemplates: { ...DEFAULT_SMS_TEMPLATES },
    timezone: "Europe/Belgrade",
    published: true,
    createdAt: new Date().toISOString(),
  });

  for (const [i, s] of DEFAULT_SERVICES.entries()) {
    db().services.push({
      id: uid(),
      clinicId,
      ...s,
      active: true,
      sortOrder: i,
    });
  }

  db().users.push({
    id: uid(),
    clinicId,
    role: "owner",
    name: data.ownerName,
    email: data.ownerEmail.toLowerCase().trim(),
    passwordHash: hashPassword(data.ownerPassword),
    dentistId: null,
    createdAt: new Date().toISOString(),
  });

  save();
  return NextResponse.json({ ok: true, clinicId, slug: data.slug });
}
