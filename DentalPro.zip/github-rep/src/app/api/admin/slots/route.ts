import { NextRequest, NextResponse } from "next/server";
import { requireAdmin } from "@/lib/adminAuth";
import { slotsForDay } from "@/lib/availability";
import { dentistsOf, servicesOf } from "@/lib/store";

/** Availability lookup for the staff booking/reschedule modals (no lead-time limit). */
export async function GET(req: NextRequest) {
  const ctx = await requireAdmin(req, "appointments");
  if (ctx instanceof NextResponse) return ctx;
  const { clinic } = ctx;

  const sp = req.nextUrl.searchParams;
  const serviceId = sp.get("serviceId") ?? "";
  const dentistId = sp.get("dentistId") ?? "any";
  const date = sp.get("date") ?? "";
  const ignore = sp.get("ignore") ?? undefined;

  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) {
    return NextResponse.json({ error: "Invalid date" }, { status: 400 });
  }
  const service = servicesOf(clinic.id).find((s) => s.id === serviceId);
  if (!service) return NextResponse.json({ error: "Service not found" }, { status: 404 });

  let dentists = dentistsOf(clinic.id, true);
  if (dentistId !== "any") dentists = dentists.filter((d) => d.id === dentistId);

  const slots = slotsForDay(clinic, service, dentists, date, {
    ignoreAppointmentId: ignore,
    ignoreLeadTime: true,
  });
  return NextResponse.json({ slots: slots.map((s) => s.time) });
}
