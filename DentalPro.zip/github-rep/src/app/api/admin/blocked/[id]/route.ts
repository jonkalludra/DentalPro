import { NextRequest, NextResponse } from "next/server";
import { requireAdmin } from "@/lib/adminAuth";
import { db, save } from "@/lib/store";

export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const ctx = await requireAdmin(req, "appointments");
  if (ctx instanceof NextResponse) return ctx;
  const { session, clinic } = ctx;
  const { id } = await params;

  const block = db().blockedSlots.find(
    (b) => b.id === id && b.clinicId === clinic.id
  );
  if (!block) return NextResponse.json({ error: "Not found" }, { status: 404 });
  if (session.role === "dentist" && block.dentistId !== session.dentistId) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  db().blockedSlots = db().blockedSlots.filter((b) => b.id !== id);
  save();
  return NextResponse.json({ ok: true });
}
