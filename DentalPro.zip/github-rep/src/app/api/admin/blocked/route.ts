import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { requireAdmin } from "@/lib/adminAuth";
import { db, save, uid } from "@/lib/store";
import { toMinutes } from "@/lib/utils";

const schema = z.object({
  dentistId: z.string().nullable(),
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  startTime: z.string().regex(/^\d{2}:\d{2}$/),
  endTime: z.string().regex(/^\d{2}:\d{2}$/),
  reason: z.string().trim().max(120).optional().default(""),
});

export async function POST(req: NextRequest) {
  const ctx = await requireAdmin(req, "appointments");
  if (ctx instanceof NextResponse) return ctx;
  const { session, clinic } = ctx;

  const parsed = schema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) {
    return NextResponse.json({ error: "Invalid request" }, { status: 400 });
  }
  const data = parsed.data;
  if (toMinutes(data.endTime) <= toMinutes(data.startTime)) {
    return NextResponse.json(
      { error: "End time must be after start time." },
      { status: 400 }
    );
  }
  // Dentists can only block their own schedule.
  const dentistId =
    session.role === "dentist" ? session.dentistId : data.dentistId;

  db().blockedSlots.push({
    id: uid(),
    clinicId: clinic.id,
    dentistId: dentistId ?? null,
    date: data.date,
    startTime: data.startTime,
    endTime: data.endTime,
    reason: data.reason,
  });
  save();
  return NextResponse.json({ ok: true });
}
