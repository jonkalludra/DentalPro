import { NextRequest, NextResponse } from "next/server";
import { requireAdmin } from "@/lib/adminAuth";
import { db, save } from "@/lib/store";
import { dentistSchema } from "@/lib/schemas";

export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const ctx = await requireAdmin(req, "staff");
  if (ctx instanceof NextResponse) return ctx;
  const { clinic } = ctx;
  const { id } = await params;

  const dentist = db().dentists.find(
    (d) => d.id === id && d.clinicId === clinic.id
  );
  if (!dentist) return NextResponse.json({ error: "Not found" }, { status: 404 });

  const parsed = dentistSchema.partial().safeParse(await req.json().catch(() => null));
  if (!parsed.success) {
    return NextResponse.json({ error: "Please check the form." }, { status: 400 });
  }
  Object.assign(dentist, parsed.data);
  save();
  return NextResponse.json({ ok: true });
}

export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const ctx = await requireAdmin(req, "staff");
  if (ctx instanceof NextResponse) return ctx;
  const { clinic } = ctx;
  const { id } = await params;

  const dentist = db().dentists.find(
    (d) => d.id === id && d.clinicId === clinic.id
  );
  if (!dentist) return NextResponse.json({ error: "Not found" }, { status: 404 });

  const hasFuture = db().appointments.some(
    (a) =>
      a.clinicId === clinic.id &&
      a.dentistId === id &&
      (a.status === "confirmed" || a.status === "pending") &&
      a.date >= new Date().toISOString().slice(0, 10)
  );
  if (hasFuture) {
    return NextResponse.json(
      { error: "This dentist has upcoming appointments. Reassign them first, or deactivate the dentist." },
      { status: 409 }
    );
  }

  db().dentists = db().dentists.filter((d) => d.id !== id);
  db().users = db().users.filter((u) => u.dentistId !== id);
  save();
  return NextResponse.json({ ok: true });
}
