import { NextRequest, NextResponse } from "next/server";
import { requireAdmin } from "@/lib/adminAuth";
import { dentistSchema } from "@/lib/schemas";
import { db, save, uid } from "@/lib/store";

export async function POST(req: NextRequest) {
  const ctx = await requireAdmin(req, "staff");
  if (ctx instanceof NextResponse) return ctx;
  const { clinic } = ctx;

  const parsed = dentistSchema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) {
    return NextResponse.json({ error: "Please check the form." }, { status: 400 });
  }

  db().dentists.push({ id: uid(), clinicId: clinic.id, ...parsed.data });
  save();
  return NextResponse.json({ ok: true });
}
