import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { requireAdmin } from "@/lib/adminAuth";
import { resolveSlot } from "@/lib/availability";
import { reminderSms } from "@/lib/booking";
import { sendClinicSms } from "@/lib/sms";
import { db, dentistsOf, save, servicesOf } from "@/lib/store";
import { formatDateLong, formatTime, toMinutes, toTimeString } from "@/lib/utils";

const schema = z.discriminatedUnion("action", [
  z.object({
    action: z.literal("status"),
    status: z.enum(["pending", "confirmed", "completed", "cancelled"]),
    notify: z.boolean().optional().default(false),
  }),
  z.object({
    action: z.literal("reschedule"),
    date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
    time: z.string().regex(/^\d{2}:\d{2}$/),
    dentistId: z.string().min(1).optional(),
    notify: z.boolean().optional().default(true),
  }),
  z.object({ action: z.literal("remind") }),
]);

export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const ctx = await requireAdmin(req, "appointments");
  if (ctx instanceof NextResponse) return ctx;
  const { session, clinic } = ctx;
  const { id } = await params;

  const appointment = db().appointments.find(
    (a) => a.id === id && a.clinicId === clinic.id
  );
  if (!appointment) {
    return NextResponse.json({ error: "Appointment not found" }, { status: 404 });
  }
  // Dentists may only touch their own schedule.
  if (session.role === "dentist" && appointment.dentistId !== session.dentistId) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const parsed = schema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) {
    return NextResponse.json({ error: "Invalid request" }, { status: 400 });
  }
  const data = parsed.data;

  const patient = db().patients.find((p) => p.id === appointment.patientId);
  const service = servicesOf(clinic.id).find((s) => s.id === appointment.serviceId);

  if (data.action === "status") {
    appointment.status = data.status;
    save();
    if (data.notify && patient && data.status === "cancelled") {
      await sendClinicSms(
        clinic.id,
        patient.phone,
        `${clinic.name}: Your appointment on ${formatDateLong(appointment.date)} at ${formatTime(appointment.startTime)} has been cancelled. Please call us at ${clinic.phone} to rebook.`,
        "update"
      );
    }
    return NextResponse.json({ ok: true });
  }

  if (data.action === "remind") {
    if (!patient || !service) {
      return NextResponse.json({ error: "Missing patient or service" }, { status: 400 });
    }
    const ok = await sendClinicSms(
      clinic.id,
      patient.phone,
      reminderSms(clinic, service, appointment),
      "reminder"
    );
    if (ok) {
      appointment.reminderSentAt = new Date().toISOString();
      save();
    }
    return NextResponse.json({ ok });
  }

  // reschedule
  if (session.role === "dentist") {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }
  if (!service) {
    return NextResponse.json({ error: "Service not found" }, { status: 404 });
  }
  const targetDentistId = data.dentistId ?? appointment.dentistId;
  const candidates =
    targetDentistId === "any"
      ? dentistsOf(clinic.id, true)
      : dentistsOf(clinic.id, true).filter((d) => d.id === targetDentistId);
  if (candidates.length === 0) {
    return NextResponse.json({ error: "Dentist not found" }, { status: 404 });
  }

  const assigned = resolveSlot(clinic, service, candidates, data.date, data.time, {
    ignoreAppointmentId: appointment.id,
    ignoreLeadTime: true,
  });
  if (!assigned) {
    return NextResponse.json({ error: "That slot is not available." }, { status: 409 });
  }

  appointment.dentistId = assigned;
  appointment.date = data.date;
  appointment.startTime = data.time;
  appointment.endTime = toTimeString(toMinutes(data.time) + service.durationMinutes);
  appointment.reminderSentAt = null;
  if (appointment.status === "pending") appointment.status = "confirmed";
  save();

  if (data.notify && patient) {
    await sendClinicSms(
      clinic.id,
      patient.phone,
      `${clinic.name}: Your appointment has been moved to ${formatDateLong(appointment.date)} at ${formatTime(appointment.startTime)}. Questions? ${clinic.phone}`,
      "update"
    );
  }
  return NextResponse.json({ ok: true });
}
