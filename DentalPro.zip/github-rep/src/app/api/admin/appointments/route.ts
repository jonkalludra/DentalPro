import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { requireAdmin } from "@/lib/adminAuth";
import { resolveSlot } from "@/lib/availability";
import { db, dentistsOf, findPatientByPhone, save, servicesOf, token, uid } from "@/lib/store";
import type { Appointment } from "@/lib/types";
import { normalizePhone, toMinutes, toTimeString } from "@/lib/utils";

const schema = z.object({
  firstName: z.string().trim().min(2).max(60),
  lastName: z.string().trim().min(2).max(60),
  phone: z.string().trim().min(6).max(24),
  serviceId: z.string().min(1),
  dentistId: z.string().min(1),
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  time: z.string().regex(/^\d{2}:\d{2}$/),
  issue: z.string().trim().max(600).optional().default(""),
});

/** Staff create an appointment manually (walk-in / phone booking). */
export async function POST(req: NextRequest) {
  const ctx = await requireAdmin(req, "appointments");
  if (ctx instanceof NextResponse) return ctx;
  const { session, clinic } = ctx;

  if (session.role === "dentist") {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const parsed = schema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) {
    return NextResponse.json({ error: "Please check the form." }, { status: 400 });
  }
  const data = parsed.data;

  const phone = normalizePhone(data.phone);
  if (!phone) {
    return NextResponse.json({ error: "Invalid phone number." }, { status: 400 });
  }

  const service = servicesOf(clinic.id).find((s) => s.id === data.serviceId);
  if (!service) return NextResponse.json({ error: "Service not found" }, { status: 404 });

  const candidates =
    data.dentistId === "any"
      ? dentistsOf(clinic.id, true)
      : dentistsOf(clinic.id, true).filter((d) => d.id === data.dentistId);
  if (candidates.length === 0) {
    return NextResponse.json({ error: "Dentist not found" }, { status: 404 });
  }

  const assigned = resolveSlot(clinic, service, candidates, data.date, data.time, {
    ignoreLeadTime: true,
  });
  if (!assigned) {
    return NextResponse.json(
      { error: "That slot is not available." },
      { status: 409 }
    );
  }

  let patient = findPatientByPhone(clinic.id, phone);
  if (!patient) {
    patient = {
      id: uid(),
      clinicId: clinic.id,
      firstName: data.firstName,
      lastName: data.lastName,
      phone,
      email: null,
      createdAt: new Date().toISOString(),
    };
    db().patients.push(patient);
  }

  const appointment: Appointment = {
    id: uid(),
    clinicId: clinic.id,
    patientId: patient.id,
    dentistId: assigned,
    serviceId: service.id,
    date: data.date,
    startTime: data.time,
    endTime: toTimeString(toMinutes(data.time) + service.durationMinutes),
    status: "confirmed",
    issue: data.issue,
    manageToken: token(),
    source: "admin",
    reminderSentAt: null,
    createdAt: new Date().toISOString(),
  };
  db().appointments.push(appointment);
  save();

  return NextResponse.json({ ok: true, id: appointment.id });
}
