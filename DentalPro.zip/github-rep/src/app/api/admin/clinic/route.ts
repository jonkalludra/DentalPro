import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { requireAdmin } from "@/lib/adminAuth";
import { save } from "@/lib/store";

const dayHours = z.object({
  closed: z.boolean(),
  open: z.string().regex(/^\d{2}:\d{2}$/),
  close: z.string().regex(/^\d{2}:\d{2}$/),
});

const schema = z
  .object({
    name: z.string().trim().min(2).max(80),
    tagline: z.string().trim().max(140),
    logoUrl: z.string().max(400_000).nullable(), // data URLs allowed
    primaryColor: z.string().regex(/^#[0-9a-fA-F]{6}$/),
    heroHeadline: z.string().trim().min(2).max(90),
    heroSubheadline: z.string().trim().max(180),
    aboutText: z.string().trim().max(1200),
    patientInstructions: z.string().trim().max(500),
    stats: z.object({
      yearsExperience: z.number().int().min(0).max(100),
      happyPatients: z.number().int().min(0).max(10_000_000),
      certifiedDentists: z.number().int().min(0).max(500),
    }),
    address: z.string().trim().max(140),
    city: z.string().trim().max(80),
    phone: z.string().trim().max(30),
    emergencyPhone: z.string().trim().max(30),
    email: z.string().trim().email().or(z.literal("")),
    mapsEmbedUrl: z.string().trim().max(600),
    socials: z.object({
      facebook: z.string().trim().max(200),
      instagram: z.string().trim().max(200),
      tiktok: z.string().trim().max(200),
    }),
    workingHours: z.array(dayHours).length(7),
    holidays: z
      .array(
        z.object({
          date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
          name: z.string().trim().max(80),
        })
      )
      .max(100),
    slotStepMinutes: z.number().int().min(5).max(120),
    minLeadMinutes: z.number().int().min(0).max(1440),
    maxAdvanceDays: z.number().int().min(1).max(365),
    smsTemplates: z.object({
      confirmation: z.string().trim().min(5).max(400),
      reminder: z.string().trim().min(5).max(400),
    }),
    published: z.boolean(),
  })
  .partial();

/** Update clinic settings (any subset of fields). */
export async function PATCH(req: NextRequest) {
  const ctx = await requireAdmin(req, "settings");
  if (ctx instanceof NextResponse) return ctx;
  const { clinic } = ctx;

  const parsed = schema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Some fields are invalid. Please review and try again." },
      { status: 400 }
    );
  }

  Object.assign(clinic, parsed.data);
  save();
  return NextResponse.json({ ok: true });
}
