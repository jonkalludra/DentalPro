import { NextRequest, NextResponse } from "next/server";
import { requireAdmin } from "@/lib/adminAuth";
import { db, save } from "@/lib/store";

export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const ctx = await requireAdmin(req, "staff");
  if (ctx instanceof NextResponse) return ctx;
  const { session, clinic } = ctx;
  const { id } = await params;

  if (id === session.userId) {
    return NextResponse.json(
      { error: "You cannot delete your own account." },
      { status: 400 }
    );
  }
  const user = db().users.find((u) => u.id === id && u.clinicId === clinic.id);
  if (!user) return NextResponse.json({ error: "Not found" }, { status: 404 });

  db().users = db().users.filter((u) => u.id !== id);
  save();
  return NextResponse.json({ ok: true });
}
