import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { requireAdmin } from "@/lib/adminAuth";
import { hashPassword } from "@/lib/password";
import { db, save, uid, userByEmail } from "@/lib/store";

const schema = z.object({
  name: z.string().trim().min(2).max(80),
  email: z.string().email(),
  password: z.string().min(8).max(100),
  role: z.enum(["owner", "receptionist", "dentist"]),
  dentistId: z.string().nullable().optional().default(null),
});

export async function POST(req: NextRequest) {
  const ctx = await requireAdmin(req, "staff");
  if (ctx instanceof NextResponse) return ctx;
  const { clinic } = ctx;

  const parsed = schema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Check the form — password must be at least 8 characters." },
      { status: 400 }
    );
  }
  const data = parsed.data;

  if (userByEmail(data.email)) {
    return NextResponse.json(
      { error: "A user with this email already exists." },
      { status: 409 }
    );
  }
  if (data.role === "dentist" && !data.dentistId) {
    return NextResponse.json(
      { error: "Link the account to a dentist profile." },
      { status: 400 }
    );
  }

  db().users.push({
    id: uid(),
    clinicId: clinic.id,
    role: data.role,
    name: data.name,
    email: data.email.toLowerCase().trim(),
    passwordHash: hashPassword(data.password),
    dentistId: data.role === "dentist" ? data.dentistId : null,
    createdAt: new Date().toISOString(),
  });
  save();
  return NextResponse.json({ ok: true });
}
