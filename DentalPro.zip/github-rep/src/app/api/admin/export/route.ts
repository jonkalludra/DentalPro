import { NextRequest, NextResponse } from "next/server";
import { requireAdmin } from "@/lib/adminAuth";
import { enrichAppointments } from "@/lib/adminData";
import { db, patientsOf } from "@/lib/store";
import { toCsv } from "@/lib/utils";

/** CSV export: /api/admin/export?type=appointments|patients */
export async function GET(req: NextRequest) {
  const ctx = await requireAdmin(req, "patients");
  if (ctx instanceof NextResponse) return ctx;
  const { clinic } = ctx;

  const type = req.nextUrl.searchParams.get("type");

  if (type === "appointments") {
    const rows = enrichAppointments(clinic.id).map((a) => [
      a.date, a.startTime, a.endTime, a.status, a.patientName, a.patientPhone,
      a.serviceName, a.dentistName, a.source, a.issue,
    ]);
    return csvResponse(
      toCsv(
        ["Date", "Start", "End", "Status", "Patient", "Phone", "Service", "Dentist", "Source", "Notes"],
        rows
      ),
      `appointments-${clinic.slug}`
    );
  }

  if (type === "patients") {
    const counts = new Map<string, number>();
    for (const a of db().appointments) {
      if (a.clinicId === clinic.id && a.status !== "cancelled") {
        counts.set(a.patientId, (counts.get(a.patientId) ?? 0) + 1);
      }
    }
    const rows = patientsOf(clinic.id).map((p) => [
      p.firstName, p.lastName, p.phone, p.email ?? "",
      String(counts.get(p.id) ?? 0),
      p.createdAt.slice(0, 10),
    ]);
    return csvResponse(
      toCsv(
        ["First Name", "Last Name", "Phone", "Email", "Visits", "Registered"],
        rows
      ),
      `patients-${clinic.slug}`
    );
  }

  return NextResponse.json({ error: "Unknown export type" }, { status: 400 });
}

function csvResponse(csv: string, name: string): NextResponse {
  return new NextResponse("﻿" + csv, {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": `attachment; filename="${name}-${new Date().toISOString().slice(0, 10)}.csv"`,
    },
  });
}
