import { NextRequest, NextResponse } from "next/server";
import { reminderSms } from "@/lib/booking";
import { sendClinicSms } from "@/lib/sms";
import { clinicById, db, save, servicesOf } from "@/lib/store";
import { parseDate, toMinutes } from "@/lib/utils";

/**
 * Sends the 24-hour SMS reminders. Wire this to Vercel Cron (hourly).
 * Protected by CRON_SECRET when set: Authorization: Bearer <secret>.
 */
export async function GET(req: NextRequest) {
  const secret = process.env.CRON_SECRET;
  if (secret) {
    const auth = req.headers.get("authorization");
    if (auth !== `Bearer ${secret}`) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }
  }

  const now = Date.now();
  const windowMax = 24 * 60; // minutes ahead
  const windowMin = 2 * 60; // don't remind for bookings starting very soon

  let sent = 0;
  for (const appointment of db().appointments) {
    if (appointment.status !== "confirmed" || appointment.reminderSentAt) continue;

    const start = parseDate(appointment.date);
    const startMs = start.getTime() + toMinutes(appointment.startTime) * 60_000;
    const minutesUntil = (startMs - now) / 60_000;
    if (minutesUntil < windowMin || minutesUntil > windowMax) continue;

    const clinic = clinicById(appointment.clinicId);
    const patient = db().patients.find((p) => p.id === appointment.patientId);
    const service = clinic
      ? servicesOf(clinic.id).find((s) => s.id === appointment.serviceId)
      : undefined;
    if (!clinic || !patient || !service) continue;

    const ok = await sendClinicSms(
      clinic.id,
      patient.phone,
      reminderSms(clinic, service, appointment),
      "reminder"
    );
    if (ok) {
      appointment.reminderSentAt = new Date().toISOString();
      sent++;
    }
  }
  if (sent > 0) save();

  return NextResponse.json({ ok: true, sent });
}
