import { LogoMark } from "@/components/icons";
import { db } from "@/lib/store";

export const dynamic = "force-dynamic";
import { ArrowRight, CalendarCheck2, LayoutDashboard, MessageSquareText, Palette, ShieldCheck, Users } from "lucide-react";
import Link from "next/link";

const FEATURES = [
  {
    icon: CalendarCheck2,
    title: "1-minute booking",
    text: "Patients book with just a name and phone number — verified by SMS, confirmed instantly.",
  },
  {
    icon: MessageSquareText,
    title: "SMS-first",
    text: "Verification codes, confirmations, 24h reminders and secure reschedule links. No emails, no accounts.",
  },
  {
    icon: LayoutDashboard,
    title: "Complete dashboard",
    text: "Appointments, interactive calendar, patients, staff schedules and statistics for the whole team.",
  },
  {
    icon: Palette,
    title: "Your clinic's brand",
    text: "Every clinic gets its own site: logo, colors, services, prices, team and working hours.",
  },
  {
    icon: Users,
    title: "Multi-dentist",
    text: "Individual schedules, days off and no double bookings — patients pick a dentist or the first available.",
  },
  {
    icon: ShieldCheck,
    title: "Role-based access",
    text: "Owner, receptionist and dentist roles, with every clinic's data fully isolated.",
  },
];

export default function PlatformHome() {
  const demoClinic = db().clinics[0];

  return (
    <div className="min-h-screen bg-white">
      <header className="fixed inset-x-0 top-0 z-40 px-4 pt-4">
        <nav className="glass mx-auto flex max-w-5xl items-center justify-between rounded-full pl-5 pr-2 py-2">
          <span className="flex items-center gap-2.5">
            <LogoMark size={34} />
            <span className="font-display text-[17px] font-extrabold tracking-tight text-ink">
              DentalPro
            </span>
          </span>
          <div className="flex items-center gap-2">
            <Link
              href="/admin/login"
              className="btn-glass inline-flex h-10 items-center rounded-full px-5 text-sm font-semibold"
            >
              Clinic Login
            </Link>
            {demoClinic && (
              <Link
                href={`/clinic/${demoClinic.slug}`}
                className="btn-liquid inline-flex h-10 items-center gap-1.5 rounded-full px-5 text-sm font-semibold"
              >
                View Demo Clinic
              </Link>
            )}
          </div>
        </nav>
      </header>

      <main>
        <section className="relative overflow-hidden pt-40 pb-24">
          <div
            aria-hidden
            className="absolute inset-0 -z-10"
            style={{
              background:
                "radial-gradient(800px 460px at 50% -10%, color-mix(in srgb, var(--brand) 10%, transparent), transparent 65%), linear-gradient(180deg, #ffffff 0%, #f7f9fd 100%)",
            }}
          />
          <div className="mx-auto max-w-4xl px-5 text-center">
            <p className="inline-flex items-center rounded-full border border-brand/15 bg-brand-soft px-4 py-1.5 text-[13px] font-semibold text-brand">
              The booking platform for modern dental clinics
            </p>
            <h1 className="font-display mt-6 text-5xl sm:text-[68px] font-extrabold leading-[1.04] tracking-[-0.03em] text-ink text-balance">
              Your clinic's website.
              <br />
              <span className="text-brand">Bookings on autopilot.</span>
            </h1>
            <p className="mx-auto mt-6 max-w-2xl text-lg sm:text-xl leading-relaxed text-ink-soft">
              A premium website with appointment booking that takes under a minute —
              no patient accounts, just an SMS code. Built for dental clinics that
              want to feel as modern as they work.
            </p>
            <div className="mt-9 flex flex-col sm:flex-row items-center justify-center gap-3">
              {demoClinic && (
                <Link
                  href={`/clinic/${demoClinic.slug}`}
                  className="btn-liquid inline-flex h-[54px] items-center gap-2 rounded-full px-9 text-[16px] font-semibold"
                >
                  Explore the demo clinic <ArrowRight size={18} />
                </Link>
              )}
              <Link
                href="/admin/login"
                className="btn-glass inline-flex h-[54px] items-center rounded-full px-8 text-[16px] font-semibold"
              >
                Open the dashboard
              </Link>
            </div>
          </div>
        </section>

        <section className="pb-28">
          <div className="mx-auto max-w-6xl px-5 sm:px-6">
            <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
              {FEATURES.map((f) => (
                <div
                  key={f.title}
                  className="rounded-3xl border border-line/70 bg-white p-7 shadow-[0_8px_30px_rgba(11,21,38,0.05)]"
                >
                  <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-brand-soft text-brand">
                    <f.icon size={22} />
                  </span>
                  <h3 className="font-display mt-4 text-lg font-bold text-ink">{f.title}</h3>
                  <p className="mt-1.5 text-[15px] leading-relaxed text-ink-soft">{f.text}</p>
                </div>
              ))}
            </div>
          </div>
        </section>
      </main>

      <footer className="border-t border-line py-8">
        <p className="text-center text-[13px] text-ink-faint">
          © {new Date().getFullYear()} DentalPro — Multi-tenant dental clinic platform
        </p>
      </footer>
    </div>
  );
}
