import { AppointmentsTable } from "@/components/admin/AppointmentsTable";
import { enrichAppointments } from "@/lib/adminData";
import { requireClinicPage } from "@/lib/adminPage";
import { dentistFilter } from "@/lib/session";
import { db, dentistsOf, servicesOf } from "@/lib/store";
import { addDays, formatDateLong, todayString } from "@/lib/utils";
import { CalendarCheck2, CalendarClock, CalendarRange, UserPlus, UsersRound } from "lucide-react";
import type { Metadata } from "next";

export const metadata: Metadata = { title: "Dashboard" };

function startOfWeek(date: string): string {
  const d = new Date(date + "T12:00:00");
  const day = d.getDay(); // 0 Sun … 6 Sat
  const diff = day === 0 ? 6 : day - 1; // Monday-based
  return addDays(date, -diff);
}

export default async function DashboardPage() {
  const { session, clinic } = await requireClinicPage();
  const onlyDentist = dentistFilter(session);

  const today = todayString();
  const weekStart = startOfWeek(today);
  const weekEnd = addDays(weekStart, 6);
  const monthPrefix = today.slice(0, 7);

  const all = enrichAppointments(
    clinic.id,
    onlyDentist ? (a) => a.dentistId === onlyDentist : undefined
  );
  const active = all.filter((a) => a.status !== "cancelled");

  const todayList = all.filter((a) => a.date === today);
  const weekCount = active.filter((a) => a.date >= weekStart && a.date <= weekEnd).length;
  const monthCount = active.filter((a) => a.date.startsWith(monthPrefix)).length;

  const patientAppointmentCounts = new Map<string, number>();
  for (const a of db().appointments) {
    if (a.clinicId === clinic.id && a.status !== "cancelled") {
      patientAppointmentCounts.set(
        a.patientId,
        (patientAppointmentCounts.get(a.patientId) ?? 0) + 1
      );
    }
  }
  const newPatientsMonth = db().patients.filter(
    (p) => p.clinicId === clinic.id && p.createdAt.startsWith(monthPrefix)
  ).length;
  const returningPatients = [...patientAppointmentCounts.values()].filter(
    (n) => n >= 2
  ).length;

  const upcoming = all
    .filter(
      (a) => a.date > today && (a.status === "confirmed" || a.status === "pending")
    )
    .slice(0, 6);

  const services = servicesOf(clinic.id, true).map((s) => ({
    id: s.id,
    name: s.name,
    durationMinutes: s.durationMinutes,
  }));
  const dentists = dentistsOf(clinic.id, true).map((d) => ({
    id: d.id,
    name: d.name,
  }));

  const stats = [
    {
      label: "Today's appointments",
      value: todayList.filter((a) => a.status !== "cancelled").length,
      icon: CalendarCheck2,
      accent: true,
    },
    { label: "This week", value: weekCount, icon: CalendarClock },
    { label: "This month", value: monthCount, icon: CalendarRange },
    { label: "New patients (month)", value: newPatientsMonth, icon: UserPlus },
    { label: "Returning patients", value: returningPatients, icon: UsersRound },
  ];

  return (
    <div>
      <div className="mb-8">
        <h1 className="font-display text-2xl sm:text-3xl font-extrabold tracking-tight text-ink">
          Good {new Date().getHours() < 12 ? "morning" : new Date().getHours() < 18 ? "afternoon" : "evening"}, {session.name.split(" ")[0]}
        </h1>
        <p className="mt-1 text-[15px] text-ink-soft">{formatDateLong(today)}</p>
      </div>

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-5">
        {stats.map((s) => (
          <div
            key={s.label}
            className={
              s.accent
                ? "rounded-3xl p-5 text-white shadow-[0_14px_36px_color-mix(in_srgb,var(--brand)_35%,transparent)]"
                : "rounded-3xl border border-line/70 bg-white p-5 shadow-[0_4px_20px_rgba(11,21,38,0.04)]"
            }
            style={
              s.accent
                ? {
                    background:
                      "linear-gradient(150deg, color-mix(in srgb, var(--brand) 85%, white), var(--brand-dark))",
                  }
                : undefined
            }
          >
            <s.icon size={20} className={s.accent ? "text-white/80" : "text-brand"} />
            <p className="font-display mt-3 text-3xl font-extrabold tracking-tight">
              {s.value}
            </p>
            <p
              className={
                s.accent
                  ? "mt-0.5 text-[12.5px] font-medium text-white/80"
                  : "mt-0.5 text-[12.5px] font-medium text-ink-faint"
              }
            >
              {s.label}
            </p>
          </div>
        ))}
      </div>

      <section className="mt-10">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="font-display text-lg font-bold text-ink">Today's schedule</h2>
        </div>
        <AppointmentsTable
          appointments={todayList}
          services={services}
          dentists={dentists}
          role={session.role}
          showFilters={false}
          emptyLabel="No appointments today — enjoy the quiet ☀️"
        />
      </section>

      <section className="mt-10">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="font-display text-lg font-bold text-ink">Coming up</h2>
          <a
            href="/admin/appointments"
            className="text-sm font-semibold text-brand hover:underline"
          >
            View all →
          </a>
        </div>
        <AppointmentsTable
          appointments={upcoming}
          services={services}
          dentists={dentists}
          role={session.role}
          showFilters={false}
          emptyLabel="No upcoming appointments yet."
        />
      </section>
    </div>
  );
}
