import { StaffManager } from "@/components/admin/StaffManager";
import { requireClinicPage } from "@/lib/adminPage";
import { can } from "@/lib/session";
import { db, dentistsOf } from "@/lib/store";
import type { Metadata } from "next";
import { redirect } from "next/navigation";

export const metadata: Metadata = { title: "Staff" };

export default async function StaffPage() {
  const { session, clinic } = await requireClinicPage();
  if (!can(session, "staff")) redirect("/admin");

  const users = db()
    .users.filter((u) => u.clinicId === clinic.id)
    .map((u) => ({
      id: u.id,
      name: u.name,
      email: u.email,
      role: u.role,
      dentistId: u.dentistId,
    }));

  return (
    <StaffManager
      dentists={dentistsOf(clinic.id)}
      users={users}
      currentUserId={session.userId}
    />
  );
}
