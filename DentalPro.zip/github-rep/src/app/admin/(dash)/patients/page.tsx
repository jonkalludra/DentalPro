import { PatientsTable } from "@/components/admin/PatientsTable";
import { requireClinicPage } from "@/lib/adminPage";
import { db, patientsOf } from "@/lib/store";
import type { Metadata } from "next";

export const metadata: Metadata = { title: "Patients" };

export default async function PatientsPage() {
  const { clinic } = await requireClinicPage();

  const stats = new Map<string, { visits: number; lastVisit: string; nextVisit: string }>();
  const today = new Date().toISOString().slice(0, 10);
  for (const a of db().appointments) {
    if (a.clinicId !== clinic.id || a.status === "cancelled") continue;
    const entry = stats.get(a.patientId) ?? { visits: 0, lastVisit: "", nextVisit: "" };
    entry.visits += 1;
    if (a.date <= today && a.date > entry.lastVisit) entry.lastVisit = a.date;
    if (a.date > today && (entry.nextVisit === "" || a.date < entry.nextVisit)) {
      entry.nextVisit = a.date;
    }
    stats.set(a.patientId, entry);
  }

  const patients = patientsOf(clinic.id)
    .map((p) => ({
      id: p.id,
      name: `${p.firstName} ${p.lastName}`,
      phone: p.phone,
      email: p.email,
      createdAt: p.createdAt.slice(0, 10),
      visits: stats.get(p.id)?.visits ?? 0,
      lastVisit: stats.get(p.id)?.lastVisit || "—",
      nextVisit: stats.get(p.id)?.nextVisit || "—",
    }))
    .sort((a, b) => b.visits - a.visits);

  return (
    <div>
      <div className="mb-7">
        <h1 className="font-display text-2xl sm:text-3xl font-extrabold tracking-tight text-ink">
          Patients
        </h1>
        <p className="mt-1 text-[15px] text-ink-soft">
          {patients.length} patients · automatically created from bookings
        </p>
      </div>
      <PatientsTable patients={patients} />
    </div>
  );
}
