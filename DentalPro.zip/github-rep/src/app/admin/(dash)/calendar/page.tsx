import { CalendarWeek } from "@/components/admin/CalendarWeek";
import { enrichAppointments } from "@/lib/adminData";
import { requireClinicPage } from "@/lib/adminPage";
import { dentistFilter } from "@/lib/session";
import { db, dentistsOf } from "@/lib/store";
import { addDays, todayString } from "@/lib/utils";
import type { Metadata } from "next";

export const metadata: Metadata = { title: "Calendar" };

function mondayOf(date: string): string {
  const d = new Date(date + "T12:00:00");
  const day = d.getDay();
  return addDays(date, day === 0 ? -6 : 1 - day);
}

export default async function CalendarPage({
  searchParams,
}: {
  searchParams: Promise<{ week?: string }>;
}) {
  const { session, clinic } = await requireClinicPage();
  const { week } = await searchParams;
  const onlyDentist = dentistFilter(session);

  const weekStart = mondayOf(
    week && /^\d{4}-\d{2}-\d{2}$/.test(week) ? week : todayString()
  );
  const weekEnd = addDays(weekStart, 6);

  const appointments = enrichAppointments(
    clinic.id,
    (a) =>
      a.date >= weekStart &&
      a.date <= weekEnd &&
      a.status !== "cancelled" &&
      (!onlyDentist || a.dentistId === onlyDentist)
  );

  const blocked = db()
    .blockedSlots.filter(
      (b) =>
        b.clinicId === clinic.id &&
        b.date >= weekStart &&
        b.date <= weekEnd &&
        (!onlyDentist || b.dentistId === null || b.dentistId === onlyDentist)
    )
    .map((b) => ({ ...b }));

  const dentists = dentistsOf(clinic.id, true).map((d) => ({
    id: d.id,
    name: d.name,
  }));

  return (
    <CalendarWeek
      weekStart={weekStart}
      appointments={appointments}
      blocked={blocked}
      dentists={dentists}
      workingHours={clinic.workingHours}
      holidays={clinic.holidays}
      role={session.role}
    />
  );
}
