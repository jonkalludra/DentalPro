import { ServicesManager } from "@/components/admin/ServicesManager";
import { requireClinicPage } from "@/lib/adminPage";
import { can } from "@/lib/session";
import { servicesOf } from "@/lib/store";
import type { Metadata } from "next";
import { redirect } from "next/navigation";

export const metadata: Metadata = { title: "Services" };

export default async function ServicesPage() {
  const { session, clinic } = await requireClinicPage();
  if (!can(session, "services")) redirect("/admin");

  return (
    <div>
      <div className="mb-7">
        <h1 className="font-display text-2xl sm:text-3xl font-extrabold tracking-tight text-ink">
          Services
        </h1>
        <p className="mt-1 text-[15px] text-ink-soft">
          Treatments patients can book — with your own durations and prices.
        </p>
      </div>
      <ServicesManager services={servicesOf(clinic.id)} />
    </div>
  );
}
