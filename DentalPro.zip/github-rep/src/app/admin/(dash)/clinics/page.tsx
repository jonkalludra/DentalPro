import { ClinicsManager } from "@/components/admin/ClinicsManager";
import { getSession } from "@/lib/session";
import { db } from "@/lib/store";
import type { Metadata } from "next";
import { redirect } from "next/navigation";

export const metadata: Metadata = { title: "Clinics" };

export default async function ClinicsPage() {
  const session = await getSession();
  if (!session) redirect("/admin/login");
  if (session.role !== "super_admin") redirect("/admin");

  const today = new Date().toISOString().slice(0, 10);
  const clinics = db().clinics.map((c) => {
    const appointments = db().appointments.filter((a) => a.clinicId === c.id);
    return {
      id: c.id,
      slug: c.slug,
      name: c.name,
      city: c.city,
      phone: c.phone,
      primaryColor: c.primaryColor,
      published: c.published,
      patients: db().patients.filter((p) => p.clinicId === c.id).length,
      upcoming: appointments.filter(
        (a) => a.date >= today && (a.status === "confirmed" || a.status === "pending")
      ).length,
      total: appointments.length,
    };
  });

  return <ClinicsManager clinics={clinics} activeClinicId={session.clinicId} />;
}
