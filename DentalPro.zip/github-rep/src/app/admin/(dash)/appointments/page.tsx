import { AppointmentsTable } from "@/components/admin/AppointmentsTable";
import { enrichAppointments } from "@/lib/adminData";
import { requireClinicPage } from "@/lib/adminPage";
import { dentistFilter } from "@/lib/session";
import { dentistsOf, servicesOf } from "@/lib/store";
import type { Metadata } from "next";

export const metadata: Metadata = { title: "Appointments" };

export default async function AppointmentsPage() {
  const { session, clinic } = await requireClinicPage();
  const onlyDentist = dentistFilter(session);

  const appointments = enrichAppointments(
    clinic.id,
    onlyDentist ? (a) => a.dentistId === onlyDentist : undefined
  ).reverse(); // most recent dates first for browsing

  return (
    <div>
      <div className="mb-7">
        <h1 className="font-display text-2xl sm:text-3xl font-extrabold tracking-tight text-ink">
          Appointments
        </h1>
        <p className="mt-1 text-[15px] text-ink-soft">
          Search, filter, reschedule and manage every booking.
        </p>
      </div>
      <AppointmentsTable
        appointments={appointments}
        services={servicesOf(clinic.id, true).map((s) => ({
          id: s.id,
          name: s.name,
          durationMinutes: s.durationMinutes,
        }))}
        dentists={dentistsOf(clinic.id, true).map((d) => ({ id: d.id, name: d.name }))}
        role={session.role}
      />
    </div>
  );
}
