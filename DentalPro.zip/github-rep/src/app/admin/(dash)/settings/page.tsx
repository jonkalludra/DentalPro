import { SettingsForm } from "@/components/admin/SettingsForm";
import { requireClinicPage } from "@/lib/adminPage";
import { can } from "@/lib/session";
import type { Metadata } from "next";
import { redirect } from "next/navigation";

export const metadata: Metadata = { title: "Settings" };

export default async function SettingsPage() {
  const { session, clinic } = await requireClinicPage();
  if (!can(session, "settings")) redirect("/admin");

  return <SettingsForm clinic={clinic} />;
}
