import { AdminShell } from "@/components/admin/AdminShell";
import { getSession, can, type Permission } from "@/lib/session";
import { clinicById } from "@/lib/store";
import { redirect } from "next/navigation";

const ALL_PERMISSIONS: Permission[] = [
  "appointments",
  "patients",
  "services",
  "staff",
  "settings",
  "clinics",
];

export default async function AdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const session = await getSession();
  if (!session) redirect("/admin/login");

  const clinic = session.clinicId ? clinicById(session.clinicId) : undefined;
  const permissions = ALL_PERMISSIONS.filter((p) => can(session, p));

  return (
    <AdminShell
      userName={session.name}
      role={session.role}
      clinicName={clinic?.name ?? "DentalPro Platform"}
      clinicSlug={clinic?.slug ?? null}
      brandColor={clinic?.primaryColor ?? "#2563eb"}
      permissions={permissions}
    >
      {children}
    </AdminShell>
  );
}
