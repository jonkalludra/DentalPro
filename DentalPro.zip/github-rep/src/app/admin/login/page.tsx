"use client";

import { LogoMark } from "@/components/icons";
import { Button, Input, Label, Spinner } from "@/components/ui";
import { motion } from "framer-motion";
import { LockKeyhole } from "lucide-react";
import { useRouter, useSearchParams } from "next/navigation";
import { Suspense, useState } from "react";

function LoginForm() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const res = await fetch("/api/admin/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error ?? "Login failed.");
        return;
      }
      const next = searchParams.get("next");
      router.push(next && next.startsWith("/admin") ? next : data.redirect);
      router.refresh();
    } catch {
      setError("Network error. Please try again.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="min-h-screen bg-mist flex items-center justify-center px-4">
      <div
        aria-hidden
        className="fixed inset-0 -z-10"
        style={{
          background:
            "radial-gradient(700px 420px at 50% -8%, color-mix(in srgb, var(--brand) 10%, transparent), transparent 65%), linear-gradient(180deg,#fff,#f5f7fb)",
        }}
      />
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-sm"
      >
        <div className="glass-deep rounded-[2rem] p-8">
          <div className="flex flex-col items-center text-center">
            <LogoMark size={52} />
            <h1 className="font-display mt-4 text-2xl font-extrabold tracking-tight text-ink">
              Clinic Dashboard
            </h1>
            <p className="mt-1 text-sm text-ink-soft">
              Sign in to manage your appointments
            </p>
          </div>

          {error && (
            <div className="mt-5 rounded-2xl border border-red-100 bg-red-50 px-4 py-3 text-sm font-medium text-red-600">
              {error}
            </div>
          )}

          <form onSubmit={submit} className="mt-6 space-y-4">
            <div>
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                placeholder="you@clinic.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                autoComplete="email"
                required
              />
            </div>
            <div>
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                autoComplete="current-password"
                required
              />
            </div>
            <Button size="lg" className="w-full" disabled={busy} type="submit">
              {busy ? <Spinner /> : <LockKeyhole size={17} />}
              Sign in
            </Button>
          </form>

          <div className="mt-6 rounded-2xl bg-white/70 border border-line/60 p-4 text-[12px] leading-relaxed text-ink-soft">
            <p className="font-bold text-ink mb-1">Demo accounts</p>
            <p>Owner: <span className="font-mono">owner@smile.dental</span> / <span className="font-mono">demo1234</span></p>
            <p>Reception: <span className="font-mono">reception@smile.dental</span> / <span className="font-mono">demo1234</span></p>
            <p>Dentist: <span className="font-mono">arta@smile.dental</span> / <span className="font-mono">demo1234</span></p>
            <p>Platform: <span className="font-mono">admin@dentalpro.app</span> / <span className="font-mono">admin1234</span></p>
          </div>
        </div>
      </motion.div>
    </div>
  );
}

export default function LoginPage() {
  return (
    <Suspense>
      <LoginForm />
    </Suspense>
  );
}
