import type { Metadata } from "next";
import { Inter, Manrope } from "next/font/google";
import "./globals.css";

const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin"],
  display: "swap",
});

const manrope = Manrope({
  variable: "--font-manrope",
  subsets: ["latin"],
  display: "swap",
});

export const metadata: Metadata = {
  title: {
    default: "DentalPro — Modern Dental Clinic Platform",
    template: "%s | DentalPro",
  },
  description:
    "Premium appointment booking platform for modern dental clinics. Book in under a minute — no account required.",
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en" className="h-full">
      <body
        className={`${inter.variable} ${manrope.variable} min-h-full antialiased`}
      >
        {children}
      </body>
    </html>
  );
}
