import { LogoMark } from "@/components/icons";
import Link from "next/link";

export default function NotFound() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-mist px-4 text-center">
      <LogoMark size={56} />
      <h1 className="font-display mt-6 text-3xl font-extrabold tracking-tight text-ink">
        Page not found
      </h1>
      <p className="mt-2 max-w-sm text-[15px] text-ink-soft">
        This page doesn't exist or the clinic website is not published yet.
      </p>
      <Link
        href="/"
        className="btn-liquid mt-7 inline-flex h-11 items-center rounded-full px-7 text-sm font-semibold"
      >
        Back to home
      </Link>
    </div>
  );
}
