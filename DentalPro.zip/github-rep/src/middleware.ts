import { NextRequest, NextResponse } from "next/server";
import { SESSION_COOKIE, verifySessionToken } from "@/lib/session";

/**
 * Multi-tenant routing.
 *
 * V1 — subdomains:  smile.yourplatform.com/*  →  /clinic/smile/*  (rewrite)
 * V2 — paths:       yourplatform.com/clinic/smile/*               (native)
 * V3 — custom domains: point the domain at the deployment and map it
 *      to a slug via the CUSTOM_DOMAINS env ("smilekos.com=smile,…").
 */

const ROOT_DOMAIN = process.env.NEXT_PUBLIC_ROOT_DOMAIN || "localhost:3000";

function customDomains(): Map<string, string> {
  const map = new Map<string, string>();
  for (const pair of (process.env.CUSTOM_DOMAINS || "").split(",")) {
    const [domain, slug] = pair.split("=").map((s) => s?.trim());
    if (domain && slug) map.set(domain.replace(/^www\./, ""), slug);
  }
  return map;
}

function slugFromHost(host: string): string | null {
  const hostname = host.split(":")[0].toLowerCase();
  const rootHost = ROOT_DOMAIN.split(":")[0].toLowerCase();

  const custom = customDomains().get(hostname.replace(/^www\./, ""));
  if (custom) return custom;

  if (hostname !== rootHost && hostname.endsWith("." + rootHost)) {
    const sub = hostname.slice(0, -(rootHost.length + 1));
    if (sub && sub !== "www") return sub;
  }
  return null;
}

export async function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;

  // ---- admin auth guard ----
  if (pathname.startsWith("/admin") && !pathname.startsWith("/admin/login")) {
    const token = req.cookies.get(SESSION_COOKIE)?.value;
    const session = token ? await verifySessionToken(token) : null;
    if (!session) {
      const url = req.nextUrl.clone();
      url.pathname = "/admin/login";
      url.searchParams.set("next", pathname);
      return NextResponse.redirect(url);
    }
    return NextResponse.next();
  }

  // ---- tenant resolution ----
  if (
    pathname.startsWith("/api") ||
    pathname.startsWith("/_next") ||
    pathname.includes(".")
  ) {
    return NextResponse.next();
  }

  const slug = slugFromHost(req.headers.get("host") || "");
  if (!slug) return NextResponse.next();

  // On a clinic subdomain, keep URLs clean: /clinic/<slug>/x → /x
  if (pathname.startsWith(`/clinic/${slug}`)) {
    const url = req.nextUrl.clone();
    url.pathname = pathname.slice(`/clinic/${slug}`.length) || "/";
    return NextResponse.redirect(url);
  }

  const url = req.nextUrl.clone();
  url.pathname = `/clinic/${slug}${pathname === "/" ? "" : pathname}`;
  return NextResponse.rewrite(url);
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon\\.ico).*)"],
};
