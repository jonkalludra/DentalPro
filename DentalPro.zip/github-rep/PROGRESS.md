# Build Progress

_Last updated: 2026-07-11 (session 2)._ This file tracks where the build stands so any
session (or teammate) can pick up from here.

## Status: V1 complete and verified ✅

All core features from the brief are built, the production build passes, and a
21-check end-to-end test of the running app passed (booking, OTP, slot logic,
reschedule/cancel, roles, exports, cron).

### Done

- [x] **Foundation** — Next.js 16 + TS + Tailwind 4 + Framer Motion; design system
      (white/gray, liquid-glass buttons & nav, rounded cards, Manrope/Inter)
- [x] **Data layer** — typed JSON store (`data/db.json`, auto-seeded demo clinic with
      45 days of realistic appointments), scrypt passwords, HMAC session cookies
- [x] **Multi-tenancy** — middleware: subdomain (V1), path (V2), custom-domain map (V3);
      per-clinic brand color/logo theming via CSS vars
- [x] **Availability engine** — durations, per-dentist hours/days off, holidays,
      blocked slots, lead time, booking window, load-balanced "no preference",
      double-booking prevention (re-checked at OTP verification)
- [x] **SMS abstraction** — `SmsProvider` interface; Twilio Verify (env-gated) +
      mock provider (on-screen code for demos); message log
- [x] **Public clinic site** — glass navbar, animated hero, how-it-works, services grid,
      about + count-up stats, reviews carousel, contact + maps + hours, footer, mobile CTA
- [x] **Booking wizard** — 5 steps, slot picker, OTP input, success screen with
      Google Calendar + .ics + patient instructions; slot-taken and expiry recovery
- [x] **Patient manage page** — secure SMS token link; reschedule (same/any dentist)
      + cancel with confirmations
- [x] **Admin dashboard** — role-based shell (super_admin / owner / receptionist / dentist),
      stats, today + upcoming, appointments table (search/filter/status/reschedule/
      walk-in/remind), week calendar with block-time, patients + CSV exports,
      services CRUD, staff & team accounts, settings (branding, contact, hours,
      holidays, booking rules, SMS templates with preview), super-admin clinics page
- [x] **Reminders** — hourly cron endpoint (`vercel.json`), 24h window, manual resend
- [x] **Docs** — README, `.env.example`, `supabase/schema.sql` (RLS + exclusion
      constraint), this file

### Verification (2026-07-11)

- `npm run build` — clean, 38 routes
- E2E against dev server — **21/21 passed**: availability respects hours/lead time,
  wrong OTP rejected, booking confirms + removes slot, ICS valid, reschedule + cancel
  via manage token, admin auth + anonymous blocked, role limits (dentist can't create,
  receptionist can't edit settings), CSV export, block-time removes public slots, cron runs
- Admin pages all render 200 with session; anonymous `/admin` → login redirect

## How to run

`npm run dev` → http://localhost:3000. Demo logins are in [README.md](README.md).
SMS runs in demo mode (code shown on screen) until Twilio env vars are set.

## Next steps (in rough priority order)

- [ ] **Supabase wiring** — schema is ready (`supabase/schema.sql`); port
      `src/lib/store.ts` to Supabase queries + Supabase Auth for staff. Required
      before real production use (JSON store is ephemeral on Vercel).
- [ ] **Real Twilio account** — create Verify service, set env vars, test with a
      Kosovo number (+383). Sender ID / local SMS gateway worth comparing on price.
- [ ] **Deploy to Vercel** — set `SESSION_SECRET`, `NEXT_PUBLIC_ROOT_DOMAIN`,
      `CRON_SECRET`; add wildcard subdomain `*.yourplatform.com` once a domain is bought.
- [ ] **Albanian translations** — site copy is customizable per clinic, but a proper
      sq/en language switch would help sales in Kosovo.
- [ ] **Design polish pass** — `webstie-ideas/` holds two reference shots (oversized
      display type, aligner photography, team photo cards). Current design already
      matches the direction; optional: even larger hero type, real photos per clinic,
      dentist photo uploads.
- [ ] **Later (per brief):** subscriptions/billing for clinics, email notifications
      (optional channel), reviews management UI, 2FA for admins.

## Decisions log

- **JSON file store now, Supabase later** — zero-setup demos for in-person sales;
  repository-style lib keeps the swap contained. Schema mirrors types 1:1.
- **SMS provider behind interface** — per brief, so Twilio can be replaced.
- **Auto-confirm after OTP** (no manual approval) — per brief Q4.
- **Admins bypass patient lead-time** for walk-ins; patients don't.
- **Demo mode shows the OTP on screen** — deliberate, for selling without SMS costs.
