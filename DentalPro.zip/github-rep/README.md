# DentalPro — Multi-Tenant Dental Clinic Platform

A premium, white-label appointment platform for dental clinics. Each clinic gets its own
branded website with a booking flow that takes **under a minute** — no patient accounts,
just an SMS code — plus a full admin dashboard for the clinic team.

Built to be sold clinic-by-clinic: one codebase, unlimited clinics, fully isolated data.

## Quick start

```bash
npm install
npm run dev
```

Open http://localhost:3000 — the platform landing page links to the seeded demo clinic
(**Smile Dental Clinic**, Prishtina) with realistic appointments, patients and reviews.

| URL | What it is |
| --- | --- |
| `/` | Platform landing (your sales page) |
| `/clinic/smile` | Demo clinic public website |
| `/clinic/smile/book` | Patient booking flow (SMS verified) |
| `/admin` | Staff dashboard (login required) |
| `/admin/clinics` | Platform admin — create/manage clinics |

### Demo accounts

| Role | Email | Password |
| --- | --- | --- |
| Platform admin (you) | `admin@dentalpro.app` | `admin1234` |
| Clinic owner | `owner@smile.dental` | `demo1234` |
| Receptionist | `reception@smile.dental` | `demo1234` |
| Dentist | `arta@smile.dental` | `demo1234` |

### SMS demo mode

Without Twilio env vars the app runs in **demo mode**: the 6-digit code is displayed
on-screen (and logged to the console) instead of being sent — perfect for in-person
demos. Add Twilio credentials in `.env` (see `.env.example`) to send real SMS via
Twilio Verify. The provider sits behind an interface (`src/lib/sms/`), so swapping in
another gateway is one file.

## Features

**Patient side** — no account, ever
- Service → dentist ("no preference" = first available) → date/time → details → SMS code → confirmed
- Smart slots: working hours, per-dentist schedules & days off, service durations,
  holidays, blocked time, lead time, no double bookings
- Confirmation SMS with secure manage link (reschedule / cancel), Google Calendar + .ics export
- Automatic 24h SMS reminders (hourly cron), manual resend from the dashboard

**Clinic dashboard** — role-based (owner / receptionist / dentist)
- Today + upcoming, weekly/monthly stats, new vs returning patients
- Appointments: search, filters, status flow (pending → confirmed → completed / cancelled),
  reschedule with live slot check, walk-in booking
- Google-Calendar-style week view; double-click to block time
- Patients list with visit history; CSV export (appointments + patients)
- Services (durations, prices, icons), staff & team accounts, full branding/settings,
  SMS template editor with live preview

**Platform (you)**
- `/admin/clinics`: create a clinic in one form (defaults + owner account seeded),
  hop into any clinic's dashboard, open its site

## Multi-tenancy

| Version | URL style | How |
| --- | --- | --- |
| V1 | `smile.yourplatform.com` | subdomain → rewritten by `src/middleware.ts` (set `NEXT_PUBLIC_ROOT_DOMAIN`) |
| V2 | `yourplatform.com/clinic/smile` | works out of the box |
| V3 | `www.smiledental.com` | custom domains via `CUSTOM_DOMAINS=domain=slug,…` |

Locally, `smile.localhost:3000` also works in modern browsers.

## Tech & architecture

Next.js 16 (App Router) · React 19 · TypeScript · Tailwind CSS 4 · Framer Motion ·
zod · file-based JSON store for dev/demo · Supabase-ready for production.

```
src/
  app/
    clinic/[slug]/       public clinic site, booking, manage-appointment
    admin/               dashboard pages (login + role-gated sections)
    api/public/[slug]/   availability, booking + OTP, manage, .ics
    api/admin/           appointments, calendar blocks, services, staff,
                         users, settings, clinics, exports
    api/cron/reminders/  24h SMS reminders (vercel.json cron, hourly)
  components/            site / booking / admin / ui primitives / icons
  lib/                   store + seed, availability engine, sms providers,
                         sessions, rbac, ics, schemas, utils
supabase/schema.sql      production schema: RLS tenant isolation +
                         exclusion constraint against double bookings
```

**Data layer:** the app currently persists to `data/db.json` (auto-seeded, zero setup —
ideal for local use and demos). For production, apply `supabase/schema.sql` to a
Supabase project and port `src/lib/store.ts` calls to Supabase queries — the schema
mirrors the TypeScript types one-to-one, and RLS enforces clinic isolation at the
database level.

**Deploy:** push to Vercel, set `SESSION_SECRET`, `NEXT_PUBLIC_ROOT_DOMAIN`, Twilio
vars and `CRON_SECRET`. `vercel.json` already schedules the reminder cron. Note that
the JSON file store is ephemeral on serverless — wire Supabase before selling access.

## Progress

See [PROGRESS.md](PROGRESS.md) for build status, verification results and the roadmap.
