-- ============================================================
-- DentalPro — production schema for Supabase (PostgreSQL)
-- Multi-tenant: every row is scoped by clinic_id and protected
-- by Row Level Security so clinics can never see each other.
-- ============================================================

create extension if not exists "pgcrypto";

-- ---------- enums ----------
create type appointment_status as enum ('pending', 'confirmed', 'completed', 'cancelled');
create type user_role as enum ('super_admin', 'owner', 'receptionist', 'dentist');
create type appointment_source as enum ('online', 'admin');

-- ---------- clinics ----------
create table clinics (
  id uuid primary key default gen_random_uuid(),
  slug text not null unique check (slug ~ '^[a-z0-9][a-z0-9-]{1,38}[a-z0-9]$'),
  name text not null,
  tagline text not null default '',
  logo_url text,
  primary_color text not null default '#2563eb',
  hero_headline text not null default 'Healthy Smiles Start Here.',
  hero_subheadline text not null default 'Book your appointment in less than a minute. No account required.',
  about_text text not null default '',
  patient_instructions text not null default '',
  address text not null default '',
  city text not null default '',
  phone text not null default '',
  emergency_phone text not null default '',
  email text not null default '',
  maps_embed_url text not null default '',
  socials jsonb not null default '{"facebook":"","instagram":"","tiktok":""}',
  stats jsonb not null default '{"yearsExperience":5,"happyPatients":1000,"certifiedDentists":2}',
  -- array of 7 {closed, open, close} objects, index 0 = Sunday
  working_hours jsonb not null,
  holidays jsonb not null default '[]',
  slot_step_minutes int not null default 30 check (slot_step_minutes between 5 and 120),
  min_lead_minutes int not null default 60 check (min_lead_minutes between 0 and 1440),
  max_advance_days int not null default 60 check (max_advance_days between 1 and 365),
  sms_templates jsonb not null default '{}',
  timezone text not null default 'Europe/Belgrade',
  published boolean not null default true,
  created_at timestamptz not null default now()
);

-- ---------- profiles (links Supabase Auth users to clinics/roles) ----------
create table profiles (
  id uuid primary key references auth.users (id) on delete cascade,
  clinic_id uuid references clinics (id) on delete cascade, -- null = super_admin
  role user_role not null,
  name text not null,
  dentist_id uuid, -- set when role = 'dentist'
  created_at timestamptz not null default now()
);

-- ---------- dentists ----------
create table dentists (
  id uuid primary key default gen_random_uuid(),
  clinic_id uuid not null references clinics (id) on delete cascade,
  name text not null,
  title text not null default '',
  bio text not null default '',
  working_hours jsonb, -- null = inherit clinic hours
  days_off date[] not null default '{}',
  active boolean not null default true
);

alter table profiles
  add constraint profiles_dentist_fk
  foreign key (dentist_id) references dentists (id) on delete set null;

-- ---------- services ----------
create table services (
  id uuid primary key default gen_random_uuid(),
  clinic_id uuid not null references clinics (id) on delete cascade,
  name text not null,
  description text not null default '',
  duration_minutes int not null check (duration_minutes between 5 and 480),
  price numeric(10, 2),
  icon text not null default 'other',
  active boolean not null default true,
  sort_order int not null default 0
);

-- ---------- patients (no auth accounts — keyed by phone per clinic) ----------
create table patients (
  id uuid primary key default gen_random_uuid(),
  clinic_id uuid not null references clinics (id) on delete cascade,
  first_name text not null,
  last_name text not null,
  phone text not null,
  email text,
  created_at timestamptz not null default now(),
  unique (clinic_id, phone)
);

-- ---------- appointments ----------
create table appointments (
  id uuid primary key default gen_random_uuid(),
  clinic_id uuid not null references clinics (id) on delete cascade,
  patient_id uuid not null references patients (id) on delete cascade,
  dentist_id uuid not null references dentists (id),
  service_id uuid not null references services (id),
  date date not null,
  start_time time not null,
  end_time time not null,
  status appointment_status not null default 'confirmed',
  issue text not null default '',
  manage_token text not null unique default encode(gen_random_bytes(32), 'hex'),
  source appointment_source not null default 'online',
  reminder_sent_at timestamptz,
  created_at timestamptz not null default now(),
  check (end_time > start_time)
);

create index appointments_clinic_date_idx on appointments (clinic_id, date);
create index appointments_dentist_date_idx on appointments (dentist_id, date)
  where status in ('pending', 'confirmed');

-- Prevent double bookings at the database level:
-- no two active appointments for the same dentist may overlap in time.
create extension if not exists btree_gist;
alter table appointments add constraint no_double_booking
  exclude using gist (
    dentist_id with =,
    daterange(date, date, '[]') with &&,
    timerange(start_time, end_time) with &&
  )
  where (status in ('pending', 'confirmed'));

-- ---------- blocked slots ----------
create table blocked_slots (
  id uuid primary key default gen_random_uuid(),
  clinic_id uuid not null references clinics (id) on delete cascade,
  dentist_id uuid references dentists (id) on delete cascade, -- null = whole clinic
  date date not null,
  start_time time not null,
  end_time time not null,
  reason text not null default '',
  check (end_time > start_time)
);

create index blocked_slots_clinic_date_idx on blocked_slots (clinic_id, date);

-- ---------- reviews ----------
create table reviews (
  id uuid primary key default gen_random_uuid(),
  clinic_id uuid not null references clinics (id) on delete cascade,
  name text not null,
  rating int not null check (rating between 1 and 5),
  text text not null,
  treatment text not null default ''
);

-- ---------- sms log ----------
create table sent_messages (
  id uuid primary key default gen_random_uuid(),
  clinic_id uuid not null references clinics (id) on delete cascade,
  phone text not null,
  body text not null,
  kind text not null check (kind in ('otp', 'confirmation', 'reminder', 'update')),
  sent_at timestamptz not null default now()
);

-- ---------- booking sessions (pending OTP verifications) ----------
create table booking_sessions (
  id uuid primary key default gen_random_uuid(),
  clinic_id uuid not null references clinics (id) on delete cascade,
  phone text not null,
  payload jsonb not null,
  attempts int not null default 0,
  expires_at timestamptz not null,
  created_at timestamptz not null default now()
);

-- ============================================================
-- Row Level Security — complete tenant isolation
-- ============================================================

alter table clinics enable row level security;
alter table profiles enable row level security;
alter table dentists enable row level security;
alter table services enable row level security;
alter table patients enable row level security;
alter table appointments enable row level security;
alter table blocked_slots enable row level security;
alter table reviews enable row level security;
alter table sent_messages enable row level security;
alter table booking_sessions enable row level security;

-- Helper: the clinic the signed-in staff member belongs to.
create or replace function auth_clinic_id() returns uuid
language sql stable security definer as $$
  select clinic_id from profiles where id = auth.uid();
$$;

create or replace function auth_role() returns user_role
language sql stable security definer as $$
  select role from profiles where id = auth.uid();
$$;

-- Public (anon) can read published clinic content for the websites.
create policy "public read clinics" on clinics
  for select using (published = true);
create policy "public read services" on services
  for select using (active = true);
create policy "public read dentists" on dentists
  for select using (active = true);
create policy "public read reviews" on reviews
  for select using (true);

-- Staff full access to their own clinic's rows (super_admin sees all).
create policy "staff read own clinic" on clinics
  for select using (id = auth_clinic_id() or auth_role() = 'super_admin');
create policy "owner update own clinic" on clinics
  for update using (
    (id = auth_clinic_id() and auth_role() = 'owner') or auth_role() = 'super_admin'
  );

create policy "staff manage dentists" on dentists
  for all using (clinic_id = auth_clinic_id() or auth_role() = 'super_admin');
create policy "staff manage services" on services
  for all using (clinic_id = auth_clinic_id() or auth_role() = 'super_admin');
create policy "staff manage patients" on patients
  for all using (clinic_id = auth_clinic_id() or auth_role() = 'super_admin');
create policy "staff manage appointments" on appointments
  for all using (clinic_id = auth_clinic_id() or auth_role() = 'super_admin');
create policy "staff manage blocked" on blocked_slots
  for all using (clinic_id = auth_clinic_id() or auth_role() = 'super_admin');
create policy "staff manage reviews" on reviews
  for all using (clinic_id = auth_clinic_id() or auth_role() = 'super_admin');
create policy "staff read messages" on sent_messages
  for select using (clinic_id = auth_clinic_id() or auth_role() = 'super_admin');

create policy "read own profile" on profiles
  for select using (id = auth.uid() or auth_role() = 'super_admin');

-- Booking sessions and public booking writes go through the service-role
-- key inside Next.js API routes / Edge Functions — no anon policies needed.
